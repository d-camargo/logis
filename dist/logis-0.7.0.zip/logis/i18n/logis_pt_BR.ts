<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>@default</name>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="116"/>
        <source>SRC da camada de {label} não foi definido; coordenadas dentro do Brasil — assumindo EPSG:4674 (SIRGAS 2000).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="122"/>
        <source>A camada de {label} está sem SRC válido (declarado: {crs}) e suas coordenadas não caem no Brasil. Defina o SRC da camada em Propriedades › Fonte e rode novamente.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="129"/>
        <source>A camada de {label} declara o SRC {crs}, mas as coordenadas estão em graus. Defina o SRC correto da camada em Propriedades › Fonte.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AlgTaskRunner</name>
    <message>
        <location filename="../gui/task_runner.py" line="54"/>
        <source>Algoritmo {id} não encontrado no registro do Processing.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FacilityLSCP</name>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="75"/>
        <source>Camada de demanda (Pontos/Polígonos)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="82"/>
        <source>Campo de peso da demanda (opcional, default=1.0)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="91"/>
        <source>Camada de instalações candidatas (Pontos/Polígonos) (opcional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="99"/>
        <source>Camada de rede viária (Linhas) (opcional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="107"/>
        <source>Distância/Tempo máximo de cobertura (max_distance)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="116"/>
        <source>Instalações selecionadas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="122"/>
        <source>Atribuição e cobertura de demandas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="137"/>
        <source>Camada de demanda inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="140"/>
        <source>A distância máxima deve ser estritamente maior que zero.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="155"/>
        <source>Lendo pontos de demanda...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="178"/>
        <source>Nenhum ponto de demanda válido encontrado.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="182"/>
        <source>Lendo instalações candidatas...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="194"/>
        <source>Nenhuma instalação candidata válida encontrada.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="201"/>
        <source>Construindo o grafo e calculando a matriz OD na rede...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="206"/>
        <source>Erro ao construir o grafo: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="212"/>
        <source>O grafo construído possui menos de 2 vértices.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="229"/>
        <source>Erro ao calcular a matriz OD: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="231"/>
        <source>Calculando matriz de distâncias euclidianas...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="240"/>
        <source>Executando a otimização LSCP (Toregas et al.)...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="250"/>
        <source>LSCP concluído. Instalações: {sel} | Totalmente Coberto: {cov} | Não cobertos: {unc}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="351"/>
        <source>Localização de Cobertura de Conjuntos (LSCP)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="354"/>
        <source>Localização de Instalações</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="360"/>
        <source>Resolve o problema de localização de cobertura de conjuntos (LSCP) utilizando a heurística gulosa de Toregas et al. (1971).

Seleciona o menor número possível de instalações para cobrir todos os pontos de demanda dentro da distância/tempo máximo especificado (max_distance).

Parâmetros:
- Camada de demanda: feições de pontos ou polígonos representando a demanda.
- Campo de peso da demanda: campo numérico indicando a demanda de cada feição (opcional, default=1.0).
- Camada de instalações candidatas: instalações elegíveis (opcional, usa a camada de demanda se omitida).
- Camada de rede viária: rede viária para distâncias reais na rede (opcional, usa distância euclidiana se omitida).
- Distância/Tempo máximo de cobertura: raio ou tempo limite para considerar uma demanda coberta.

Saídas:
- Instalações selecionadas: camada de candidatos escolhidos com total de demanda e pontos cobertos.
- Atribuição e cobertura de demandas: camada de demanda com o status de cobertura (is_covered) e a instalação atribuída.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="157"/>
        <source>camada de demanda</source>
        <translation>camada de demanda</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="184"/>
        <source>instalações candidatas</source>
        <translation>instalações candidatas</translation>
    </message>
</context>
<context>
    <name>FacilityMCLP</name>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="76"/>
        <source>Camada de demanda (Pontos/Polígonos)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="83"/>
        <source>Campo de peso da demanda (opcional, default=1.0)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="92"/>
        <source>Camada de instalações candidatas (Pontos/Polígonos) (opcional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="100"/>
        <source>Camada de rede viária (Linhas) (opcional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="108"/>
        <source>Número máximo de instalações (p)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="117"/>
        <source>Distância/Tempo máximo de cobertura (max_distance)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="126"/>
        <source>Instalações selecionadas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="132"/>
        <source>Atribuição e cobertura de demandas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="148"/>
        <source>Camada de demanda inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="151"/>
        <source>A distância máxima deve ser estritamente maior que zero.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="166"/>
        <source>Lendo pontos de demanda...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="189"/>
        <source>Nenhum ponto de demanda válido encontrado.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="193"/>
        <source>Lendo instalações candidatas...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="205"/>
        <source>Nenhuma instalação candidata válida encontrada.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="208"/>
        <source>O número de instalações p ({p}) excede o número de candidatos ({cand}).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="219"/>
        <source>Construindo o grafo e calculando a matriz OD na rede...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="224"/>
        <source>Erro ao construir o grafo: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="230"/>
        <source>O grafo construído possui menos de 2 vértices.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="247"/>
        <source>Erro ao calcular a matriz OD: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="249"/>
        <source>Calculando matriz de distâncias euclidianas...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="258"/>
        <source>Executando a otimização MCLP (Church &amp; ReVelle)...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="269"/>
        <source>MCLP concluído. Instalações: {sel} | Demanda Coberta: {cov:.2f}/{tot:.2f} ({ratio:.1%})</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="361"/>
        <source>Localização de Cobertura Máxima (MCLP)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="364"/>
        <source>Localização de Instalações</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="370"/>
        <source>Resolve o problema de localização de cobertura máxima (MCLP) utilizando a heurística gulosa de Church &amp; ReVelle (1974).

Seleciona até p instalações candidatas que maximizem o peso da demanda atendida dentro da distância/tempo máximo especificado (max_distance).

Parâmetros:
- Camada de demanda: feições de pontos ou polígonos representando a demanda.
- Campo de peso da demanda: campo numérico indicando a demanda de cada feição (opcional, default=1.0).
- Camada de instalações candidatas: instalações elegíveis (opcional, usa a camada de demanda se omitida).
- Camada de rede viária: rede viária para distâncias reais na rede (opcional, usa distância euclidiana se omitida).
- Número máximo de instalações (p): quantidade máxima de instalações a selecionar.
- Distância/Tempo máximo de cobertura: raio ou tempo limite para considerar uma demanda coberta.

Saídas:
- Instalações selecionadas: camada de candidatos escolhidos com total de demanda e pontos cobertos.
- Atribuição e cobertura de demandas: camada de demanda com o status de cobertura (is_covered) e a instalação atribuída.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="168"/>
        <source>camada de demanda</source>
        <translation>camada de demanda</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="195"/>
        <source>instalações candidatas</source>
        <translation>instalações candidatas</translation>
    </message>
</context>
<context>
    <name>FacilityPMedian</name>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="76"/>
        <source>Camada de demanda (Pontos/Polígonos)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="83"/>
        <source>Campo de peso da demanda (opcional, default=1.0)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="92"/>
        <source>Camada de instalações candidatas (Pontos/Polígonos) (opcional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="100"/>
        <source>Camada de rede viária (Linhas) (opcional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="108"/>
        <source>Número de instalações (p)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="117"/>
        <source>Número máximo de iterações do Teitz-Bart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="126"/>
        <source>Instalações selecionadas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="132"/>
        <source>Atribuição de demandas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="148"/>
        <source>Camada de demanda inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="163"/>
        <source>Lendo pontos de demanda...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="186"/>
        <source>Nenhum ponto de demanda válido encontrado.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="190"/>
        <source>Lendo instalações candidatas...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="202"/>
        <source>Nenhuma instalação candidata válida encontrada.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="205"/>
        <source>O número de instalações p ({p}) excede o número de candidatos ({cand}).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="216"/>
        <source>Construindo o grafo e calculando a matriz OD na rede...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="221"/>
        <source>Erro ao construir o grafo: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="227"/>
        <source>O grafo construído possui menos de 2 vértices.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="244"/>
        <source>Erro ao calcular a matriz OD: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="246"/>
        <source>Calculando matriz de distâncias euclidianas...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="255"/>
        <source>Executando a otimização p-Mediana (Teitz-Bart)...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="266"/>
        <source>Localização concluída. Instalações selecionadas: {sel} | Custo Total: {cost:.2f}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="348"/>
        <source>Localização p-Mediana (Teitz-Bart)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="351"/>
        <source>Localização de Instalações</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="357"/>
        <source>Resolve o problema de localização p-mediana selecionando p instalações candidatas que minimizem a soma total das distâncias/custos ponderadas da demanda até a instalação mais próxima.

Parâmetros:
- Camada de demanda: feições de pontos ou polígonos representando a demanda.
- Campo de peso da demanda: campo numérico indicando a demanda de cada feição (opcional, default=1.0).
- Camada de instalações candidatas: instalações elegíveis (opcional, usa a camada de demanda se omitida).
- Camada de rede viária: rede viária para distâncias reais na rede (opcional, usa distância euclidiana se omitida).
- Número de instalações (p): quantidade de instalações a selecionar.
- Número máximo de iterações: limite de trocas locais no algoritmo Teitz-Bart.

Saídas:
- Instalações selecionadas: camada de candidatos escolhidos com totais de demanda e custo.
- Atribuição de demandas: camada de demanda com o ID da instalação atribuída e o custo de atendimento.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="165"/>
        <source>camada de demanda</source>
        <translation>camada de demanda</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="192"/>
        <source>instalações candidatas</source>
        <translation>instalações candidatas</translation>
    </message>
</context>
<context>
    <name>LoadOsmNetwork</name>
    <message>
        <location filename="../algorithms/data_osm_network.py" line="52"/>
        <source>Código IBGE do município (7 dígitos)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/data_osm_network.py" line="58"/>
        <source>Nome do município (opcional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/data_osm_network.py" line="65"/>
        <source>Forçar novo download (ignorar cache)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/data_osm_network.py" line="72"/>
        <source>Arcos (rede viária)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/data_osm_network.py" line="78"/>
        <source>Nós (rede viária)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/data_osm_network.py" line="92"/>
        <source>Código IBGE do município deve possuir exatamente 7 dígitos.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/data_osm_network.py" line="124"/>
        <source>nenhuma via encontrada para o município</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/data_osm_network.py" line="136"/>
        <source>Não foi possível criar o sink de arcos.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/data_osm_network.py" line="147"/>
        <source>Não foi possível criar o sink de nós.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/data_osm_network.py" line="168"/>
        <source>Rede viária OSM carregada: {links} arcos, {nodes} nós.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/data_osm_network.py" line="185"/>
        <source>Baixar rede viária urbana (OSM, município)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/data_osm_network.py" line="188"/>
        <source>Dados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/data_osm_network.py" line="110"/>
        <source>Fonte: {backend}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/data_osm_network.py" line="194"/>
        <source>Baixa e processa a rede viária urbana de um município a partir dos dados do OpenStreetMap.
Utiliza o algoritmo gisbr:osm_network quando o GisBR 0.11+ está instalado e o pipeline interno caso contrário.
Em ambos os casos, os arcos trazem os campos de custo length, speed e travel_time.

Parâmetros:
- Código IBGE do município: código numérico de 7 dígitos.
- Nome do município (opcional): para auxiliar na identificação.
- Forçar novo download: se verdadeiro, ignora o cache local e faz nova requisição Overpass.

Retorno:
- Arcos (rede viária): camada de linhas representando os trechos de vias recortados para o município.
- Nós (rede viária): camada de pontos representando as interseções e extremidades dos arcos.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LoadSnvNetwork</name>
    <message>
        <location filename="../algorithms/data_snv_network.py" line="44"/>
        <source>Sigla da UF (2 letras)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/data_snv_network.py" line="50"/>
        <source>Forçar novo download (ignorar cache)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/data_snv_network.py" line="57"/>
        <source>Arcos (rede viária)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/data_snv_network.py" line="63"/>
        <source>Nós (rede viária)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/data_snv_network.py" line="76"/>
        <source>UF inválida: {uf}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/data_snv_network.py" line="99"/>
        <source>O SNV não devolveu dados para a UF {uf}.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/data_snv_network.py" line="111"/>
        <source>Não foi possível criar o sink de arcos.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/data_snv_network.py" line="122"/>
        <source>Não foi possível criar o sink de nós.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/data_snv_network.py" line="143"/>
        <source>Rede viária SNV carregada: {links} arcos, {nodes} nós.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/data_snv_network.py" line="160"/>
        <source>Baixar rede viária federal (SNV/DNIT, UF)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/data_snv_network.py" line="163"/>
        <source>Dados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/data_snv_network.py" line="169"/>
        <source>Baixa e processa a rede viária federal de uma UF a partir dos dados do SNV/DNIT.

Parâmetros:
- Sigla da UF (2 letras): sigla do estado brasileiro (ex.: MG, SP, RJ).
- Forçar novo download: se verdadeiro, ignora o cache local e faz nova requisição.

Retorno:
- Arcos (rede viária): camada de linhas representando os trechos de rodovias federais/estaduais no estado.
- Nós (rede viária): camada de pontos representando as interseções e extremidades dos arcos.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LogisPlugin</name>
    <message>
        <location filename="../logis_plugin.py" line="48"/>
        <source>Dependências...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../logis_plugin.py" line="62"/>
        <source>Indicadores Urbanos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../logis_plugin.py" line="69"/>
        <source>Indicadores Regionais</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../logis_plugin.py" line="76"/>
        <source>Coleta de Lixo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../logis_plugin.py" line="83"/>
        <source>Roteirização</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../logis_plugin.py" line="90"/>
        <source>Documentação</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../logis_plugin.py" line="55"/>
        <source>Rede Viária</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LogisProvider</name>
    <message>
        <location filename="../provider.py" line="79"/>
        <source>logis — suporte a projetos de logística no Brasil</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NetworkDock</name>
    <message>
        <location filename="../gui/network_dock.py" line="234"/>
        <source>logis — Rede Viária</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="266"/>
        <source>&lt;b&gt;Rede Viária&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="280"/>
        <source>Município (OSM)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="319"/>
        <source>UF:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="287"/>
        <source>Listar municípios da UF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="291"/>
        <source>Município:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="296"/>
        <source>Código IBGE (7 dígitos):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="324"/>
        <source>Forçar novo download (ignorar cache)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="310"/>
        <source>Baixar arcos e nós (OSM)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="317"/>
        <source>Estado (SNV/DNIT)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="327"/>
        <source>Baixar arcos e nós (SNV)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="340"/>
        <source>&lt;b&gt;Resultados:&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="389"/>
        <source>Municípios de {uf} carregados com sucesso.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="391"/>
        <source>Erro ao listar municípios: {str(e)}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="455"/>
        <source>Erro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="400"/>
        <source>Código IBGE do município deve possuir 7 dígitos.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="304"/>
        <source>Fonte: GisBR (gisbr:osm_network)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="306"/>
        <source>Fonte: pipeline interno do logis — instale o GisBR 0.11+ para usar o fluxo único</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="270"/>
        <source>O painel baixa arcos e nós direto para o projeto. O download roda em primeiro plano; acompanhe o andamento na barra de progresso.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="383"/>
        <source>Listando municípios…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="405"/>
        <source>Baixando rede viária OSM…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="444"/>
        <source>Rede viária OSM ({code_muni}) carregada via {source}: {n_links} arcos, {n_nodes} nós.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="453"/>
        <source>Por favor, selecione uma UF.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="458"/>
        <source>Baixando rede viária SNV…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="490"/>
        <source>Rede viária SNV ({uf}) carregada: {n_links} arcos, {n_nodes} nós.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RegionalCriticalLinks</name>
    <message>
        <location filename="../algorithms/regional_critical_links.py" line="54"/>
        <source>Camada de malha rodoviária (Linhas)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_critical_links.py" line="61"/>
        <source>Trechos com indicação de ponte/arco crítico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_critical_links.py" line="67"/>
        <source>Número de pontes/arcos críticos identificados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_critical_links.py" line="78"/>
        <source>Camada de malha rodoviária inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_critical_links.py" line="80"/>
        <source>Construindo o grafo a partir da malha rodoviária...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_critical_links.py" line="84"/>
        <source>Erro ao construir o grafo: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_critical_links.py" line="90"/>
        <source>O grafo construído está vazio.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_critical_links.py" line="95"/>
        <source>Deduplicando arcos em arestas físicas únicas...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_critical_links.py" line="113"/>
        <source>Identificando pontes/arcos críticos ({n} arestas físicas)...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_critical_links.py" line="130"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_critical_links.py" line="146"/>
        <source>Pontes/arcos críticos identificados: {n} de {total} trechos.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_critical_links.py" line="162"/>
        <source>Pontes/Arcos Críticos da Malha Regional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_critical_links.py" line="165"/>
        <source>Indicadores Regionais</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_critical_links.py" line="171"/>
        <source>Identifica as pontes/arcos críticos (cut links) da malha rodoviária regional: trechos cuja remoção desconecta a rede, indicando ligações intermunicipais sem rota alternativa.

Parâmetros:
- Camada de malha rodoviária: feições de linha representando as rodovias.

Retorno:
- Camada de linhas com o campo 'is_critical_link' (booleano), uma feição por trecho físico único da malha.
- Número de pontes/arcos críticos identificados.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RegionalDock</name>
    <message>
        <location filename="../gui/regional_dock.py" line="168"/>
        <source>logis — Indicadores Regionais</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="185"/>
        <source>&lt;b&gt;Indicadores Regionais&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="189"/>
        <source>Selecione as camadas e parâmetros abaixo para calcular os indicadores de densidade rodoviária regional e percentual de pavimentação.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="200"/>
        <source>Camada de rede regional (Linhas):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="206"/>
        <source>Camada de área de referência (Polígonos - para Densidade):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="212"/>
        <source>População da área de referência (habitantes):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="219"/>
        <source>Calcular Densidade Rodoviária</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="225"/>
        <source>Calcular % Pavimentação</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="231"/>
        <source>Calcular Pontes/Arcos Críticos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="237"/>
        <source>Resultados dos Indicadores Regionais:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="395"/>
        <source>Aviso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="395"/>
        <source>Por favor, selecione uma camada de rede regional.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="400"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro: Camada de rede regional não selecionada.&lt;/span&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="271"/>
        <source>Por favor, selecione uma camada de área de referência.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="276"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro: Camada de área de referência não selecionada.&lt;/span&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="406"/>
        <source>Erro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="406"/>
        <source>QGIS Processing não está disponível no ambiente atual.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="411"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro: QGIS Processing não disponível.&lt;/span&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="291"/>
        <source>&lt;b&gt;=== CALCULANDO DENSIDADE RODOVIÁRIA REGIONAL ===&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="303"/>
        <source>-&gt; &lt;b&gt;Densidade por Área:&lt;/b&gt; {value:.4f} km/1.000 km²</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="307"/>
        <source>-&gt; &lt;b&gt;Densidade por Área:&lt;/b&gt; N/A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="310"/>
        <source>-&gt; &lt;b&gt;Densidade por População:&lt;/b&gt; {value:.4f} km/10.000 hab.&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="314"/>
        <source>-&gt; &lt;b&gt;Densidade por População:&lt;/b&gt; N/A&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="317"/>
        <source>&lt;span style=&apos;color: #fc8181;&apos;&gt;Erro ao calcular densidade: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="440"/>
        <source>&lt;b&gt;=== CÁLCULO CONCLUÍDO ===&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="353"/>
        <source>&lt;b&gt;=== CALCULANDO PERCENTUAL DE PAVIMENTAÇÃO ===&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="364"/>
        <source>-&gt; &lt;b&gt;Percentual Pavimentada:&lt;/b&gt; {value:.2f}%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="368"/>
        <source>-&gt; &lt;b&gt;Percentual Pavimentada:&lt;/b&gt; N/A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="371"/>
        <source>-&gt; &lt;b&gt;Percentual Duplicada:&lt;/b&gt; {value:.2f}%&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="375"/>
        <source>-&gt; &lt;b&gt;Percentual Duplicada:&lt;/b&gt; N/A&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="378"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro ao calcular pavimentação: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="415"/>
        <source>&lt;b&gt;=== CALCULANDO PONTES/ARCOS CRÍTICOS ===&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="429"/>
        <source>-&gt; &lt;b&gt;Pontes/Arcos Críticos:&lt;/b&gt; {n} de {total} trechos.&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="436"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro ao calcular pontes/arcos críticos: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RegionalNetworkDensity</name>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="46"/>
        <source>Camada de malha rodoviária (Linhas)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="53"/>
        <source>Camada de área de referência (UF, mesorregião, etc.)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="60"/>
        <source>População da área de referência (hab.)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="68"/>
        <source>Densidade rodoviária por área (km/1.000 km²)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="74"/>
        <source>Densidade rodoviária por população (km/10.000 hab.)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="87"/>
        <source>Camada de malha rodoviária inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="89"/>
        <source>Camada de área de referência inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="92"/>
        <source>O campo 'length' não foi encontrado na camada de malha rodoviária. Utilize a camada snv_links_{uf} gerada por core.network.snv_pipeline.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="104"/>
        <source>Somando a extensão total da malha rodoviária (campo 'length')...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="121"/>
        <source>Calculando a área total do polígono de referência...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="136"/>
        <source>A área calculada é de 0 km² ou negativa. Verifique a geometria de referência.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="146"/>
        <source>Extensão da Malha: {length:.2f} m | Área: {area:.4f} km² | População: {pop:.0f} hab.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="151"/>
        <source>Densidade por Área: {da:.4f} km/1.000 km² | Densidade por População: {dp:.4f} km/10.000 hab.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="168"/>
        <source>Densidade da Malha Rodoviária Regional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="171"/>
        <source>Indicadores Regionais</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="177"/>
        <source>Calcula a densidade da malha rodoviária por área territorial (km/1.000 km²) e por população (km/10.000 hab.).

Parâmetros:
- Camada de malha rodoviária: feições de linha representando as rodovias.
- Camada de área de referência: feições de polígono definindo o território (UF, mesorregião, etc.).
- População da área de referência: número de habitantes do território.

Retornos:
- Densidade rodoviária por área (km/1.000 km²).
- Densidade rodoviária por população (km/10.000 hab.).</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RegionalPavementPercentage</name>
    <message>
        <location filename="../algorithms/regional_pavement_percentage.py" line="42"/>
        <source>Camada de malha rodoviária (Linhas)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_pavement_percentage.py" line="49"/>
        <source>Campo que indica o tipo de superfície (ex: 'ds_superfi')</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_pavement_percentage.py" line="59"/>
        <source>Percentual de vias pavimentadas (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_pavement_percentage.py" line="65"/>
        <source>Percentual de vias duplicadas (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_pavement_percentage.py" line="77"/>
        <source>Camada de malha rodoviária inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_pavement_percentage.py" line="84"/>
        <source>O campo '{field}' não foi encontrado na camada de malha rodoviária. Campos disponíveis: {fields}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_pavement_percentage.py" line="90"/>
        <source>O campo 'length' não foi encontrado na camada de malha rodoviária. Utilize a camada snv_links_{uf} gerada por core.network.snv_pipeline.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_pavement_percentage.py" line="103"/>
        <source>Somando as extensões da malha rodoviária (campo 'length')...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_pavement_percentage.py" line="124"/>
        <source>O comprimento total da malha é de 0 metros ou menor. Verifique as feições da camada de entrada.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_pavement_percentage.py" line="136"/>
        <source>Extensão Total: {total:.2f} m | Pavimentada: {paved:.2f} m | Duplicada: {dup:.2f} m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_pavement_percentage.py" line="141"/>
        <source>Percentual Pavimentada: {p_paved:.2f}% | Percentual Duplicada: {p_dup:.2f}%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_pavement_percentage.py" line="158"/>
        <source>Percentual de Pavimentação e Duplicação</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_pavement_percentage.py" line="161"/>
        <source>Indicadores Regionais</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/regional_pavement_percentage.py" line="167"/>
        <source>Calcula o percentual da malha rodoviária regional que é pavimentada e o percentual que é duplicada.

Parâmetros:
- Camada de malha rodoviária: feições de linha representando as rodovias.
- Campo de superfície: o atributo que armazena a superfície física (ex: 'ds_superfi').

Retornos:
- Percentual da malha pavimentada (%).
- Percentual da malha duplicada (%).</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RoutingDock</name>
    <message>
        <location filename="../gui/routing_dock.py" line="254"/>
        <source>logis — Roteirização</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="291"/>
        <source>&lt;b&gt;Roteirização&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="340"/>
        <source>Camada do ponto inicial (Pontos):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="346"/>
        <source>Camada de pontos a visitar (Pontos):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="352"/>
        <source>Camada do ponto final (Pontos - opcional, vazio fecha no ponto inicial):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="307"/>
        <source>Camada de rede viária (Linhas - opcional):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="494"/>
        <source>Aplicar busca local (2-opt e Or-opt)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="405"/>
        <source>Calcular Rota (TSP)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="318"/>
        <source>Resultados da Roteirização:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="933"/>
        <source>Aviso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="705"/>
        <source>Por favor, selecione a camada do ponto inicial.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="710"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro: Ponto inicial não selecionado.&lt;/span&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="714"/>
        <source>Por favor, selecione a camada de pontos a visitar.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="719"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro: Pontos a visitar não selecionados.&lt;/span&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="739"/>
        <source>&lt;b&gt;=== CALCULANDO ROTA (TSP) ===&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="861"/>
        <source>-&gt; &lt;b&gt;Pontos visitados:&lt;/b&gt; {n}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="873"/>
        <source>-&gt; &lt;b&gt;Razão de deadhead (dead_ratio):&lt;/b&gt; {dr:.4f}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="876"/>
        <source>Sim (fecha no ponto inicial)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="876"/>
        <source>Não (termina no ponto final)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="877"/>
        <source>-&gt; &lt;b&gt;Fechamento:&lt;/b&gt; {closed}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="902"/>
        <source>&lt;span style=&apos;color: #fc8181;&apos;&gt;Erro ao calcular rota: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="1082"/>
        <source>&lt;b&gt;=== CÁLCULO CONCLUÍDO ===&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="337"/>
        <source>TSP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="413"/>
        <source>CVRP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="422"/>
        <source>Nota: A camada de rede viária utilizada é a selecionada no topo do painel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="445"/>
        <source>Camada de demanda / clientes (Pontos):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="460"/>
        <source>Campo de peso/demanda (opcional, default = 1,0):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="469"/>
        <source>Capacidade do veículo:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="506"/>
        <source>Executar Roteirização (CVRP)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="924"/>
        <source>Por favor, selecione a camada de depósito.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="929"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro: Depósito não selecionado.&lt;/span&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="933"/>
        <source>Por favor, selecione a camada de demanda / clientes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="938"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro: Camada de demanda não selecionada.&lt;/span&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="941"/>
        <source>&lt;b&gt;=== EXECUTANDO ROTEIRIZAÇÃO (CVRP) ===&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="1055"/>
        <source>-&gt; &lt;b&gt;Rotas geradas:&lt;/b&gt; {n}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="1058"/>
        <source>-&gt; &lt;b&gt;Paradas atendidas:&lt;/b&gt; {n}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="1061"/>
        <source>-&gt; &lt;b&gt;Carga total:&lt;/b&gt; {load:.2f}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="1084"/>
        <source>&lt;span style=&apos;color: #fc8181;&apos;&gt;Erro ao executar CVRP: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="295"/>
        <source>O painel reúne o Caixeiro Viajante e a Roteirização de Veículos Capacitados; a camada de rede viária escolhida abaixo vale para a aba CVRP e, na aba TSP, quando o modo &quot;pela rede viária&quot; está selecionado.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="324"/>
        <source>Cancelar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="360"/>
        <source>Modo de cálculo da distância:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="362"/>
        <source>Linha reta (euclidiana)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="362"/>
        <source>Pela rede viária (Dijkstra)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="368"/>
        <source>Nota: O modo &quot;pela rede viária&quot; utiliza a camada de rede escolhida no topo do painel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="477"/>
        <source>Backend de otimização:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="479"/>
        <source>Automático (OR-Tools quando disponível)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="479"/>
        <source>Python puro (heurística)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="479"/>
        <source>OR-Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="486"/>
        <source>Nota: Em modo automático, o OR-Tools é utilizado se disponível, com fallback para Python puro.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="498"/>
        <source>Refina a rota inicial invertendo trechos (2-opt) e reposicionando paradas (Or-opt). Reduz a distância total e aumenta o tempo de cálculo.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="616"/>
        <source>-&gt; &lt;b&gt;Destino das saídas:&lt;/b&gt; camada temporária</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="666"/>
        <source>&lt;span style='color: #ecc94b;'&gt;Aviso: Falha ao carregar camada do GPKG ({nome}). Usando camada temporária.&lt;/span&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="676"/>
        <source>Erro desconhecido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="677"/>
        <source>&lt;span style='color: #ecc94b;'&gt;Aviso: Falha ao gravar no GPKG ({err}). Usando camada temporária.&lt;/span&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="687"/>
        <source>-&gt; &lt;b&gt;Destino das saídas:&lt;/b&gt; {dest}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="723"/>
        <source>O modo pela rede viária exige uma camada de rede viária no topo do painel (ex: osm_links_&lt;code_muni&gt; do pipeline OSM).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="731"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro: O modo pela rede exige uma camada de rede viária no topo do painel (ex: osm_links_&lt;code_muni&gt; do pipeline OSM).&lt;/span&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="944"/>
        <source>&lt;span style='color: #ecc94b;'&gt;Aviso: O OR-Tools está desativado por ter derrubado a sessão anterior. O rearme fica no diálogo de Dependências.&lt;/span&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="1002"/>
        <source>&lt;span style='color: #ecc94b;'&gt;Cálculo cancelado pelo usuário.&lt;/span&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="806"/>
        <source>Erro ao calcular rota.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="864"/>
        <source>-&gt; &lt;b&gt;Distância total do tour:&lt;/b&gt; {dist:.2f}&amp;nbsp;m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="867"/>
        <source>-&gt; &lt;b&gt;Custo de acesso:&lt;/b&gt; {acc:.2f}&amp;nbsp;m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="870"/>
        <source>-&gt; &lt;b&gt;Custo de retorno:&lt;/b&gt; {ret:.2f}&amp;nbsp;m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="880"/>
        <source>-&gt; &lt;b&gt;Modo de distância:&lt;/b&gt; {mode}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="883"/>
        <source>-&gt; &lt;b&gt;Backend de otimização:&lt;/b&gt; {backend}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="1075"/>
        <source>-&gt; &lt;b&gt;Tempo de cálculo:&lt;/b&gt; {t} s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="1078"/>
        <source>-&gt; &lt;b&gt;Unidade das distâncias:&lt;/b&gt; metros&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="894"/>
        <source>&lt;span style='color: #ecc94b;'&gt;Aviso: {n} trecho(s) caíram no segmento reto por falta de caminho na malha.&lt;/span&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="1011"/>
        <source>Erro ao executar CVRP.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="1050"/>
        <source>Rota {id}: {n} paradas | carga {load:.2f} | distância {dist:.2f}&amp;nbsp;m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="1064"/>
        <source>-&gt; &lt;b&gt;Distância total:&lt;/b&gt; {dist:.2f}&amp;nbsp;m&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="989"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro ao iniciar o cálculo: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="415"/>
        <source>Resolve a roteirização de uma frota com capacidade a partir de um ou mais depósitos.</source>
        <translation>Resolve a roteirização de uma frota com capacidade a partir de um ou mais depósitos.</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="430"/>
        <source>Camada de depósitos (Pontos) — origem/destino das rotas:</source>
        <translation>Camada de depósitos (Pontos) — origem/destino das rotas:</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="436"/>
        <source>Campo ID do depósito (opcional):</source>
        <translation>Campo ID do depósito (opcional):</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="451"/>
        <source>Campo do depósito de cada ponto (opcional — vazio: depósito mais próximo):</source>
        <translation>Campo do depósito de cada ponto (opcional — vazio: depósito mais próximo):</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="1049"/>
        <source>depósito {id}</source>
        <translation>depósito {id}</translation>
    </message>
</context>
<context>
    <name>UrbanCargoRestriction</name>
    <message>
        <location filename="../algorithms/urban_cargo_restriction.py" line="74"/>
        <source>Camada de rede viária (Linhas)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_cargo_restriction.py" line="81"/>
        <source>Expressão de restrição (retorna verdadeiro para trechos restritos). Se vazia, usa o filtro default por tipo de via (highway), largura e peso máximo, quando esses campos existirem na camada.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_cargo_restriction.py" line="94"/>
        <source>Índice de restrição de circulação (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_cargo_restriction.py" line="106"/>
        <source>Camada de rede viária inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_cargo_restriction.py" line="112"/>
        <source>Usando expressão de restrição default: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_cargo_restriction.py" line="122"/>
        <source>Expressão de restrição inválida: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_cargo_restriction.py" line="134"/>
        <source>Calculando a extensão total e restrita da rede viária...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_cargo_restriction.py" line="154"/>
        <source>Erro ao avaliar a expressão de restrição: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_cargo_restriction.py" line="168"/>
        <source>O comprimento total da rede viária calculada é 0 m ou negativo. Verifique as geometrias.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_cargo_restriction.py" line="178"/>
        <source>Comprimento Total: {total:.2f} m | Comprimento Restrito: {restricted:.2f} m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_cargo_restriction.py" line="183"/>
        <source>Índice de Acessibilidade de Carga: {index:.2f}%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_cargo_restriction.py" line="195"/>
        <source>Índice de Restrição de Circulação de Carga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_cargo_restriction.py" line="198"/>
        <source>Indicadores Urbanos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_cargo_restriction.py" line="204"/>
        <source>Calcula o índice de restrição de circulação para veículos de carga (acessibilidade de carga).
O índice representa o percentual da rede viária urbana que está livre de restrições de circulação.

Parâmetros:
- Camada de rede viária: feições de linha representando as vias.
- Expressão de restrição: expressão QGIS opcional que define quais trechos possuem restrições (ex: &quot;maxweight&quot; IS NOT NULL ou &quot;largura&quot; &lt; 3.0).

Retorno:
- Valor numérico (%) de 0.0 a 100.0, onde 100.0 indica que nenhuma via é restrita.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UrbanDeliveryDistance</name>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="55"/>
        <source>Camada de rede viária (Linhas)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="62"/>
        <source>Camada de depósitos candidatos (Pontos)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="69"/>
        <source>Camada de zonas/centroides (Pontos)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="76"/>
        <source>Critério de custo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="76"/>
        <source>Distância</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="76"/>
        <source>Tempo de viagem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="84"/>
        <source>Zonas com custo de entrega</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="98"/>
        <source>Camada de rede viária inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="100"/>
        <source>Camada de depósitos inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="102"/>
        <source>Camada de zonas inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="108"/>
        <source>Lendo depósitos...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="117"/>
        <source>Nenhum depósito válido encontrado na camada de depósitos.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="120"/>
        <source>Lendo zonas...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="129"/>
        <source>Nenhuma zona válida encontrada na camada de zonas.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="132"/>
        <source>Construindo o grafo a partir da rede viária...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="137"/>
        <source>Erro ao construir o grafo: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="143"/>
        <source>O grafo construído possui menos de 2 vértices. Não é possível calcular as distâncias.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="154"/>
        <source>Não foi possível amarrar um ou mais depósitos à rede viária.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="156"/>
        <source>Não foi possível amarrar uma ou mais zonas à rede viária.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="159"/>
        <source>Calculando matriz de distâncias/tempos de viagem depósito-zona...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="167"/>
        <source>Erro ao calcular a matriz OD: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="184"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="192"/>
        <source>Custo de entrega ao depósito mais próximo calculado para {count} zona(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="203"/>
        <source>Distância de Entrega Urbana</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="206"/>
        <source>Indicadores Urbanos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="212"/>
        <source>Calcula a distância ou tempo de entrega ao depósito mais próximo para cada zona de demanda (centroide de setor) a partir de uma camada de depósitos candidatos, usando caminhos mínimos na rede viária.

Parâmetros:
- Camada de rede viária: feições de linha representando as vias.
- Camada de depósitos candidatos: feições de ponto representando os depósitos/centros de distribuição.
- Camada de zonas/centroides: feições de ponto representando as zonas de demanda/entregas.
- Critério de custo: define se o cálculo de custo de caminho mínimo é baseado em Distância ou Tempo de viagem.

Retorno:
- Cópia da camada de zonas com a coluna 'dist_entrega' (contendo a menor distância ou tempo de viagem até o depósito mais próximo).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="110"/>
        <source>camada de depósitos</source>
        <translation>camada de depósitos</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="122"/>
        <source>camada de zonas</source>
        <translation>camada de zonas</translation>
    </message>
</context>
<context>
    <name>UrbanDemandDensity</name>
    <message>
        <location filename="../algorithms/urban_demand_density.py" line="47"/>
        <source>Código IBGE do município (7 dígitos)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_demand_density.py" line="53"/>
        <source>Campo de população (ou domicílios/empregos) na camada do censobr unida por gisbr:join_censo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_demand_density.py" line="62"/>
        <source>Setores censitários com densidade de demanda</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_demand_density.py" line="74"/>
        <source>Código do município é obrigatório.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_demand_density.py" line="76"/>
        <source>Campo de população é obrigatório.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_demand_density.py" line="78"/>
        <source>Obtendo setores censitários do município {}...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_demand_density.py" line="87"/>
        <source>Campo de população '{field}' não encontrado. Campos disponíveis: {available}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_demand_density.py" line="101"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_demand_density.py" line="107"/>
        <source>Calculando densidade de demanda por setor...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_demand_density.py" line="123"/>
        <source>Setor {fid}: {error}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_demand_density.py" line="136"/>
        <source>Densidade de demanda calculada para {count} setor(es).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_demand_density.py" line="145"/>
        <source>Densidade de Demanda Urbana</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_demand_density.py" line="148"/>
        <source>Indicadores Urbanos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_demand_density.py" line="154"/>
        <source>Calcula a densidade de demanda (população, domicílios ou empregos por km²) de cada setor censitário de um município, a partir dos setores + variáveis do censobr (gisbr:read_census_tract + gisbr:join_censo). Requer o plugin GisBR instalado.

Parâmetros:
- Código IBGE do município: código de 7 dígitos.
- Campo de população: nome do campo de população/domicílios/empregos na camada unida pelo censobr (varia conforme o dataset do censobr).

Retorno:
- Cópia dos setores censitários com o campo 'dens_demanda_hab_km2'.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UrbanDock</name>
    <message>
        <location filename="../gui/urban_dock.py" line="184"/>
        <source>logis — Indicadores Urbanos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="217"/>
        <source>&lt;b&gt;Indicadores Urbanos&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="254"/>
        <source>Camada de área de referência (Polígonos - para Densidade):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="260"/>
        <source>Calcular Indicadores</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="241"/>
        <source>Resultados dos Indicadores:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="292"/>
        <source>&lt;b&gt;Densidade de Demanda&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="296"/>
        <source>Código IBGE do município (7 dígitos):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="300"/>
        <source>Campo de população (setor + censobr, requer GisBR):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="304"/>
        <source>Calcular Densidade de Demanda</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="309"/>
        <source>&lt;b&gt;Acessibilidade Gravitacional&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="313"/>
        <source>Camada de origem (pontos/centroides):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="318"/>
        <source>Camada de destinos (POIs):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="323"/>
        <source>Campo de peso do destino (opcional, default 1):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="329"/>
        <source>Beta (decaimento por distância):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="336"/>
        <source>Calcular Acessibilidade Gravitacional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="266"/>
        <source>&lt;b&gt;Centralidade de Intermediação (Betweenness)&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="270"/>
        <source>Número de amostras (pares OD):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="283"/>
        <source>Calcular Centralidade de Intermediação</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="361"/>
        <source>&lt;b&gt;Distância de Entrega&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="365"/>
        <source>Camada de depósitos candidatos (Pontos):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="370"/>
        <source>Camada de zonas/centroides (Pontos):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="375"/>
        <source>Critério de custo:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="377"/>
        <source>Distância</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="377"/>
        <source>Tempo de viagem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="380"/>
        <source>Calcular Distância de Entrega</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="741"/>
        <source>Aviso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="727"/>
        <source>Por favor, selecione uma camada de rede viária.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="404"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro: Camada de rede viária não selecionada.&lt;/span&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="751"/>
        <source>Erro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="751"/>
        <source>QGIS Processing não está disponível no ambiente atual.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="415"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro: QGIS Processing não disponível.&lt;/span&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="419"/>
        <source>&lt;b&gt;=== INICIANDO CÁLCULO DOS INDICADORES ===&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="423"/>
        <source>&lt;i&gt;1) Densidade viária: Pulado (camada de área não selecionada)&lt;/i&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="425"/>
        <source>1) Calculando densidade viária...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="433"/>
        <source>   -&gt; &lt;b&gt;Densidade viária:&lt;/b&gt; {value:.4f} km/km²&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="437"/>
        <source>   -&gt; &lt;b&gt;Densidade viária:&lt;/b&gt; N/A (resultado vazio)&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="439"/>
        <source>   -&gt; &lt;span style=&apos;color: #fc8181;&apos;&gt;Erro ao calcular densidade: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="444"/>
        <source>2) Calculando conectividade da rede...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="457"/>
        <source>   -&gt; &lt;b&gt;Número de nós (v):&lt;/b&gt; {v}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="458"/>
        <source>   -&gt; &lt;b&gt;Número de arestas (e):&lt;/b&gt; {e}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="460"/>
        <source>   -&gt; &lt;b&gt;Índice Alfa:&lt;/b&gt; {v:.4f}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="462"/>
        <source>   -&gt; &lt;b&gt;Índice Beta:&lt;/b&gt; {v:.4f}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="464"/>
        <source>   -&gt; &lt;b&gt;Índice Gama:&lt;/b&gt; {v:.4f}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="466"/>
        <source>   -&gt; &lt;b&gt;Cruzamentos 4+ pernas:&lt;/b&gt; {v:.2f}%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="468"/>
        <source>   -&gt; &lt;b&gt;Becos sem saída:&lt;/b&gt; {v:.2f}%&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="470"/>
        <source>   -&gt; &lt;span style=&apos;color: #fc8181;&apos;&gt;Erro ao calcular conectividade: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="475"/>
        <source>3) Calculando circuidade média (amostragem)...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="484"/>
        <source>   -&gt; &lt;b&gt;Circuidade média:&lt;/b&gt; {value:.4f}&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="488"/>
        <source>   -&gt; &lt;b&gt;Circuidade média:&lt;/b&gt; N/A (resultado vazio)&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="490"/>
        <source>   -&gt; &lt;span style=&apos;color: #fc8181;&apos;&gt;Erro ao calcular circuidade: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="531"/>
        <source>   -&gt; &lt;b&gt;Acessibilidade de carga:&lt;/b&gt; {value:.2f}%&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="535"/>
        <source>   -&gt; &lt;b&gt;Acessibilidade de carga:&lt;/b&gt; N/A (resultado vazio)&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="537"/>
        <source>   -&gt; &lt;span style='color: #fc8181;'&gt;Erro ao calcular restrição: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="494"/>
        <source>&lt;b&gt;=== CÁLCULO CONCLUÍDO ===&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="550"/>
        <source>Por favor, informe o código IBGE do município.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="557"/>
        <source>Por favor, informe o campo de população.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="574"/>
        <source>&lt;b&gt;Calculando densidade de demanda...&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="585"/>
        <source>   -&gt; &lt;b&gt;Densidade de demanda:&lt;/b&gt; camada adicionada ao projeto com {count} setor(es).&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="589"/>
        <source>   -&gt; &lt;b&gt;Densidade de demanda:&lt;/b&gt; N/A (resultado vazio)&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="591"/>
        <source>   -&gt; &lt;span style=&apos;color: #fc8181;&apos;&gt;Erro ao calcular densidade de demanda: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="614"/>
        <source>Por favor, selecione uma camada de origem.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="621"/>
        <source>Por favor, selecione uma camada de destinos.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="638"/>
        <source>&lt;b&gt;Calculando acessibilidade gravitacional...&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="654"/>
        <source>   -&gt; &lt;b&gt;Acessibilidade gravitacional:&lt;/b&gt; camada adicionada ao projeto com {count} origem(ns).&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="658"/>
        <source>   -&gt; &lt;b&gt;Acessibilidade gravitacional:&lt;/b&gt; N/A (resultado vazio)&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="660"/>
        <source>   -&gt; &lt;span style=&apos;color: #fc8181;&apos;&gt;Erro ao calcular acessibilidade gravitacional: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="692"/>
        <source>&lt;b&gt;Calculando centralidade de intermediação...&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="706"/>
        <source>   -&gt; &lt;b&gt;Centralidade de intermediação:&lt;/b&gt; camada adicionada ao projeto com {count} aresta(s).&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="710"/>
        <source>   -&gt; &lt;b&gt;Centralidade de intermediação:&lt;/b&gt; N/A (resultado vazio)&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="712"/>
        <source>   -&gt; &lt;span style='color: #fc8181;'&gt;Erro ao calcular centralidade de intermediação: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="734"/>
        <source>Por favor, selecione uma camada de depósitos candidatos.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="741"/>
        <source>Por favor, selecione uma camada de zonas/centroides.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="758"/>
        <source>&lt;b&gt;Calculando distância de entrega...&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="771"/>
        <source>   -&gt; &lt;b&gt;Distância de entrega:&lt;/b&gt; camada adicionada ao projeto com {count} zona(s).&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="775"/>
        <source>   -&gt; &lt;b&gt;Distância de entrega:&lt;/b&gt; N/A (resultado vazio)&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="777"/>
        <source>   -&gt; &lt;span style='color: #fc8181;'&gt;Erro ao calcular distância de entrega: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="251"/>
        <source>Rede</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="289"/>
        <source>Demanda</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="342"/>
        <source>Carga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="345"/>
        <source>&lt;b&gt;Restrição de Circulação de Carga&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="349"/>
        <source>Expressão de restrição (opcional, ex: maxweight / highway):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="351"/>
        <source>Ex: &quot;highway&quot; = &apos;residential&apos; OR &quot;maxweight&quot; &lt; 3.5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="356"/>
        <source>Calcular Restrição de Carga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="523"/>
        <source>&lt;b&gt;Calculando restrição de circulação de carga...&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="221"/>
        <source>A camada de rede viária escolhida abaixo vale para as três abas (Rede, Demanda, Carga); cada aba tem seu próprio botão de cálculo.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="232"/>
        <source>Camada de rede viária (Linhas) — usada por todas as abas:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="276"/>
        <source>Semente da amostragem (opcional, 0 = aleatório):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="279"/>
        <source>Aleatória</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UrbanEdgeBetweenness</name>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="57"/>
        <source>Camada de rede viária (Linhas)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="64"/>
        <source>Número de amostras (pares OD)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="73"/>
        <source>Semente aleatória (opcional, para reprodutibilidade)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="80"/>
        <source>Arestas com centralidade de intermediação</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="96"/>
        <source>Camada de rede viária inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="98"/>
        <source>Construindo o grafo a partir da rede viária...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="102"/>
        <source>Erro ao construir o grafo: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="108"/>
        <source>O grafo construído está vazio.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="110"/>
        <source>Grafo construído: {v} vértices, {e} arestas.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="116"/>
        <source>Amostrando pares OD e calculando a centralidade de intermediação...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="132"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="147"/>
        <source>Centralidade de intermediação máxima observada: {max_score:.4f}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="160"/>
        <source>Centralidade de Intermediação de Arestas (Betweenness)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="163"/>
        <source>Indicadores Urbanos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="169"/>
        <source>Calcula a centralidade de intermediação (betweenness) aproximada de cada aresta de uma rede viária urbana, por amostragem de pares origem-destino e caminhos mínimos de Dijkstra.

Parâmetros:
- Camada de rede viária: feições de linha representando as vias.
- Número de amostras (pares OD): número de pares a amostrar (default 1000).
- Semente aleatória: opcional, para reprodutibilidade da amostragem.

Retorno:
- Camada de linhas com o campo 'betweenness' (0.0 a 1.0), uma feição por aresta do grafo.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UrbanGravityAccessibility</name>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="57"/>
        <source>Camada de rede viária (Linhas)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="64"/>
        <source>Camada de origem (pontos/centroides)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="71"/>
        <source>Camada de destinos (POIs)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="78"/>
        <source>Campo de peso/atratividade do destino (opcional, default 1 para todos)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="87"/>
        <source>Parâmetro de decaimento por distância (beta)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="96"/>
        <source>Origem com acessibilidade gravitacional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="111"/>
        <source>Camada de rede viária inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="113"/>
        <source>Camada de origem inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="115"/>
        <source>Camada de destinos inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="125"/>
        <source>Lendo origens...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="134"/>
        <source>Nenhuma origem válida encontrada na camada de origem.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="137"/>
        <source>Lendo destinos e pesos...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="153"/>
        <source>Nenhum destino válido encontrado na camada de destinos.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="156"/>
        <source>Construindo o grafo a partir da rede viária...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="161"/>
        <source>Erro ao construir o grafo: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="167"/>
        <source>O grafo construído possui menos de 2 vértices. Não é possível calcular a acessibilidade.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="178"/>
        <source>Não foi possível amarrar uma ou mais origens à rede viária.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="180"/>
        <source>Não foi possível amarrar um ou mais destinos à rede viária.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="183"/>
        <source>Calculando matriz de distâncias origem-destino...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="190"/>
        <source>Erro ao calcular a matriz OD: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="207"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="215"/>
        <source>Acessibilidade gravitacional calculada para {count} origem(ns).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="226"/>
        <source>Acessibilidade Gravitacional Urbana</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="229"/>
        <source>Indicadores Urbanos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="235"/>
        <source>Calcula a acessibilidade gravitacional de cada origem (ex.: centroides de setor) a uma camada de destinos ponderados (ex.: POIs, comércio, empregos), usando caminhos mínimos sobre a rede viária urbana.

Parâmetros:
- Camada de rede viária: feições de linha representando as vias.
- Camada de origem: feições de ponto (ex.: centroides de setor, saída do indicador de densidade de demanda).
- Camada de destinos (POIs): feições de ponto com os destinos.
- Campo de peso/atratividade do destino: campo numérico opcional (default 1 para todos os destinos).
- Beta: parâmetro de decaimento por distância do modelo gravitacional (default 2.0).

Retorno:
- Cópia da camada de origem com o campo 'acess_gravit' (índice de acessibilidade gravitacional).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="127"/>
        <source>camada de origem</source>
        <translation>camada de origem</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="139"/>
        <source>camada de destinos</source>
        <translation>camada de destinos</translation>
    </message>
</context>
<context>
    <name>UrbanMeanCircuity</name>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="51"/>
        <source>Camada de rede viária (Linhas)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="58"/>
        <source>Número de amostras (pares OD)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="67"/>
        <source>Distância euclidiana mínima (metros)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="76"/>
        <source>Circuidade média</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="89"/>
        <source>Camada de rede viária inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="91"/>
        <source>Construindo o grafo a partir da rede viária...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="95"/>
        <source>Erro ao construir o grafo: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="101"/>
        <source>O grafo construído possui menos de 2 vértices. Não é possível calcular a circuidade.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="105"/>
        <source>Grafo construído: {v} vértices, {e} arestas.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="111"/>
        <source>Amostrando pares de pontos para o cálculo da circuidade...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="169"/>
        <source>Não foi possível encontrar nenhum par de pontos válido que satisfaça a distância mínima de {min_dist} metros.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="176"/>
        <source>Calculando circuidade média com {count} amostras válidas...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="187"/>
        <source>Circuidade média calculada: {circuity:.4f}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="196"/>
        <source>Circuidade Média de Rede Viária Urbana</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="199"/>
        <source>Indicadores Urbanos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="205"/>
        <source>Calcula a circuidade média de uma rede viária urbana a partir de amostras de caminhos mínimos.

Parâmetros:
- Camada de rede viária: feições de linha representando as vias.
- Número de amostras (pares OD): número de caminhos a amostrar (default 1000).
- Distância euclidiana mínima: distância mínima em metros entre origem e destino (default 100m).

Retorno:
- Valor numérico contendo a circuidade média (distância rede / distância euclidiana).</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UrbanNetworkConnectivity</name>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="47"/>
        <source>Camada de rede viária (Linhas)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="54"/>
        <source>Número de nós (v)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="60"/>
        <source>Número de arestas (e)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="66"/>
        <source>Índice Alfa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="72"/>
        <source>Índice Beta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="78"/>
        <source>Índice Gama</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="84"/>
        <source>Percentual de interseções com grau 4 ou mais</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="90"/>
        <source>Percentual de becos sem saída</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="101"/>
        <source>Camada de rede viária inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="103"/>
        <source>Construindo o grafo a partir da rede viária...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="108"/>
        <source>Erro ao construir o grafo: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="113"/>
        <source>O grafo construído não possui vértices.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="116"/>
        <source>Calculando os graus dos nós...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="140"/>
        <source>Calculando os indicadores de conectividade...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="147"/>
        <source>Nós (v): {v} | Arestas (e): {e}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="150"/>
        <source>Índices: Alfa={alpha:.4f} | Beta={beta:.4f} | Gama={gamma:.4f}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="155"/>
        <source>Interseções 4+ pernas: {pct_4:.2f}% | Becos sem saída: {pct_dead:.2f}%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="177"/>
        <source>Conectividade de Rede Viária Urbana</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="180"/>
        <source>Indicadores Urbanos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="186"/>
        <source>Calcula indicadores de conectividade para uma rede viária urbana a partir dos graus de seus nós.

Parâmetros:
- Camada de rede viária: feições de linha representando as vias.

Retornos:
- Número de nós (v)
- Número de arestas (e)
- Índice Alfa (0 a 1)
- Índice Beta (links por nó)
- Índice Gama (0 a 1)
- Percentual de interseções com grau 4 ou mais (cruzamentos de 4 pernas)
- Percentual de becos sem saída (grau 1)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UrbanNetworkDensity</name>
    <message>
        <location filename="../algorithms/urban_network_density.py" line="42"/>
        <source>Camada de rede viária (Linhas)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_density.py" line="49"/>
        <source>Camada de área de referência (Polígonos)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_density.py" line="56"/>
        <source>Densidade da rede viária (km/km²)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_density.py" line="68"/>
        <source>Camada de rede viária inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_density.py" line="70"/>
        <source>Camada de área de referência inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_density.py" line="79"/>
        <source>Calculando a extensão total da rede viária...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_density.py" line="96"/>
        <source>Calculando a área total do polígono de referência...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_density.py" line="111"/>
        <source>A área calculada é de 0 km² ou negativa. Verifique a geometria de referência.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_density.py" line="121"/>
        <source>Comprimento da Rede: {length:.2f} m | Área: {area:.4f} km²</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_density.py" line="126"/>
        <source>Densidade Calculada: {density:.4f} km/km²</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_density.py" line="136"/>
        <source>Densidade de Rede Viária Urbana</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_density.py" line="139"/>
        <source>Indicadores Urbanos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_density.py" line="145"/>
        <source>Calcula a densidade da rede viária em km de via por km² de área de referência.

Parâmetros:
- Camada de rede viária: feições de linha representando as vias.
- Camada de área de referência: feições de polígono definindo a área territorial.

Retorno:
- Valor numérico contendo a densidade em km/km².</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VrpCvrp</name>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="180"/>
        <source>Camada de depósito (Pontos/Polígonos)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="196"/>
        <source>Camada de demanda / clientes (Pontos/Polígonos)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="212"/>
        <source>Campo de peso/demanda (opcional, default=1.0)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="221"/>
        <source>Capacidade do veículo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="230"/>
        <source>Camada de rede viária (Linhas) (opcional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="238"/>
        <source>Aplicar busca local (2-opt e Or-opt)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="257"/>
        <source>Rotas geradas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="263"/>
        <source>Paradas por rota (opcional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="296"/>
        <source>Camada de depósito inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="298"/>
        <source>Camada de demanda inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="300"/>
        <source>A capacidade do veículo deve ser estritamente maior que zero.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="317"/>
        <source>Nenhum ponto de depósito válido encontrado.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="325"/>
        <source>Lendo pontos de demanda...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="359"/>
        <source>A demanda do nó excede a capacidade máxima do veículo ({weight} &gt; {cap}).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="388"/>
        <source>Nenhum ponto de demanda válido encontrado.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="510"/>
        <source>Construindo o grafo e calculando a matriz OD na rede...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="544"/>
        <source>Erro ao construir o grafo: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="551"/>
        <source>O grafo construído possui menos de 2 vértices.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="570"/>
        <source>Erro ao calcular a matriz OD: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="575"/>
        <source>Calculando matriz de distâncias euclidianas...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="802"/>
        <source>Roteirização de Veículos Capacitados (CVRP)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="805"/>
        <source>Roteirização</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="245"/>
        <source>Backend de otimização</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="245"/>
        <source>Automático (OR-Tools quando disponível)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="245"/>
        <source>Python puro (heurística)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="245"/>
        <source>OR-Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="324"/>
        <source>Lendo pontos de demanda…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="536"/>
        <source>Janela de análise: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="540"/>
        <source>Construindo o grafo…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="558"/>
        <source>Calculando a matriz OD…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="574"/>
        <source>Calculando matriz de distâncias euclidianas…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="590"/>
        <source>Otimizando (OR-Tools)…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="592"/>
        <source>Otimizando (heurística Python)…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="600"/>
        <source>Executando a otimização CVRP...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="619"/>
        <source>Roteirização concluída. Rotas geradas: {count} | Backend: {backend} | Distância Total: {dist:.2f}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="626"/>
        <source>Gravando as saídas…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="391"/>
        <source>depósito</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="392"/>
        <source>demanda</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="400"/>
        <source>SRC da rede: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="485"/>
        <source>SRC de depósito: {} → {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="486"/>
        <source>SRC de demanda: {} → {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="523"/>
        <source>Janela de análise calculada a partir dos pontos é inválida: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="530"/>
        <source>Os pontos ({}) não caem na área da rede viária (rede em {}) — confira o SRC das camadas.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="478"/>
        <source>Transformação {src} → {dst} ok (prova ({x1:.4f}, {y1:.4f}) → ({x2:.4f}, {y2:.4f}))</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="465"/>
        <source>Transformação para EPSG:5880 falhou ({exc}) — adotando fallback para {utm_auth}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="463"/>
        <source>Transformação para UTM ({utm}) falhou: {exc}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="462"/>
        <source>Transformação de coordenadas falhou: {exc}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="283"/>
        <source>Campo de ID do depósito (opcional)</source>
        <translation>Campo de ID do depósito (opcional)</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="283"/>
        <source>Campo do depósito de cada ponto (opcional)</source>
        <translation>Campo do depósito de cada ponto (opcional)</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="283"/>
        <source>O parâmetro '{param1}' não pode ser preenchido sem o '{param2}'.</source>
        <translation>O parâmetro '{param1}' não pode ser preenchido sem o '{param2}'.</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="320"/>
        <source>ID de depósito repetido na camada de depósito.</source>
        <translation>ID de depósito repetido na camada de depósito.</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="371"/>
        <source>O valor '{val}' no campo de depósito da demanda não existe na camada de depósitos. IDs válidos: {ids}</source>
        <translation>O valor '{val}' no campo de depósito da demanda não existe na camada de depósitos. IDs válidos: {ids}</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="383"/>
        <source>{count} ponto(s) de demanda com o campo de depósito vazio; serão alocados ao depósito mais próximo.</source>
        <translation>{count} ponto(s) de demanda com o campo de depósito vazio; serão alocados ao depósito mais próximo.</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="788"/>
        <source>Depósito {did}: {count} rota(s), carga {load:.2f}</source>
        <translation>Depósito {did}: {count} rota(s), carga {load:.2f}</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="811"/>
        <source>Resolve o Problema de Roteirização de Veículos Capacitados (CVRP) a partir de uma ou mais feições de depósito e uma camada de pontos de demanda (clientes).

Limitação (agrupa primeiro, roteiriza depois): os pontos são alocados aos depósitos antes da roteirização (Gillett &amp; Johnson, 1976) e nunca trocam de depósito, sendo uma solução boa, não ótima. Se o campo de depósito da demanda for vazio, o cliente é alocado ao depósito mais próximo.

Constroi rotas que iniciam e terminam no depósito, respeitando a capacidade máxima do veículo, utilizando a heurística de economias de Clarke &amp; Wright (1964) e refinamento opcional por busca local 2-opt (Lin, 1965) e Or-opt (Or, 1976).

Parâmetros:
- Camada de depósito: feição(ões) de ponto/polígono representando o(s) depósito(s).
- Campo de ID do depósito: campo que identifica cada depósito (opcional).
- Camada de demanda / clientes: feições de pontos ou polígonos com demandas a atender.
- Campo do depósito de cada ponto: indica qual depósito atende o cliente (opcional).
- Campo de peso/demanda: campo numérico da demanda de cada cliente (opcional, default=1.0).
- Capacidade do veículo: carga máxima transportada por cada veículo em uma rota.
- Camada de rede viária: rede viária para distâncias reais (opcional, usa distância euclidiana se omitida).
- Aplicar busca local: se verdadeiro, aplica 2-opt e Or-opt para otimização de cada rota.
- Backend de otimização: qual motor usar (Automático/Python/OR-Tools).

Saídas:
- Rotas geradas: camada de linhas com a geometria das rotas e estatísticas de carga e distância.
- Paradas por rota: camada de pontos ordenada com atribuição de rota e carga acumulada.</source>
        <translation>Resolve o Problema de Roteirização de Veículos Capacitados (CVRP) a partir de uma ou mais feições de depósito e uma camada de pontos de demanda (clientes).

Limitação (agrupa primeiro, roteiriza depois): os pontos são alocados aos depósitos antes da roteirização (Gillett &amp; Johnson, 1976) e nunca trocam de depósito, sendo uma solução boa, não ótima. Se o campo de depósito da demanda for vazio, o cliente é alocado ao depósito mais próximo.

Constroi rotas que iniciam e terminam no depósito, respeitando a capacidade máxima do veículo, utilizando a heurística de economias de Clarke &amp; Wright (1964) e refinamento opcional por busca local 2-opt (Lin, 1965) e Or-opt (Or, 1976).

Parâmetros:
- Camada de depósito: feição(ões) de ponto/polígono representando o(s) depósito(s).
- Campo de ID do depósito: campo que identifica cada depósito (opcional).
- Camada de demanda / clientes: feições de pontos ou polígonos com demandas a atender.
- Campo do depósito de cada ponto: indica qual depósito atende o cliente (opcional).
- Campo de peso/demanda: campo numérico da demanda de cada cliente (opcional, default=1.0).
- Capacidade do veículo: carga máxima transportada por cada veículo em uma rota.
- Camada de rede viária: rede viária para distâncias reais (opcional, usa distância euclidiana se omitida).
- Aplicar busca local: se verdadeiro, aplica 2-opt e Or-opt para otimização de cada rota.
- Backend de otimização: qual motor usar (Automático/Python/OR-Tools).

Saídas:
- Rotas geradas: camada de linhas com a geometria das rotas e estatísticas de carga e distância.
- Paradas por rota: camada de pontos ordenada com atribuição de rota e carga acumulada.</translation>
    </message>
</context>
<context>
    <name>VrpTsp</name>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="176"/>
        <source>Camada do ponto inicial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="183"/>
        <source>Camada de pontos a visitar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="190"/>
        <source>Camada do ponto final (opcional; vazia = a rota fecha no ponto inicial)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="198"/>
        <source>Camada de rede viária (Linhas) (opcional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="206"/>
        <source>Aplicar busca local (2-opt e Or-opt)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="225"/>
        <source>Ordem de visita</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="231"/>
        <source>Rota (trechos)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="255"/>
        <source>Camada do ponto inicial inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="257"/>
        <source>Camada de pontos a visitar inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="268"/>
        <source>Nenhum ponto inicial válido encontrado.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="274"/>
        <source>Lendo pontos a visitar...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="292"/>
        <source>A camada de pontos a visitar está vazia.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="304"/>
        <source>Nenhum ponto final válido encontrado na camada fornecida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="435"/>
        <source>Construindo o grafo e calculando a matriz OD na rede...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="469"/>
        <source>Erro ao construir o grafo: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="477"/>
        <source>O grafo construído possui menos de 2 vértices.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="502"/>
        <source>Erro ao calcular a matriz OD: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="521"/>
        <source>Calculando matriz de distâncias euclidianas...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="546"/>
        <source>Executando a otimização TSP...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="788"/>
        <source>Caixeiro Viajante (TSP)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="791"/>
        <source>Roteirização</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="213"/>
        <source>Backend de otimização</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="213"/>
        <source>Automático (OR-Tools quando disponível)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="213"/>
        <source>Python puro (heurística)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="213"/>
        <source>OR-Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="273"/>
        <source>Lendo pontos a visitar…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="461"/>
        <source>Janela de análise: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="465"/>
        <source>Construindo o grafo…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="482"/>
        <source>Não foi possível amarrar um ou mais pontos à rede viária. Verifique se os pontos estão próximos da malha e no mesmo território dela.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="490"/>
        <source>Calculando a matriz OD…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="512"/>
        <source>A rede viária possui {} par(es) de pontos sem caminho entre si. Verifique se a rede está desconectada.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="520"/>
        <source>Calculando matriz de distâncias euclidianas…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="536"/>
        <source>Otimizando (OR-Tools)…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="538"/>
        <source>Otimizando (heurística Python)…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="562"/>
        <source>Otimização TSP concluída. Pontos: {count} | Modo: {dist_mode} | Backend: {backend} | Distância Total: {dist:.2f}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="569"/>
        <source>Gravando as saídas…</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="797"/>
        <source>Resolve o Problema do Caixeiro Viajante (TSP) a partir de um ponto inicial, uma camada de pontos a visitar e, opcionalmente, um ponto final ou rede viária.

Determina a sequência de visita de menor distância total utilizando as heurísticas do Vizinho Mais Próximo (Flood, 1956) com refinamento opcional por busca local 2-opt (Lin, 1965) e Or-opt (Or, 1976), ou o solver de programação por restrições do Google OR-Tools.

Parâmetros:
- Camada do ponto inicial: feição de ponto/polígono do local de partida.
- Camada de pontos a visitar: feições de pontos/polígonos a serem visitadas.
- Camada do ponto final (opcional): feição do ponto de chegada (se omitida ou vazia, a rota fecha no ponto inicial).
- Camada de rede viária: rede viária para distâncias reais (opcional, usa distância euclidiana se omitida).
- Aplicar busca local: se verdadeiro, aplica 2-opt e Or-opt para otimização da rota.
- Backend de otimização: escolha do solver ('Automático (OR-Tools quando disponível)', 'Python puro (heurística)' ou 'OR-Tools'). O modo 'Python puro' é o modo seguro quando o QGIS fecha ao rodar a rota.

Saídas:
- Ordem de visita: camada de pontos ordenada com a ordem de visita na tabela de atributos em 'visit_seq', nó ('node_role'), papel da perna ('leg_role'), distância da perna ('leg_dist') e distância acumulada ('cum_dist').
- Rota (trechos): camada de linhas com a geometria das pernas da rota classificadas ('leg_role': 'acesso', 'rota', 'retorno'). Os trechos 'acesso' e 'retorno' da camada de rota são os deslocamentos improdutivos (do ponto inicial ao primeiro ponto a visitar e do último ao ponto final), somados em 'access_dist' e 'return_dist', com os totais de distância ('tour_dist', 'service_dist') e a taxa improdutiva ('dead_ratio') repetidos em todas as feições, além do modo de cálculo ('dist_mode') e da geometria do trecho ('leg_geom').</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="307"/>
        <source>ponto inicial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="308"/>
        <source>pontos a visitar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="311"/>
        <source>ponto final</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="319"/>
        <source>SRC da rede: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="409"/>
        <source>SRC de ponto inicial: {} → {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="410"/>
        <source>SRC de pontos a visitar: {} → {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="412"/>
        <source>SRC de ponto final: {} → {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="448"/>
        <source>Janela de análise calculada a partir dos pontos é inválida: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="455"/>
        <source>Os pontos ({}) não caem na área da rede viária (rede em {}) — confira o SRC das camadas.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="402"/>
        <source>Transformação {src} → {dst} ok (prova ({x1:.4f}, {y1:.4f}) → ({x2:.4f}, {y2:.4f}))</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="387"/>
        <source>Transformação para EPSG:5880 falhou ({exc}) — adotando fallback para {utm_auth}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="385"/>
        <source>Transformação para UTM ({utm}) falhou: {exc}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="384"/>
        <source>Transformação de coordenadas falhou: {exc}</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WasteCarpRoute</name>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="102"/>
        <source>Camada de vias</source>
        <translation type="unfinished">Camada de vias</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="109"/>
        <source>Campo de geração/demanda de resíduos (kg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="118"/>
        <source>Campo de via obrigatória para coleta (opcional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="126"/>
        <source>Campo de setor de coleta (opcional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="134"/>
        <source>Capacidade do veículo (em toneladas ou kg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="143"/>
        <source>Camada de ponto do depósito/aterro (exatamente 1 feição)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="159"/>
        <source>Vias com rota de coleta (CARP)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="176"/>
        <source>Camada de vias inválida.</source>
        <translation type="unfinished">Camada de vias inválida.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="178"/>
        <source>A capacidade do veículo deve ser maior que zero.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="196"/>
        <source>Lendo trechos de via...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="259"/>
        <source>Demanda do trecho '{fid}' ({dem:.2f}) excede a capacidade do veículo ({cap:.2f}).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="278"/>
        <source>{count} trecho(s) com geometria inválida foram ignorados.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="285"/>
        <source>Nenhum trecho de via válido encontrado na camada de entrada.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="293"/>
        <source>Camada de depósito inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="303"/>
        <source>A camada de ponto do depósito deve conter exatamente 1 feição (encontradas {count}).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="327"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="338"/>
        <source>Setor '{sec}': nenhum trecho de coleta obrigatória. Ignorando setor.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="358"/>
        <source>Calculando rotas CARP para o setor '{sec}' ({req_count} trechos obrigatórios)...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="372"/>
        <source>Erro ao calcular rotas CARP para o setor &apos;{sec}&apos;: {err}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="378"/>
        <source>Setor &apos;{sec}&apos;: {count} rota(s)/viagem(ns) gerada(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="398"/>
        <source>Setor &apos;{sec}&apos;, rota {idx}: carga {load:.2f} kg, {dh_km:.2f} km de deadhead.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="404"/>
        <source>Aviso: rota {idx} do setor &apos;{sec}&apos; usa menos de 50% da capacidade ({load:.2f} kg de {cap:.2f} kg).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="440"/>
        <source>Roteirização por Arcos Capacitada (CARP)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="443"/>
        <source>Logística Especializada — Coleta de Lixo</source>
        <translation type="unfinished">Logística Especializada — Coleta de Lixo</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="449"/>
        <source>Calcula rotas de veículos capacitados para coleta de lixo por arcos usando o Problema de Roteirização por Arcos Capacitada (Capacitated Arc Routing Problem - CARP) com a heurística Path-Scanning (Golden et al., 1983).

Parâmetros:
- Camada de vias: feições de linha com a malha viária.
- Campo de demanda de resíduos (obrigatório): campo numérico com a geração em cada trecho, em kg.
- Campo de via obrigatória (opcional): campo indicando trechos com coleta obrigatória; se omitido, todos os trechos são obrigatórios.
- Campo de setor de coleta (opcional): se informado, resolve o CARP separadamente por setor.
- Capacidade do veículo: capacidade máxima de carga por veículo, em kg.
- Camada de depósito/aterro: feição de ponto com a localização do aterro/depósito/garagem (exatamente 1 feição). O depósito é snapado ao vértice de via mais próximo por distância euclidiana — aproximação heurística, não uma projeção exata sobre a rede.
- Tolerância de nó: distância em metros para conectar vértices das vias.

Um trecho isolado com demanda maior que a capacidade do veículo gera erro explícito em vez de ser dividido entre mais de uma viagem (sem split-delivery).

Retorno:
- Camada de linha com feições de vias e campos adicionais: 'route_id' (identificador da rota/viagem dentro do setor), 'route_visit_order' (ordem de visita na rota), 'route_sector_id' (setor de coleta), 'route_is_deadhead' (booleano indicando passagem duplicada/deslocamento deadhead), 'route_load_kg' (carga total da rota em kg) e 'route_distance_km' (distância total da rota em km).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="150"/>
        <source>Tolerância de nó (m)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="203"/>
        <source>camada de vias</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="296"/>
        <source>camada de depósito</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WasteCollectionCoverage</name>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="72"/>
        <source>Camada de vias exigidas (faixa de frequência)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="79"/>
        <source>Campo de setor da camada de vias exigidas (opcional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="87"/>
        <source>Camada de rota coberta (vias percorridas)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="94"/>
        <source>Campo indicador de deadhead/conector (opcional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="104"/>
        <source>Campo de setor da camada de rota coberta (opcional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="112"/>
        <source>Rótulo de frequência de coleta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="120"/>
        <source>Tabela de cobertura por setor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="136"/>
        <source>Camada de vias exigidas inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="138"/>
        <source>Camada de rota coberta inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="156"/>
        <source>Calculando extensão exigida por setor...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="182"/>
        <source>Calculando extensão coberta por setor...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="214"/>
        <source>Nenhum trecho válido encontrado nas camadas de entrada.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="234"/>
        <source>Erro ao calcular a cobertura da coleta: {err}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="258"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="275"/>
        <source>Setor &apos;{sid}&apos;: {req:.2f} km exigidos | {cov:.2f} km cobertos | Cobertura: {pct}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="287"/>
        <source>Aviso: Setor &apos;{sid}&apos; possui cobertura baixa ({pct:.1f}% &lt; 80.0%).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="326"/>
        <source>Total geral: {req:.2f} km exigidos | {cov:.2f} km cobertos | Cobertura total: {pct}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="343"/>
        <source>Cobertura da Coleta de Resíduos por Setor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="346"/>
        <source>Logística Especializada — Coleta de Lixo</source>
        <translation type="unfinished">Logística Especializada — Coleta de Lixo</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="352"/>
        <source>Calcula a extensão de via exigida (required_km), extensão efetivamente coberta por rotas de coleta (covered_km) e a taxa de cobertura (coverage_pct) por setor e no total acumulado.

Parâmetros:
- Camada de vias exigidas (faixa de frequência): feições de linha com as vias exigidas.
- Campo de setor da camada de vias exigidas (opcional): campo com o identificador do setor.
- Camada de rota coberta (vias percorridas): feições de linha (ex.: saídas de logis:waste_cpp_route, logis:waste_rpp_route ou logis:waste_carp_route).
- Campo indicador de deadhead/conector (opcional): campo booleano onde True indica trecho improdutivo (default: 'route_is_deadhead'). Trechos improdutivos são desconsiderados da cobertura.
- Campo de setor da camada de rota coberta (opcional): campo de setor na camada de rota.
- Rótulo de frequência de coleta: rótulo textual de frequência (ex.: 'Diária', '3x/semana').

Retorno:
- Tabela sem geometria com uma feição por setor: 'sector_id', 'frequency_label', 'required_km', 'covered_km' e 'coverage_pct'. Quando há mais de um setor, uma feição adicional com 'sector_id' nulo traz o total acumulado.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WasteCppRoute</name>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="94"/>
        <source>Camada de vias</source>
        <translation type="unfinished">Camada de vias</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="101"/>
        <source>Campo de setor de coleta (opcional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="118"/>
        <source>Vias com rota de coleta (CPP)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="131"/>
        <source>Camada de vias inválida.</source>
        <translation type="unfinished">Camada de vias inválida.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="139"/>
        <source>Lendo trechos de via e agrupando por setor...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="195"/>
        <source>{count} trecho(s) com geometria inválida foram ignorados.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="202"/>
        <source>Nenhum trecho de via válido encontrado na camada de entrada.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="220"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="229"/>
        <source>Calculando rota CPP para o setor &apos;{sec}&apos; com {count} trecho(s)...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="241"/>
        <source>Erro ao calcular rota CPP para o setor &apos;{sec}&apos;: {err}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="251"/>
        <source>Setor &apos;{sec}&apos;: {dup} trecho(s) duplicado(s) (deadhead), {km:.2f} km improdutivos.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="281"/>
        <source>Roteirização por Arcos (CPP)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="284"/>
        <source>Logística Especializada — Coleta de Lixo</source>
        <translation type="unfinished">Logística Especializada — Coleta de Lixo</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="290"/>
        <source>Calcula a sequência de percurso para coleta de lixo por arcos usando o Problema do Carteiro Chinês (Chinese Postman Problem - CPP).

Parâmetros:
- Camada de vias: feições de linha a serem percorridas.
- Campo de setor de coleta (opcional): se informado, o CPP é resolvido separadamente para cada setor de coleta; se omitido, toda a camada é tratada como um único setor.
- Tolerância de nó: distância em metros para conectar vértices das vias.

Retorno:
- Camada de linha com feições duplicadas nos trechos de deadhead e campos adicionais: 'route_visit_order' (posição sequencial no circuito), 'route_sector_id' (setor de coleta) e 'route_is_deadhead' (booleano indicando passagem duplicada/deadhead).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="109"/>
        <source>Tolerância de nó (m)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="146"/>
        <source>camada de vias</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WasteDeadheadRatio</name>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="68"/>
        <source>Camada de rotas/vias de coleta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="75"/>
        <source>Campo indicador de deadhead/improdutivo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="85"/>
        <source>Campo de identificação da rota/setor (opcional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="93"/>
        <source>Razão de deadhead por rota</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="106"/>
        <source>Camada de rotas de coleta inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="110"/>
        <source>Campo indicador de deadhead inválido.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="118"/>
        <source>Lendo feições da camada e calculando comprimentos...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="147"/>
        <source>Nenhum trecho válido encontrado na camada de entrada.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="158"/>
        <source>Erro ao calcular a razão de deadhead: {err}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="178"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="193"/>
        <source>Rota '{rid}': {prod:.2f} km produtivos | {dh:.2f} km deadhead | Razão: {ratio}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="218"/>
        <source>Total acumulado de todas as rotas: {prod:.2f} km produtivos | {dh:.2f} km deadhead | Razão total: {ratio}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="245"/>
        <source>Razão de Deadhead por Rota</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="248"/>
        <source>Logística Especializada — Coleta de Lixo</source>
        <translation type="unfinished">Logística Especializada — Coleta de Lixo</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="254"/>
        <source>Calcula a extensão de deslocamento produtivo (coleta), improdutivo (deadhead/conector) e a razão de deadhead (deadhead_km / productive_km) para cada rota de coleta e no total.

Parâmetros:
- Camada de rotas/vias de coleta: feições de linha (ex.: saídas de logis:waste_cpp_route, logis:waste_rpp_route ou logis:waste_carp_route).
- Campo indicador de deadhead (obrigatório): campo booleano onde True indica trecho de deadhead/deslocamento improdutivo (default: 'route_is_deadhead').
- Campo de identificação da rota/setor (opcional): se informado, calcula a razão separadamente para cada rota/setor; se omitido, calcula para a camada inteira.

Retorno:
- Tabela sem geometria com uma feição por rota: 'route_id', 'productive_km' (extensão de coleta), 'deadhead_km' (extensão improdutiva) e 'deadhead_ratio' (razão deadhead_km / productive_km). Quando há mais de uma rota, uma feição adicional com 'route_id' nulo traz o total agregado de todas as rotas.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WasteDestinationDistance</name>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="73"/>
        <source>Camada de rede viária (Linhas)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="80"/>
        <source>Camada de destinos de resíduos - aterro/transbordo/ecoponto (Pontos)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="87"/>
        <source>Camada de setores/origens de coleta (Pontos ou Polígonos)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="94"/>
        <source>Critério de custo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="94"/>
        <source>Distância</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="94"/>
        <source>Tempo de viagem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="102"/>
        <source>Setores de coleta com distância ao destino</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="116"/>
        <source>Camada de rede viária inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="118"/>
        <source>Camada de destinos de resíduos inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="120"/>
        <source>Camada de setores/origens inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="126"/>
        <source>Lendo pontos de destino (aterros/transbordos/ecopontos)...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="135"/>
        <source>Nenhum ponto de destino válido encontrado.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="138"/>
        <source>Lendo setores/origens de coleta...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="147"/>
        <source>Nenhum setor/origem de coleta válido encontrado.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="150"/>
        <source>Construindo o grafo a partir da rede viária...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="155"/>
        <source>Erro ao construir o grafo: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="161"/>
        <source>O grafo construído possui menos de 2 vértices. Não é possível calcular as distâncias.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="172"/>
        <source>Não foi possível amarrar um ou mais pontos de destino à rede viária.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="174"/>
        <source>Não foi possível amarrar um ou mais setores/origens à rede viária.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="177"/>
        <source>Calculando matriz de distâncias/tempos de viagem destino-setor...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="185"/>
        <source>Erro ao calcular a matriz OD: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="202"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="210"/>
        <source>Distância ao destino de resíduos mais próximo calculada para {count} setor(es).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="221"/>
        <source>Distância ao Destino de Resíduos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="224"/>
        <source>Logística Especializada — Coleta de Lixo</source>
        <translation type="unfinished">Logística Especializada — Coleta de Lixo</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="230"/>
        <source>Calcula a distância ou tempo de viagem ao ponto de destino de resíduos mais próximo (aterro sanitário, estação de transbordo, ecoponto) para cada setor ou centroide de coleta, utilizando caminhos mínimos na rede viária.

Parâmetros:
- Camada de rede viária: feições de linha representando as vias.
- Camada de destinos de resíduos: feições de ponto representando aterros, estações de transbordo ou ecopontos.
- Camada de setores/origens: feições de ponto ou polígono representando os setores de coleta.
- Critério de custo: define se o cálculo de custo de caminho mínimo é baseado em Distância ou Tempo de viagem.

Retorno:
- Cópia da camada de origens com a coluna 'dist_destino' (menor distância em km ou tempo em min até o destino mais próximo).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="128"/>
        <source>camada de destinos de resíduos</source>
        <translation>camada de destinos de resíduos</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="140"/>
        <source>camada de setores/origens</source>
        <translation>camada de setores/origens</translation>
    </message>
</context>
<context>
    <name>WasteDistricting</name>
    <message>
        <location filename="../algorithms/waste_districting.py" line="100"/>
        <source>Camada de vias</source>
        <translation type="unfinished">Camada de vias</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="107"/>
        <source>Campo de carga (opcional, default=comprimento do trecho)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="116"/>
        <source>Número de setores de coleta desejado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="134"/>
        <source>Máximo de iterações de rebalanceamento de fronteira</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="143"/>
        <source>Vias com setor de coleta atribuído</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="158"/>
        <source>Camada de vias inválida.</source>
        <translation type="unfinished">Camada de vias inválida.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="163"/>
        <source>Lendo trechos de via e construindo adjacência...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="207"/>
        <source>{count} trecho(s) com geometria inválida foram ignorados.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="214"/>
        <source>Nenhum trecho de via válido encontrado na camada de entrada.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="217"/>
        <source>O número de setores ({k}) não pode exceder o número de trechos válidos ({n}).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="224"/>
        <source>Selecionando sementes (farthest-first)...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="228"/>
        <source>Crescendo setores a partir das sementes...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="231"/>
        <source>Rebalanceando trechos de fronteira...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="242"/>
        <source>Setorização concluída. Setores: {k} | carga mín={min:.2f} | carga máx={max:.2f} | carga média={avg:.2f}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="258"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="283"/>
        <source>Setorização de Coleta de Resíduos (Districting)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="286"/>
        <source>Logística Especializada — Coleta de Lixo</source>
        <translation type="unfinished">Logística Especializada — Coleta de Lixo</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="125"/>
        <source>Tolerância de nó (m)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="170"/>
        <source>camada de vias</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="292"/>
        <source>Particiona os trechos de uma camada de vias em k setores de coleta contíguos e balanceados por carga (resíduos gerados ou, na ausência do campo, comprimento do trecho).

Usa a heurística de sementes farthest-first (Gonzalez, 1985), seguida de crescimento de regiões a partir das sementes e refinamento local por troca de trechos de fronteira para equilibrar a carga entre setores mantendo contiguidade. A solução é boa, não necessariamente ótima.

Parâmetros:
- Camada de vias: trechos de via (linhas) a setorizar.
- Campo de carga: campo numérico com a carga de cada trecho (opcional; se omitido, usa o comprimento do trecho como proxy de carga).
- Número de setores: quantidade desejada de setores de coleta (k &gt;= 2).
- Tolerância de nó: distância, em metros, usada para considerar dois vértices de extremidade como o mesmo nó da rede. Funciona com qualquer SRC de entrada — a camada é lida já reprojetada para coordenadas métricas quando está em SRC geográfico, e o comprimento de cada trecho é medido de forma elipsoidal, em metros de verdade.
- Máximo de iterações: limite de trocas locais de trechos de fronteira.

Saída:
- Camada de vias com o novo atributo 'collection_sector_id' (ID do setor de coleta).</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WasteDock</name>
    <message>
        <location filename="../gui/waste_dock.py" line="183"/>
        <source>logis — Coleta de Lixo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="216"/>
        <source>&lt;b&gt;Coleta de Lixo&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="220"/>
        <source>Painel para gestão, estimativa de geração, setorização e roteirização por arcos (coleta de lixo urbana).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="237"/>
        <source>&lt;b&gt;Estimativa de Geração&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="242"/>
        <source>Camada de setores censitérios (Polígonos):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="248"/>
        <source>Campo ID do setor (Setores):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="255"/>
        <source>Campo de população (Setores):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="434"/>
        <source>Camada de trechos de via (Linhas):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="277"/>
        <source>Taxa per capita (kg/hab/dia):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="285"/>
        <source>Fração de cobertura (0.0 a 1.0):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="293"/>
        <source>Calcular Estimativa de Geração</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="352"/>
        <source>&lt;b&gt;Roteirização CPP&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="637"/>
        <source>Campo de setor de coleta (opcional):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="479"/>
        <source>Tolerância de nó (m):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="380"/>
        <source>Executar Roteirização CPP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="386"/>
        <source>&lt;b&gt;Roteirização RPP&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="440"/>
        <source>Campo de via obrigatória (opcional):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="423"/>
        <source>Executar Roteirização RPP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="429"/>
        <source>&lt;b&gt;Roteirização CARP&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="449"/>
        <source>Campo de demanda de resíduos (kg):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="456"/>
        <source>Camada de ponto do depósito/aterro (Pontos):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="462"/>
        <source>Capacidade do veículo:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="487"/>
        <source>Executar Roteirização CARP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="498"/>
        <source>&lt;b&gt;Dimensionamento de Frota&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="606"/>
        <source>Camada de rotas de coleta (Linhas):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="509"/>
        <source>Campo ID da rota:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="646"/>
        <source>Velocidade média de coleta (km/h):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="533"/>
        <source>Duração da jornada de trabalho (horas):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="654"/>
        <source>Tempo de descarga por rota (horas):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="662"/>
        <source>Tempo de deslocamento ao destino por rota (horas):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="557"/>
        <source>Executar Dimensionamento de Frota</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="601"/>
        <source>&lt;b&gt;Equilíbrio entre Setores&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="612"/>
        <source>Campo de carga da rota (kg):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="619"/>
        <source>Campo de distância da rota em km (opcional):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="628"/>
        <source>Campo ID da rota (opcional):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="670"/>
        <source>Executar Equilíbrio entre Setores</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="676"/>
        <source>&lt;b&gt;Distância ao Destino&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="681"/>
        <source>Camada de rede viária (Linhas):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="687"/>
        <source>Camada de destinos de resíduos (Pontos):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="693"/>
        <source>Camada de setores/origens de coleta (Pontos ou Polígonos):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="699"/>
        <source>Critério de custo:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="701"/>
        <source>Distância</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="701"/>
        <source>Tempo de viagem</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="705"/>
        <source>Executar Distância ao Destino</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="711"/>
        <source>&lt;b&gt;Cobertura por Frequência&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="716"/>
        <source>Camada de vias exigidas (faixa de frequência) (Linhas):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="722"/>
        <source>Campo de setor da camada de vias exigidas (opcional):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="731"/>
        <source>Camada de rota coberta (Linhas):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="737"/>
        <source>Campo indicador de deadhead/conector (opcional):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="746"/>
        <source>Campo de setor da camada de rota coberta (opcional):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="755"/>
        <source>Rótulo de frequência de coleta:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="760"/>
        <source>Executar Cobertura por Frequência</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="768"/>
        <source>Resultados:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1425"/>
        <source>Aviso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="795"/>
        <source>Por favor, selecione todas as camadas e campos necessários para a estimativa de geração.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1430"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro: Parâmetros incompletos.&lt;/span&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1436"/>
        <source>Erro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1436"/>
        <source>QGIS Processing não está disponível no ambiente atual.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1441"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro: QGIS Processing não disponível.&lt;/span&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="815"/>
        <source>&lt;b&gt;=== CALCULANDO ESTIMATIVA DE GERAÇÃO ===&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="864"/>
        <source>-&gt; &lt;b&gt;Estimativa calculada com sucesso!&lt;/b&gt; (Camada com {count} trechos viários)&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="868"/>
        <source>-&gt; &lt;b&gt;Resultado da estimativa retornou vazio.&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="871"/>
        <source>&lt;span style=&apos;color: #fc8181;&apos;&gt;Erro ao calcular estimativa: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1473"/>
        <source>&lt;b&gt;=== CÁLCULO CONCLUÍDO ===&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="955"/>
        <source>Por favor, selecione a camada de vias para a roteirização CPP.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="975"/>
        <source>&lt;b&gt;=== EXECUTANDO ROTEIRIZAÇÃO CPP ===&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="992"/>
        <source>-&gt; &lt;b&gt;Roteirização CPP concluída com sucesso!&lt;/b&gt; (Camada com {count} trechos viários)&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1130"/>
        <source>-&gt; &lt;b&gt;Resultado da roteirização retornou vazio.&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="999"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro ao executar roteirização CPP: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1137"/>
        <source>&lt;b&gt;=== ROTEIRIZAÇÃO CONCLUÍDA ===&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1018"/>
        <source>Por favor, selecione a camada de vias para a roteirização RPP.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1038"/>
        <source>&lt;b&gt;=== EXECUTANDO ROTEIRIZAÇÃO RPP ===&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1056"/>
        <source>-&gt; &lt;b&gt;Roteirização RPP concluída com sucesso!&lt;/b&gt; (Camada com {count} trechos viários)&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1063"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro ao executar roteirização RPP: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1085"/>
        <source>Por favor, selecione a camada de vias, o campo de demanda e a camada do depósito para a roteirização CARP.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1105"/>
        <source>&lt;b&gt;=== EXECUTANDO ROTEIRIZAÇÃO CARP ===&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1126"/>
        <source>-&gt; &lt;b&gt;Roteirização CARP concluída com sucesso!&lt;/b&gt; (Camada com {count} trechos viários)&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1133"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro ao executar roteirização CARP: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1155"/>
        <source>Por favor, selecione a camada de rotas e o campo ID da rota para o dimensionamento de frota.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1175"/>
        <source>&lt;b&gt;=== EXECUTANDO DIMENSIONAMENTO DE FROTA ===&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1196"/>
        <source>-&gt; &lt;b&gt;Dimensionamento de frota concluído com sucesso!&lt;/b&gt; (Camada com {count} registros)&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1200"/>
        <source>-&gt; &lt;b&gt;Resultado do dimensionamento retornou vazio.&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1203"/>
        <source>&lt;span style=&apos;color: #fc8181;&apos;&gt;Erro ao executar dimensionamento de frota: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1207"/>
        <source>&lt;b&gt;=== DIMENSIONAMENTO CONCLUÍDO ===&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1226"/>
        <source>Por favor, selecione a camada de rotas e o campo de carga para a análise de equilíbrio.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1246"/>
        <source>&lt;b&gt;=== EXECUTANDO EQUILÍBRIO ENTRE SETORES ===&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1268"/>
        <source>-&gt; &lt;b&gt;Equilíbrio entre setores calculado com sucesso!&lt;/b&gt; (Camada com {count} registros)&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1272"/>
        <source>-&gt; &lt;b&gt;Resultado do equilíbrio retornou vazio.&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1275"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro ao executar equilíbrio entre setores: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1279"/>
        <source>&lt;b&gt;=== ANÁLISE CONCLUÍDA ===&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1294"/>
        <source>Por favor, selecione a rede viária, a camada de destinos e a camada de setores para o cálculo de distância ao destino.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1314"/>
        <source>&lt;b&gt;=== EXECUTANDO DISTÂNCIA AO DESTINO ===&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1332"/>
        <source>-&gt; &lt;b&gt;Distância ao destino calculada com sucesso!&lt;/b&gt; (Camada com {count} registro(s))&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1336"/>
        <source>-&gt; &lt;b&gt;Resultado da distância ao destino retornou vazio.&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1339"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro ao executar distância ao destino: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1360"/>
        <source>Por favor, selecione a camada de vias exigidas e a camada de rota coberta para o cálculo de cobertura por frequência.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1380"/>
        <source>&lt;b&gt;=== EXECUTANDO COBERTURA POR FREQUÊNCIA ===&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1400"/>
        <source>-&gt; &lt;b&gt;Cobertura por frequência calculada com sucesso!&lt;/b&gt; (Camada com {count} registro(s))&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1404"/>
        <source>-&gt; &lt;b&gt;Resultado da cobertura por frequência retornou vazio.&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1407"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro ao executar cobertura por frequência: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="234"/>
        <source>Geração</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="299"/>
        <source>&lt;b&gt;Setorização&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="310"/>
        <source>Campo de carga (opcional):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="319"/>
        <source>Número de setores de coleta desejado:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="334"/>
        <source>Máximo de iterações de rebalanceamento:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="341"/>
        <source>Executar Setorização</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="349"/>
        <source>Roteirização</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="495"/>
        <source>Frota</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="565"/>
        <source>Indicadores</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="568"/>
        <source>&lt;b&gt;Deadhead Ratio (Razão de Deadhead)&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="573"/>
        <source>Camada de rotas/vias de coleta (Linhas):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="579"/>
        <source>Campo indicador de deadhead/improdutivo:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="586"/>
        <source>Campo de identificação da rota/setor (opcional):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="595"/>
        <source>Executar Razão de Deadhead</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="891"/>
        <source>Por favor, selecione a camada de vias para a setorização.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="911"/>
        <source>&lt;b&gt;=== EXECUTANDO SETORIZAÇÃO ===&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="930"/>
        <source>-&gt; &lt;b&gt;Setorização concluída com sucesso!&lt;/b&gt; (Camada com {count} trechos viários)&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="934"/>
        <source>-&gt; &lt;b&gt;Resultado da setorização retornou vazio.&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="937"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro ao executar setorização: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="941"/>
        <source>&lt;b&gt;=== EXECUÇÃO CONCLUÍDA ===&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1425"/>
        <source>Por favor, selecione a camada de rotas e o campo indicador de deadhead para a análise.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1445"/>
        <source>&lt;b&gt;=== EXECUTANDO RAZÃO DE DEADHEAD ===&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1462"/>
        <source>-&gt; &lt;b&gt;Razão de deadhead calculada com sucesso!&lt;/b&gt; (Camada com {count} registro(s))&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1466"/>
        <source>-&gt; &lt;b&gt;Resultado da razão de deadhead retornou vazio.&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1469"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro ao executar razão de deadhead: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="268"/>
        <source>Campo ID do setor (Vias) — vazio: associa automaticamente</source>
        <translation>Campo ID do setor (Vias) — vazio: associa automaticamente</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="834"/>
        <source>-&gt; &lt;b&gt;Setores associados às vias com sucesso!&lt;/b&gt; ({count} trechos viários)&lt;br&gt;</source>
        <translation>-&gt; &lt;b&gt;Setores associados às vias com sucesso!&lt;/b&gt; ({count} trechos viários)&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="840"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro: Falha na associação das vias aos setores.&lt;/span&gt;&lt;br&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Erro: Falha na associação das vias aos setores.&lt;/span&gt;&lt;br&gt;</translation>
    </message>
</context>
<context>
    <name>WasteFleetSizing</name>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="71"/>
        <source>Camada de rotas de coleta (saída de logis:waste_carp_route)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="78"/>
        <source>Campo de identificação da rota</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="86"/>
        <source>Campo de setor de coleta (opcional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="94"/>
        <source>Velocidade média de coleta (km/h)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="103"/>
        <source>Duração da jornada de trabalho diária (horas)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="112"/>
        <source>Tempo fixo de descarga por rota (horas)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="121"/>
        <source>Tempo fixo de deslocamento ao destino por rota (horas)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="130"/>
        <source>Dimensionamento de frota por setor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="147"/>
        <source>Camada de rotas de coleta inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="151"/>
        <source>Campo de identificação da rota inválido.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="159"/>
        <source>Lendo rotas e somando distâncias por setor...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="186"/>
        <source>Nenhuma rota válida encontrada na camada de entrada.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="206"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="217"/>
        <source>Dimensionando frota do setor &apos;{sec}&apos; ({count} rota(s))...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="232"/>
        <source>Erro ao dimensionar a frota do setor &apos;{sec}&apos;: {err}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="238"/>
        <source>Setor '{sec}': {fleet} veículo(s) necessário(s) | Utilização média: {util:.1f}% | Tempo total de rotas: {total:.2f} h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="250"/>
        <source>Aviso: frota do setor '{sec}' com utilização média abaixo de 50% ({util:.1f}%) — possível sobredimensionamento.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="277"/>
        <source>Dimensionamento de Frota de Coleta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="280"/>
        <source>Logística Especializada — Coleta de Lixo</source>
        <translation type="unfinished">Logística Especializada — Coleta de Lixo</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="286"/>
        <source>Dimensiona a frota de veículos necessária para atender às rotas de coleta de resíduos sólidos durante a jornada de trabalho, aplicando o algoritmo First-Fit Decreasing (FFD) para o problema de empacotamento (Bin Packing).

Parâmetros:
- Camada de rotas de coleta: feições de linha, tipicamente a saída de logis:waste_carp_route.
- Campo de identificação da rota (obrigatório): agrupa feições pela rota/viagem ('route_id'); a distância de cada rota é a soma do comprimento das geometrias.
- Campo de setor de coleta (opcional): se informado, dimensiona a frota separadamente por setor ('route_sector_id'); se omitido, trata a camada inteira como um único setor.
- Velocidade média de coleta: velocidade operacional em km/h (default: 10 km/h).
- Duração da jornada: tempo máximo de trabalho por veículo em horas (default: 8 h).
- Tempo fixo de descarga: tempo gasto na descarga por rota em horas (default: 0.5 h).
- Tempo fixo de deslocamento: tempo de viagem ao aterro/depósito por rota em horas (default: 0.5 h).

Uma rota isolada cuja duração exceda a jornada de trabalho gera erro explícito em vez de ser dividida entre mais de um veículo (sem split).

Retorno:
- Tabela sem geometria com uma feição por setor: 'sector_id', 'fleet_size' (nº de veículos estimado), 'num_routes' (nº de rotas do setor), 'total_route_time_h' (soma das durações das rotas) e 'avg_utilization' (utilização média da frota, entre 0 e 1).</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WasteGenerationEstimate</name>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="62"/>
        <source>Camada de setores (população)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="69"/>
        <source>Campo de identificação do setor</source>
        <translation type="unfinished">Campo de identificação do setor</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="77"/>
        <source>Campo de população (habitantes)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="85"/>
        <source>Camada de vias (com setor já associado)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="92"/>
        <source>Campo de identificação do setor na camada de vias</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="100"/>
        <source>Geração per capita (kg/hab/dia)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="109"/>
        <source>Fração de cobertura da coleta (0 a 1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="119"/>
        <source>Vias com estimativa de geração de resíduos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="136"/>
        <source>Camada de setores inválida.</source>
        <translation type="unfinished">Camada de setores inválida.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="138"/>
        <source>Camada de vias inválida.</source>
        <translation type="unfinished">Camada de vias inválida.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="142"/>
        <source>Campo de população '{field}' não encontrado na camada de setores.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="147"/>
        <source>Campo de identificação do setor '{field}' não encontrado na camada de setores.</source>
        <translation type="unfinished">Campo de identificação do setor '{field}' não encontrado na camada de setores.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="152"/>
        <source>Campo de identificação do setor '{field}' não encontrado na camada de vias.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="157"/>
        <source>Lendo população dos setores...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="169"/>
        <source>Agrupando trechos de via por setor...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="176"/>
        <source>Trecho {fid} sem setor associado — ignorado.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="191"/>
        <source>Setor '{sector}' presente na camada de vias mas não encontrado na camada de setores — ignorado.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="214"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="232"/>
        <source>Geração de resíduos estimada para {count} trecho(s) de via.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="243"/>
        <source>Estimativa de Geração de Resíduos Sólidos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="246"/>
        <source>Logística Especializada — Coleta de Lixo</source>
        <translation type="unfinished">Logística Especializada — Coleta de Lixo</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="252"/>
        <source>Estima a geração de resíduos sólidos (em kg/dia) por trecho de via, a partir da população de cada setor e do rateio proporcional ao comprimento dos trechos de via associados a esse setor.

A camada de vias deve chegar com um campo de identificação do setor já preenchido (ex.: rodando antes logis:waste_street_sector_join no QGIS antes deste algorithm, ou trazendo o campo de outra fonte) — este algorithm não faz nenhum spatial join.

Parâmetros:
- Camada de setores: feições de polígono representando os setores de coleta.
- Campo de identificação do setor (setores): identifica cada setor.
- Campo de população: população de cada setor.
- Camada de vias: feições de linha representando os trechos de via a coletar.
- Campo de identificação do setor (vias): associa cada trecho de via ao seu setor.
- Geração per capita: taxa de geração diária por habitante em kg (default: 0.9 kg/hab/dia).
- Fração de cobertura: fração da população do setor efetivamente coberta pela coleta (default: 1.0).

Retorno:
- Camada de vias com a nova coluna 'waste_kg_day', contendo a geração de resíduos rateada de cada trecho (kg/dia).</source>
        <translation>Estima a geração de resíduos sólidos (em kg/dia) por trecho de via, a partir da população de cada setor e do rateio proporcional ao comprimento dos trechos de via associados a esse setor.

A camada de vias deve chegar com um campo de identificação do setor já preenchido (ex.: rodando antes logis:waste_street_sector_join no QGIS antes deste algorithm, ou trazendo o campo de outra fonte) — este algorithm não faz nenhum spatial join.

Parâmetros:
- Camada de setores: feições de polígono representando os setores de coleta.
- Campo de identificação do setor (setores): identifica cada setor.
- Campo de população: população de cada setor.
- Camada de vias: feições de linha representando os trechos de via a coletar.
- Campo de identificação do setor (vias): associa cada trecho de via ao seu setor.
- Geração per capita: taxa de geração diária por habitante em kg (default: 0.9 kg/hab/dia).
- Fração de cobertura: fração da população do setor efetivamente coberta pela coleta (default: 1.0).

Retorno:
- Camada de vias com a nova coluna 'waste_kg_day', contendo a geração de resíduos rateada de cada trecho (kg/dia).</translation>
    </message>
</context>
<context>
    <name>WasteRppRoute</name>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="114"/>
        <source>Camada de vias</source>
        <translation type="unfinished">Camada de vias</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="121"/>
        <source>Campo de via obrigatória para coleta (opcional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="129"/>
        <source>Campo de setor de coleta (opcional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="146"/>
        <source>Vias com rota de coleta (RPP)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="160"/>
        <source>Camada de vias inválida.</source>
        <translation type="unfinished">Camada de vias inválida.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="173"/>
        <source>Lendo trechos de via e agrupando por setor...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="235"/>
        <source>{count} trecho(s) com geometria inválida foram ignorados.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="242"/>
        <source>Nenhum trecho de via válido encontrado na camada de entrada.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="260"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="273"/>
        <source>Setor '{sec}': nenhum trecho de coleta obrigatória. Ignorando setor.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="282"/>
        <source>Calculando rota RPP para o setor '{sec}' ({req_count} obrigatórios de {tot_count} trechos)...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="327"/>
        <source>Erro ao calcular rota RPP para o setor &apos;{sec}&apos;: {err}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="338"/>
        <source>Setor '{sec}': RPP concluído com {steps} passo(s). {km:.2f} km de deadhead/deslocamento.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="365"/>
        <source>Roteirização por Arcos (RPP)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="368"/>
        <source>Logística Especializada — Coleta de Lixo</source>
        <translation type="unfinished">Logística Especializada — Coleta de Lixo</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="374"/>
        <source>Calcula a sequência de percurso para coleta de lixo por arcos em um subconjunto de vias obrigatórias usando o Problema do Carteiro Rural (Rural Postman Problem - RPP).

Parâmetros:
- Camada de vias: feições de linha com a malha viária.
- Campo de via obrigatória (opcional): campo booleano/inteiro indicando trechos de coleta obrigatória; se omitido, todas as vias são consideradas obrigatórias (equivalente ao CPP).
- Campo de setor de coleta (opcional): se informado, o RPP é resolvido separadamente por setor.
- Tolerância de nó: distância em metros para conectar vértices das vias.

Retorno:
- Camada de linha com feições duplicadas na sequência de travessia e três campos adicionais: 'route_visit_order' (posição sequencial no circuito), 'route_sector_id' (setor de coleta) e 'route_is_connector' (booleano indicando via conetora).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="137"/>
        <source>Tolerância de nó (m)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="180"/>
        <source>camada de vias</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WasteSectorBalance</name>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="74"/>
        <source>Camada de rotas de coleta (ex.: saída de logis:waste_carp_route)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="81"/>
        <source>Campo de carga da rota (kg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="91"/>
        <source>Campo de distância da rota em km (opcional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="101"/>
        <source>Campo de identificação da rota (opcional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="110"/>
        <source>Campo de setor de coleta (opcional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="119"/>
        <source>Velocidade média de coleta (km/h)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="129"/>
        <source>Tempo fixo de descarga por rota (horas)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="138"/>
        <source>Tempo fixo de deslocamento ao destino por rota (horas)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="147"/>
        <source>Indicadores de equilíbrio entre rotas por setor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="165"/>
        <source>Camada de rotas de coleta inválida.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="169"/>
        <source>Campo de carga da rota '{field}' não encontrado.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="191"/>
        <source>Agrupando feições e calculando cargas e distâncias de rotas por setor...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="235"/>
        <source>Nenhuma rota válida encontrada na camada de entrada.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="264"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="317"/>
        <source>Erro ao calcular equilíbrio do setor '{sec}': {err}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="326"/>
        <source>Setor '{sec}': {num} rota(s) | Carga média: {m_load:.2f} kg (σ={std_load:.2f}, CV={cv_load:.1f}%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="339"/>
        <source>Aviso: setor '{sec}' apresenta desbalanço de carga alto (CV={cv:.1f}% &gt; 20%).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="346"/>
        <source>Setor '{sec}': Tempo médio: {m_time:.2f} h (σ={std_time:.2f}, CV={cv_time:.1f}%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="386"/>
        <source>Equilíbrio entre Setores/Rotas de Coleta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="389"/>
        <source>Logística Especializada — Coleta de Lixo</source>
        <translation type="unfinished">Logística Especializada — Coleta de Lixo</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="395"/>
        <source>Avalia o equilíbrio (balanço) de carga e tempo operacional entre rotas/setores de coleta de resíduos sólidos, calculando média, desvio padrão, mínimo, máximo e coeficiente de variação (CV).

Parâmetros:
- Camada de rotas de coleta: feições com rotas/vias (ex.: saída de logis:waste_carp_route, com campos 'route_load_kg' e 'route_distance_km').
- Campo de carga da rota (obrigatório): campo numérico com a carga total da rota (kg).
- Campo de distância da rota (opcional): campo numérico com a distância em km; se omitido, utiliza a extensão das geometrias das rotas.
- Campo de identificação da rota (opcional): se informado, agrupa feições por rota.
- Campo de setor de coleta (opcional): se informado, calcula o equilíbrio separadamente para cada setor.
- Velocidade média de coleta: velocidade operacional em km/h (default: 10 km/h).
- Tempo fixo de descarga: tempo gasto na descarga por rota em horas (default: 0.0 h).
- Tempo fixo de deslocamento: tempo de viagem ao aterro/depósito em horas (default: 0.0 h).

Retorno:
- Tabela sem geometria com uma feição por setor: 'sector_id', 'num_routes', 'total_load_kg', 'mean_load_kg', 'std_dev_load_kg', 'min_load_kg', 'max_load_kg', 'cv_load', 'total_time_h', 'mean_time_h', 'std_dev_time_h', 'min_time_h', 'max_time_h' e 'cv_time'.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WasteStreetSectorJoin</name>
    <message>
        <location filename="../algorithms/waste_street_sector_join.py" line="57"/>
        <source>Camada de vias</source>
        <translation>Camada de vias</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_street_sector_join.py" line="64"/>
        <source>Camada de setores</source>
        <translation>Camada de setores</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_street_sector_join.py" line="71"/>
        <source>Campo de identificação do setor</source>
        <translation>Campo de identificação do setor</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_street_sector_join.py" line="79"/>
        <source>Vias com setor associado</source>
        <translation>Vias com setor associado</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_street_sector_join.py" line="94"/>
        <source>Camada de vias inválida.</source>
        <translation>Camada de vias inválida.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_street_sector_join.py" line="96"/>
        <source>Camada de setores inválida.</source>
        <translation>Camada de setores inválida.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_street_sector_join.py" line="99"/>
        <source>Campo de identificação do setor '{field}' não encontrado na camada de setores.</source>
        <translation>Campo de identificação do setor '{field}' não encontrado na camada de setores.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_street_sector_join.py" line="106"/>
        <source>A camada de vias já possui o campo '{field}'. Utilize esse campo diretamente em vez de refazer a junção.</source>
        <translation>A camada de vias já possui o campo '{field}'. Utilize esse campo diretamente em vez de refazer a junção.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_street_sector_join.py" line="129"/>
        <source>Executando junção espacial por maior sobreposição...</source>
        <translation>Executando junção espacial por maior sobreposição...</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_street_sector_join.py" line="156"/>
        <source>{count} trecho(s) de via ficaram sem setor associado (valor NULL).</source>
        <translation>{count} trecho(s) de via ficaram sem setor associado (valor NULL).</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_street_sector_join.py" line="168"/>
        <source>Associar Vias a Setores Censitários</source>
        <translation>Associar Vias a Setores Censitários</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_street_sector_join.py" line="171"/>
        <source>Logística Especializada — Coleta de Lixo</source>
        <translation>Logística Especializada — Coleta de Lixo</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_street_sector_join.py" line="177"/>
        <source>Associa espacialmente cada trecho de via ao setor censitário correspondente.

A operação utiliza a sobreposição espacial com critério de maior sobreposição (um para um), garantindo que trechos que cruzam a divisa entre dois setores sejam atribuídos ao setor onde possuem maior extensão, sem duplicar feições nem distorcer o rateio de extensão.

Trechos que estiverem fora de todos os setores recebem valor NULL no campo de setor, sem serem descartados da camada de saída.

Parâmetros:
- Camada de vias: linhas representando a malha viária a ser associada.
- Camada de setores: polígonos representando os setores censitários ou áreas de coleta.
- Campo de identificação do setor: campo da camada de setores que identifica unicamente cada setor.

Retorno:
- Camada de vias contendo todos os atributos originais mais o campo de identificação do setor preenchido conforme a sobreposição espacial.</source>
        <translation>Associa espacialmente cada trecho de via ao setor censitário correspondente.

A operação utiliza a sobreposição espacial com critério de maior sobreposição (um para um), garantindo que trechos que cruzam a divisa entre dois setores sejam atribuídos ao setor onde possuem maior extensão, sem duplicar feições nem distorcer o rateio de extensão.

Trechos que estiverem fora de todos os setores recebem valor NULL no campo de setor, sem serem descartados da camada de saída.

Parâmetros:
- Camada de vias: linhas representando a malha viária a ser associada.
- Camada de setores: polígonos representando os setores censitários ou áreas de coleta.
- Campo de identificação do setor: campo da camada de setores que identifica unicamente cada setor.

Retorno:
- Camada de vias contendo todos os atributos originais mais o campo de identificação do setor preenchido conforme a sobreposição espacial.</translation>
    </message>
</context>
</TS>
