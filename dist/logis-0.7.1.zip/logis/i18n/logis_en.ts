<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>@default</name>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="105"/>
        <source>Aviso: SRC da camada de {label} não foi definido ou é inválido. Assumindo EPSG:4674 (SIRGAS 2000).</source>
        <translation type="obsolete">Warning: CRS of layer {label} was not defined or is invalid. Assuming EPSG:4674 (SIRGAS 2000).</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="114"/>
        <source>A camada de {label} possui coordenadas em graus geográficos, mas o SRC declarado ({crs}) usa metros.</source>
        <translation type="obsolete">The {label} layer has geographic degree coordinates, but the declared CRS ({crs}) uses meters.</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="122"/>
        <source>A camada de {label} possui coordenadas métricas, mas o SRC declarado ({crs}) é geográfico.</source>
        <translation type="obsolete">The {label} layer has metric coordinates, but the declared CRS ({crs}) is geographic.</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="116"/>
        <source>SRC da camada de {label} não foi definido; coordenadas dentro do Brasil — assumindo EPSG:4674 (SIRGAS 2000).</source>
        <translation>CRS of the {label} layer was not set; coordinates within Brazil — assuming EPSG:4674 (SIRGAS 2000).</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="122"/>
        <source>A camada de {label} está sem SRC válido (declarado: {crs}) e suas coordenadas não caem no Brasil. Defina o SRC da camada em Propriedades › Fonte e rode novamente.</source>
        <translation>The {label} layer has no valid CRS (declared: {crs}) and its coordinates do not fall within Brazil. Set the layer CRS in Properties › Source and run again.</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="129"/>
        <source>A camada de {label} declara o SRC {crs}, mas as coordenadas estão em graus. Defina o SRC correto da camada em Propriedades › Fonte.</source>
        <translation>The {label} layer declares CRS {crs}, but the coordinates are in degrees. Set the correct layer CRS in Properties › Source.</translation>
    </message>
</context>
<context>
    <name>AlgTaskRunner</name>
    <message>
        <location filename="../gui/task_runner.py" line="52"/>
        <source>Algoritmo '{self.alg_id}' não encontrado.</source>
        <translation type="obsolete">Algorithm '{self.alg_id}' not found in the Processing registry.</translation>
    </message>
    <message>
        <location filename="../gui/task_runner.py" line="54"/>
        <source>Algoritmo {id} não encontrado no registro do Processing.</source>
        <translation>Algorithm {id} not found in the Processing registry.</translation>
    </message>
</context>
<context>
    <name>FacilityLSCP</name>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="75"/>
        <source>Camada de demanda (Pontos/Polígonos)</source>
        <translation>Demand layer (Points/Polygons)</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="82"/>
        <source>Campo de peso da demanda (opcional, default=1.0)</source>
        <translation>Demand weight field (optional, default=1.0)</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="91"/>
        <source>Camada de instalações candidatas (Pontos/Polígonos) (opcional)</source>
        <translation>Candidate facilities layer (Points/Polygons) (optional)</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="99"/>
        <source>Camada de rede viária (Linhas) (opcional)</source>
        <translation>Road network layer (Lines) (optional)</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="107"/>
        <source>Distância/Tempo máximo de cobertura (max_distance)</source>
        <translation>Maximum coverage distance/time (max_distance)</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="116"/>
        <source>Instalações selecionadas</source>
        <translation>Selected facilities</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="122"/>
        <source>Atribuição e cobertura de demandas</source>
        <translation>Demand assignment and coverage</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="137"/>
        <source>Camada de demanda inválida.</source>
        <translation>Invalid demand layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="140"/>
        <source>A distância máxima deve ser estritamente maior que zero.</source>
        <translation>Maximum distance must be strictly greater than zero.</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="155"/>
        <source>Lendo pontos de demanda...</source>
        <translation>Reading demand points...</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="178"/>
        <source>Nenhum ponto de demanda válido encontrado.</source>
        <translation>No valid demand point found.</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="182"/>
        <source>Lendo instalações candidatas...</source>
        <translation>Reading candidate facilities...</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="194"/>
        <source>Nenhuma instalação candidata válida encontrada.</source>
        <translation>No valid candidate facility found.</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="201"/>
        <source>Construindo o grafo e calculando a matriz OD na rede...</source>
        <translation>Building graph and calculating network OD matrix...</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="206"/>
        <source>Erro ao construir o grafo: {}</source>
        <translation>Error building graph: {}</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="212"/>
        <source>O grafo construído possui menos de 2 vértices.</source>
        <translation>The constructed graph has fewer than 2 vertices.</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="229"/>
        <source>Erro ao calcular a matriz OD: {}</source>
        <translation>Error calculating OD matrix: {}</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="231"/>
        <source>Calculando matriz de distâncias euclidianas...</source>
        <translation>Calculating euclidean distance matrix...</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="240"/>
        <source>Executando a otimização LSCP (Toregas et al.)...</source>
        <translation>Running LSCP optimization (Toregas et al.)...</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="250"/>
        <source>LSCP concluído. Instalações: {sel} | Totalmente Coberto: {cov} | Não cobertos: {unc}</source>
        <translation>LSCP completed. Facilities: {sel} | Fully Covered: {cov} | Uncovered: {unc}</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="351"/>
        <source>Localização de Cobertura de Conjuntos (LSCP)</source>
        <translation>Set Covering Location (LSCP)</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="354"/>
        <source>Localização de Instalações</source>
        <translation>Facility Location</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="360"/>
        <source>Resolve o problema de localização de cobertura de conjuntos (LSCP) utilizando a heurística gulosa de Toregas et al. (1971).

Seleciona o menor número possível de instalações para cobrir todos os pontos de demanda dentro da distância/tempo máximo especificado (max_distance).

Parâmetros:
- Camada de demanda: feições de pontos ou polígonos representando a demanda.
- Campo de peso da demanda: campo numérico indicando a demanda de cada feição (opcional, default=1.0).
- Camada de instalações candidatas: instalações elegíveis (opcional, usa a camada de demanda se omitida).
- Camada de rede viária: rede viária para distâncias reais na rede (opcional, usa distância euclidiana se omitida).
- Distância/Tempo máximo de cobertura: raio ou tempo limite para considerar uma demanda coberta.

Saídas:
- Instalações selecionadas: camada de candidatos escolhidos com total de demanda e pontos cobertos.
- Atribuição e cobertura de demandas: camada de demanda com o status de cobertura (is_covered) e a instalação atribuída.</source>
        <translation>Solves the Set Covering Location Problem (LSCP) using Toregas et al. (1971) greedy heuristic.

Selects the minimum number of facilities to cover all demand points within specified maximum distance/time (max_distance).

Parameters:
- Demand layer: point or polygon features representing demand.
- Demand weight field: numeric field indicating demand weight (optional, default=1.0).
- Candidate facilities layer: eligible facilities (optional, uses demand layer if omitted).
- Road network layer: road network for real network distances (optional, uses euclidean distance if omitted).
- Maximum coverage distance/time: radius or time limit to consider demand covered.

Outputs:
- Selected facilities: layer of chosen candidates with total demand and covered points.
- Demand assignment and coverage: demand layer with coverage status (is_covered) and assigned facility.</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="157"/>
        <source>camada de demanda</source>
        <translation>demand layer</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_lscp.py" line="184"/>
        <source>instalações candidatas</source>
        <translation>candidate facilities</translation>
    </message>
</context>
<context>
    <name>FacilityMCLP</name>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="76"/>
        <source>Camada de demanda (Pontos/Polígonos)</source>
        <translation>Demand layer (Points/Polygons)</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="83"/>
        <source>Campo de peso da demanda (opcional, default=1.0)</source>
        <translation>Demand weight field (optional, default=1.0)</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="92"/>
        <source>Camada de instalações candidatas (Pontos/Polígonos) (opcional)</source>
        <translation>Candidate facilities layer (Points/Polygons) (optional)</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="100"/>
        <source>Camada de rede viária (Linhas) (opcional)</source>
        <translation>Road network layer (Lines) (optional)</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="108"/>
        <source>Número máximo de instalações (p)</source>
        <translation>Maximum number of facilities (p)</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="117"/>
        <source>Distância/Tempo máximo de cobertura (max_distance)</source>
        <translation>Maximum coverage distance/time (max_distance)</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="126"/>
        <source>Instalações selecionadas</source>
        <translation>Selected facilities</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="132"/>
        <source>Atribuição e cobertura de demandas</source>
        <translation>Demand assignment and coverage</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="148"/>
        <source>Camada de demanda inválida.</source>
        <translation>Invalid demand layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="151"/>
        <source>A distância máxima deve ser estritamente maior que zero.</source>
        <translation>Maximum distance must be strictly greater than zero.</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="166"/>
        <source>Lendo pontos de demanda...</source>
        <translation>Reading demand points...</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="189"/>
        <source>Nenhum ponto de demanda válido encontrado.</source>
        <translation>No valid demand point found.</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="193"/>
        <source>Lendo instalações candidatas...</source>
        <translation>Reading candidate facilities...</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="205"/>
        <source>Nenhuma instalação candidata válida encontrada.</source>
        <translation>No valid candidate facility found.</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="208"/>
        <source>O número de instalações p ({p}) excede o número de candidatos ({cand}).</source>
        <translation>Number of facilities p ({p}) exceeds candidate count ({cand}).</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="219"/>
        <source>Construindo o grafo e calculando a matriz OD na rede...</source>
        <translation>Building graph and calculating network OD matrix...</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="224"/>
        <source>Erro ao construir o grafo: {}</source>
        <translation>Error building graph: {}</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="230"/>
        <source>O grafo construído possui menos de 2 vértices.</source>
        <translation>The constructed graph has fewer than 2 vertices.</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="247"/>
        <source>Erro ao calcular a matriz OD: {}</source>
        <translation>Error calculating OD matrix: {}</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="249"/>
        <source>Calculando matriz de distâncias euclidianas...</source>
        <translation>Calculating euclidean distance matrix...</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="258"/>
        <source>Executando a otimização MCLP (Church &amp; ReVelle)...</source>
        <translation>Running MCLP optimization (Church &amp; ReVelle)...</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="269"/>
        <source>MCLP concluído. Instalações: {sel} | Demanda Coberta: {cov:.2f}/{tot:.2f} ({ratio:.1%})</source>
        <translation>MCLP completed. Facilities: {sel} | Covered Demand: {cov:.2f}/{tot:.2f} ({ratio:.1%})</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="361"/>
        <source>Localização de Cobertura Máxima (MCLP)</source>
        <translation>Maximum Coverage Location (MCLP)</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="364"/>
        <source>Localização de Instalações</source>
        <translation>Facility Location</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="370"/>
        <source>Resolve o problema de localização de cobertura máxima (MCLP) utilizando a heurística gulosa de Church &amp; ReVelle (1974).

Seleciona até p instalações candidatas que maximizem o peso da demanda atendida dentro da distância/tempo máximo especificado (max_distance).

Parâmetros:
- Camada de demanda: feições de pontos ou polígonos representando a demanda.
- Campo de peso da demanda: campo numérico indicando a demanda de cada feição (opcional, default=1.0).
- Camada de instalações candidatas: instalações elegíveis (opcional, usa a camada de demanda se omitida).
- Camada de rede viária: rede viária para distâncias reais na rede (opcional, usa distância euclidiana se omitida).
- Número máximo de instalações (p): quantidade máxima de instalações a selecionar.
- Distância/Tempo máximo de cobertura: raio ou tempo limite para considerar uma demanda coberta.

Saídas:
- Instalações selecionadas: camada de candidatos escolhidos com total de demanda e pontos cobertos.
- Atribuição e cobertura de demandas: camada de demanda com o status de cobertura (is_covered) e a instalação atribuída.</source>
        <translation>Solves the Maximum Coverage Location Problem (MCLP) using Church &amp; ReVelle (1974) greedy heuristic.

Selects up to p candidate facilities that maximize total covered demand weight within specified maximum distance/time (max_distance).

Parameters:
- Demand layer: point or polygon features representing demand.
- Demand weight field: numeric field indicating demand weight (optional, default=1.0).
- Candidate facilities layer: eligible facilities (optional, uses demand layer if omitted).
- Road network layer: road network for real network distances (optional, uses euclidean distance if omitted).
- Maximum number of facilities (p): maximum facility count to select.
- Maximum coverage distance/time: radius or time limit to consider demand covered.

Outputs:
- Selected facilities: layer of chosen candidates with total demand and covered points.
- Demand assignment and coverage: demand layer with coverage status (is_covered) and assigned facility.</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="168"/>
        <source>camada de demanda</source>
        <translation>demand layer</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_mclp.py" line="195"/>
        <source>instalações candidatas</source>
        <translation>candidate facilities</translation>
    </message>
</context>
<context>
    <name>FacilityPMedian</name>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="76"/>
        <source>Camada de demanda (Pontos/Polígonos)</source>
        <translation>Demand layer (Points/Polygons)</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="83"/>
        <source>Campo de peso da demanda (opcional, default=1.0)</source>
        <translation>Demand weight field (optional, default=1.0)</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="92"/>
        <source>Camada de instalações candidatas (Pontos/Polígonos) (opcional)</source>
        <translation>Candidate facilities layer (Points/Polygons) (optional)</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="100"/>
        <source>Camada de rede viária (Linhas) (opcional)</source>
        <translation>Road network layer (Lines) (optional)</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="108"/>
        <source>Número de instalações (p)</source>
        <translation>Number of facilities (p)</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="117"/>
        <source>Número máximo de iterações do Teitz-Bart</source>
        <translation>Maximum number of Teitz-Bart iterations</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="126"/>
        <source>Instalações selecionadas</source>
        <translation>Selected facilities</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="132"/>
        <source>Atribuição de demandas</source>
        <translation>Demand assignment</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="148"/>
        <source>Camada de demanda inválida.</source>
        <translation>Invalid demand layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="163"/>
        <source>Lendo pontos de demanda...</source>
        <translation>Reading demand points...</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="186"/>
        <source>Nenhum ponto de demanda válido encontrado.</source>
        <translation>No valid demand point found.</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="190"/>
        <source>Lendo instalações candidatas...</source>
        <translation>Reading candidate facilities...</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="202"/>
        <source>Nenhuma instalação candidata válida encontrada.</source>
        <translation>No valid candidate facility found.</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="205"/>
        <source>O número de instalações p ({p}) excede o número de candidatos ({cand}).</source>
        <translation>Number of facilities p ({p}) exceeds candidate count ({cand}).</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="216"/>
        <source>Construindo o grafo e calculando a matriz OD na rede...</source>
        <translation>Building graph and calculating network OD matrix...</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="221"/>
        <source>Erro ao construir o grafo: {}</source>
        <translation>Error building graph: {}</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="227"/>
        <source>O grafo construído possui menos de 2 vértices.</source>
        <translation>The constructed graph has fewer than 2 vertices.</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="244"/>
        <source>Erro ao calcular a matriz OD: {}</source>
        <translation>Error calculating OD matrix: {}</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="246"/>
        <source>Calculando matriz de distâncias euclidianas...</source>
        <translation>Calculating euclidean distance matrix...</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="255"/>
        <source>Executando a otimização p-Mediana (Teitz-Bart)...</source>
        <translation>Running p-Median optimization (Teitz-Bart)...</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="266"/>
        <source>Localização concluída. Instalações selecionadas: {sel} | Custo Total: {cost:.2f}</source>
        <translation>Location completed. Selected facilities: {sel} | Total Cost: {cost:.2f}</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="348"/>
        <source>Localização p-Mediana (Teitz-Bart)</source>
        <translation>p-Median Location (Teitz-Bart)</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="351"/>
        <source>Localização de Instalações</source>
        <translation>Facility Location</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="357"/>
        <source>Resolve o problema de localização p-mediana selecionando p instalações candidatas que minimizem a soma total das distâncias/custos ponderadas da demanda até a instalação mais próxima.

Parâmetros:
- Camada de demanda: feições de pontos ou polígonos representando a demanda.
- Campo de peso da demanda: campo numérico indicando a demanda de cada feição (opcional, default=1.0).
- Camada de instalações candidatas: instalações elegíveis (opcional, usa a camada de demanda se omitida).
- Camada de rede viária: rede viária para distâncias reais na rede (opcional, usa distância euclidiana se omitida).
- Número de instalações (p): quantidade de instalações a selecionar.
- Número máximo de iterações: limite de trocas locais no algoritmo Teitz-Bart.

Saídas:
- Instalações selecionadas: camada de candidatos escolhidos com totais de demanda e custo.
- Atribuição de demandas: camada de demanda com o ID da instalação atribuída e o custo de atendimento.</source>
        <translation>Solves the p-median location problem by selecting p candidate facilities that minimize the sum of weighted distances/costs from demand to the nearest facility.

Parameters:
- Demand layer: point or polygon features representing demand.
- Demand weight field: numeric field indicating demand weight (optional, default=1.0).
- Candidate facilities layer: eligible facilities (optional, uses demand layer if omitted).
- Road network layer: road network for real network distances (optional, uses euclidean distance if omitted).
- Number of facilities (p): quantity of facilities to select.
- Maximum iterations: limit of local swaps in Teitz-Bart algorithm.

Outputs:
- Selected facilities: layer of chosen candidates with demand and cost totals.
- Demand assignment: demand layer with assigned facility ID and service cost.</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="165"/>
        <source>camada de demanda</source>
        <translation>demand layer</translation>
    </message>
    <message>
        <location filename="../algorithms/facility_p_median.py" line="192"/>
        <source>instalações candidatas</source>
        <translation>candidate facilities</translation>
    </message>
</context>
<context>
    <name>LoadOsmNetwork</name>
    <message>
        <location filename="../algorithms/data_osm_network.py" line="52"/>
        <source>Código IBGE do município (7 dígitos)</source>
        <translation>Municipal IBGE code (7 digits)</translation>
    </message>
    <message>
        <location filename="../algorithms/data_osm_network.py" line="58"/>
        <source>Nome do município (opcional)</source>
        <translation>Municipality name (optional)</translation>
    </message>
    <message>
        <location filename="../algorithms/data_osm_network.py" line="65"/>
        <source>Forçar novo download (ignorar cache)</source>
        <translation>Force new download (ignore cache)</translation>
    </message>
    <message>
        <location filename="../algorithms/data_osm_network.py" line="72"/>
        <source>Arcos (rede viária)</source>
        <translation>Links (road network)</translation>
    </message>
    <message>
        <location filename="../algorithms/data_osm_network.py" line="78"/>
        <source>Nós (rede viária)</source>
        <translation>Nodes (road network)</translation>
    </message>
    <message>
        <location filename="../algorithms/data_osm_network.py" line="92"/>
        <source>Código IBGE do município deve possuir exatamente 7 dígitos.</source>
        <translation>Municipal IBGE code must have exactly 7 digits.</translation>
    </message>
    <message>
        <location filename="../algorithms/data_osm_network.py" line="124"/>
        <source>nenhuma via encontrada para o município</source>
        <translation>no roads found for the municipality</translation>
    </message>
    <message>
        <location filename="../algorithms/data_osm_network.py" line="136"/>
        <source>Não foi possível criar o sink de arcos.</source>
        <translation>Could not create links sink.</translation>
    </message>
    <message>
        <location filename="../algorithms/data_osm_network.py" line="147"/>
        <source>Não foi possível criar o sink de nós.</source>
        <translation>Could not create nodes sink.</translation>
    </message>
    <message>
        <location filename="../algorithms/data_osm_network.py" line="168"/>
        <source>Rede viária OSM carregada: {links} arcos, {nodes} nós.</source>
        <translation>OSM road network loaded: {links} links, {nodes} nodes.</translation>
    </message>
    <message>
        <location filename="../algorithms/data_osm_network.py" line="185"/>
        <source>Baixar rede viária urbana (OSM, município)</source>
        <translation>Download urban road network (OSM, municipality)</translation>
    </message>
    <message>
        <location filename="../algorithms/data_osm_network.py" line="188"/>
        <source>Dados</source>
        <translation>Data</translation>
    </message>
    <message>
        <location filename="../algorithms/data_osm_network.py" line="181"/>
        <source>Baixa e processa a rede viária urbana de um município a partir dos dados do OpenStreetMap (via Overpass API).

Parâmetros:
- Código IBGE do município: código numérico de 7 dígitos.
- Nome do município (opcional): para auxiliar na identificação.
- Forçar novo download: se verdadeiro, ignora o cache local e faz nova requisição Overpass.

Retorno:
- Arcos (rede viária): camada de linhas representando os trechos de vias recortados para o município.
- Nós (rede viária): camada de pontos representando as interseções e extremidades dos arcos.</source>
        <translation type="obsolete">Downloads and processes the urban road network of a municipality from OpenStreetMap data (via Overpass API).

Parameters:
- Municipal IBGE code: 7-digit numeric code.
- Municipality name (optional): to help identification.
- Force new download: if true, ignores local cache and makes a new Overpass request.

Returns:
- Links (road network): line layer representing road segments clipped for the municipality.
- Nodes (road network): point layer representing intersections and endpoints.</translation>
    </message>
    <message>
        <location filename="../algorithms/data_osm_network.py" line="110"/>
        <source>Fonte: {backend}</source>
        <translation>Source: {backend}</translation>
    </message>
    <message>
        <location filename="../algorithms/data_osm_network.py" line="194"/>
        <source>Baixa e processa a rede viária urbana de um município a partir dos dados do OpenStreetMap.
Utiliza o algoritmo gisbr:osm_network quando o GisBR 0.11+ está instalado e o pipeline interno caso contrário.
Em ambos os casos, os arcos trazem os campos de custo length, speed e travel_time.

Parâmetros:
- Código IBGE do município: código numérico de 7 dígitos.
- Nome do município (opcional): para auxiliar na identificação.
- Forçar novo download: se verdadeiro, ignora o cache local e faz nova requisição Overpass.

Retorno:
- Arcos (rede viária): camada de linhas representando os trechos de vias recortados para o município.
- Nós (rede viária): camada de pontos representando as interseções e extremidades dos arcos.</source>
        <translation>Downloads and processes the urban road network of a municipality from OpenStreetMap data.
Uses the algorithm gisbr:osm_network when GisBR 0.11+ is installed and the internal pipeline otherwise.
In both cases, links include the cost fields length, speed and travel_time.

Parameters:
- IBGE municipality code: 7-digit numerical code.
- Municipality name (optional): to assist in identification.
- Force new download: if true, ignores local cache and makes a new Overpass request.

Returns:
- Links (road network): line layer representing road segments clipped for the municipality.
- Nodes (road network): point layer representing intersections and link endpoints.</translation>
    </message>
</context>
<context>
    <name>LoadSnvNetwork</name>
    <message>
        <location filename="../algorithms/data_snv_network.py" line="44"/>
        <source>Sigla da UF (2 letras)</source>
        <translation>State abbreviation (2 letters)</translation>
    </message>
    <message>
        <location filename="../algorithms/data_snv_network.py" line="50"/>
        <source>Forçar novo download (ignorar cache)</source>
        <translation>Force new download (ignore cache)</translation>
    </message>
    <message>
        <location filename="../algorithms/data_snv_network.py" line="57"/>
        <source>Arcos (rede viária)</source>
        <translation>Links (road network)</translation>
    </message>
    <message>
        <location filename="../algorithms/data_snv_network.py" line="63"/>
        <source>Nós (rede viária)</source>
        <translation>Nodes (road network)</translation>
    </message>
    <message>
        <location filename="../algorithms/data_snv_network.py" line="76"/>
        <source>UF inválida: {uf}</source>
        <translation>Invalid state: {uf}</translation>
    </message>
    <message>
        <location filename="../algorithms/data_snv_network.py" line="99"/>
        <source>O SNV não devolveu dados para a UF {uf}.</source>
        <translation>SNV did not return data for state {uf}.</translation>
    </message>
    <message>
        <location filename="../algorithms/data_snv_network.py" line="111"/>
        <source>Não foi possível criar o sink de arcos.</source>
        <translation>Could not create links sink.</translation>
    </message>
    <message>
        <location filename="../algorithms/data_snv_network.py" line="122"/>
        <source>Não foi possível criar o sink de nós.</source>
        <translation>Could not create nodes sink.</translation>
    </message>
    <message>
        <location filename="../algorithms/data_snv_network.py" line="143"/>
        <source>Rede viária SNV carregada: {links} arcos, {nodes} nós.</source>
        <translation>SNV road network loaded: {links} links, {nodes} nodes.</translation>
    </message>
    <message>
        <location filename="../algorithms/data_snv_network.py" line="160"/>
        <source>Baixar rede viária federal (SNV/DNIT, UF)</source>
        <translation>Download federal road network (SNV/DNIT, state)</translation>
    </message>
    <message>
        <location filename="../algorithms/data_snv_network.py" line="163"/>
        <source>Dados</source>
        <translation>Data</translation>
    </message>
    <message>
        <location filename="../algorithms/data_snv_network.py" line="169"/>
        <source>Baixa e processa a rede viária federal de uma UF a partir dos dados do SNV/DNIT.

Parâmetros:
- Sigla da UF (2 letras): sigla do estado brasileiro (ex.: MG, SP, RJ).
- Forçar novo download: se verdadeiro, ignora o cache local e faz nova requisição.

Retorno:
- Arcos (rede viária): camada de linhas representando os trechos de rodovias federais/estaduais no estado.
- Nós (rede viária): camada de pontos representando as interseções e extremidades dos arcos.</source>
        <translation>Downloads and processes the federal road network of a state from SNV/DNIT data.

Parameters:
- State abbreviation (2 letters): Brazilian state abbreviation (e.g., MG, SP, RJ).
- Force new download: if true, ignores local cache and makes a new request.

Returns:
- Links (road network): line layer representing federal/state highway segments in the state.
- Nodes (road network): point layer representing intersections and endpoints.</translation>
    </message>
</context>
<context>
    <name>LogisPlugin</name>
    <message>
        <location filename="../logis_plugin.py" line="48"/>
        <source>Dependências...</source>
        <translation>Dependencies...</translation>
    </message>
    <message>
        <location filename="../logis_plugin.py" line="62"/>
        <source>Indicadores Urbanos</source>
        <translation>Urban Indicators</translation>
    </message>
    <message>
        <location filename="../logis_plugin.py" line="69"/>
        <source>Indicadores Regionais</source>
        <translation>Regional Indicators</translation>
    </message>
    <message>
        <location filename="../logis_plugin.py" line="76"/>
        <source>Coleta de Lixo</source>
        <translation>Waste Collection</translation>
    </message>
    <message>
        <location filename="../logis_plugin.py" line="83"/>
        <source>Roteirização</source>
        <translation>Routing</translation>
    </message>
    <message>
        <location filename="../logis_plugin.py" line="90"/>
        <source>Documentação</source>
        <translation>Documentation</translation>
    </message>
    <message>
        <location filename="../logis_plugin.py" line="55"/>
        <source>Rede Viária</source>
        <translation>Road Network</translation>
    </message>
</context>
<context>
    <name>LogisProvider</name>
    <message>
        <location filename="../provider.py" line="79"/>
        <source>logis — suporte a projetos de logística no Brasil</source>
        <translation>logis — support for logistics projects in Brazil</translation>
    </message>
</context>
<context>
    <name>NetworkDock</name>
    <message>
        <location filename="../gui/network_dock.py" line="234"/>
        <source>logis — Rede Viária</source>
        <translation>logis — Road Network</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="266"/>
        <source>&lt;b&gt;Rede Viária&lt;/b&gt;</source>
        <translation>&lt;b&gt;Road Network&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="207"/>
        <source>O painel baixa arcos e nós direto para o projeto. O QGIS pode ficar sem resposta durante o download.</source>
        <translation type="obsolete">The panel downloads links and nodes directly into the project. QGIS may become unresponsive during download.</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="280"/>
        <source>Município (OSM)</source>
        <translation>Municipality (OSM)</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="319"/>
        <source>UF:</source>
        <translation>State:</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="287"/>
        <source>Listar municípios da UF</source>
        <translation>List state municipalities</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="291"/>
        <source>Município:</source>
        <translation>Municipality:</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="296"/>
        <source>Código IBGE (7 dígitos):</source>
        <translation>IBGE Code (7 digits):</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="324"/>
        <source>Forçar novo download (ignorar cache)</source>
        <translation>Force new download (ignore cache)</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="310"/>
        <source>Baixar arcos e nós (OSM)</source>
        <translation>Download links and nodes (OSM)</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="317"/>
        <source>Estado (SNV/DNIT)</source>
        <translation>State (SNV/DNIT)</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="327"/>
        <source>Baixar arcos e nós (SNV)</source>
        <translation>Download links and nodes (SNV)</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="340"/>
        <source>&lt;b&gt;Resultados:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Results:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="389"/>
        <source>Municípios de {uf} carregados com sucesso.</source>
        <translation>Municipalities of {uf} loaded successfully.</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="391"/>
        <source>Erro ao listar municípios: {str(e)}</source>
        <translation>Error listing municipalities: {str(e)}</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="455"/>
        <source>Erro</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="400"/>
        <source>Código IBGE do município deve possuir 7 dígitos.</source>
        <translation>Municipal IBGE code must have 7 digits.</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="304"/>
        <source>Fonte: GisBR (gisbr:osm_network)</source>
        <translation>Source: GisBR (gisbr:osm_network)</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="243"/>
        <source>Fonte: Pipeline interno (logis)</source>
        <translation type="obsolete">Source: Internal pipeline (logis)</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="306"/>
        <source>Fonte: pipeline interno do logis — instale o GisBR 0.11+ para usar o fluxo único</source>
        <translation>Source: logis internal pipeline — install GisBR 0.11+ to use the unified flow</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="270"/>
        <source>O painel baixa arcos e nós direto para o projeto. O download roda em primeiro plano; acompanhe o andamento na barra de progresso.</source>
        <translation>The panel downloads links and nodes straight into the project. The download runs in the foreground; follow its progress in the progress bar.</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="383"/>
        <source>Listando municípios…</source>
        <translation>Listing municipalities…</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="405"/>
        <source>Baixando rede viária OSM…</source>
        <translation>Downloading OSM road network…</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="444"/>
        <source>Rede viária OSM ({code_muni}) carregada via {source}: {n_links} arcos, {n_nodes} nós.</source>
        <translation>OSM road network ({code_muni}) loaded via {source}: {n_links} links, {n_nodes} nodes.</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="453"/>
        <source>Por favor, selecione uma UF.</source>
        <translation>Please select a state (UF).</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="458"/>
        <source>Baixando rede viária SNV…</source>
        <translation>Downloading SNV road network…</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="490"/>
        <source>Rede viária SNV ({uf}) carregada: {n_links} arcos, {n_nodes} nós.</source>
        <translation>SNV road network ({uf}) loaded: {n_links} links, {n_nodes} nodes.</translation>
    </message>
</context>
<context>
    <name>RegionalCriticalLinks</name>
    <message>
        <location filename="../algorithms/regional_critical_links.py" line="54"/>
        <source>Camada de malha rodoviária (Linhas)</source>
        <translation>Highway network layer (Lines)</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_critical_links.py" line="61"/>
        <source>Trechos com indicação de ponte/arco crítico</source>
        <translation>Segments indicating critical bridge/link</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_critical_links.py" line="67"/>
        <source>Número de pontes/arcos críticos identificados</source>
        <translation>Number of identified critical bridges/links</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_critical_links.py" line="78"/>
        <source>Camada de malha rodoviária inválida.</source>
        <translation>Invalid highway network layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_critical_links.py" line="80"/>
        <source>Construindo o grafo a partir da malha rodoviária...</source>
        <translation>Building graph from highway network...</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_critical_links.py" line="84"/>
        <source>Erro ao construir o grafo: {}</source>
        <translation>Error building graph: {}</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_critical_links.py" line="90"/>
        <source>O grafo construído está vazio.</source>
        <translation>The constructed graph is empty.</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_critical_links.py" line="95"/>
        <source>Deduplicando arcos em arestas físicas únicas...</source>
        <translation>Deduplicating arcs into unique physical edges...</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_critical_links.py" line="113"/>
        <source>Identificando pontes/arcos críticos ({n} arestas físicas)...</source>
        <translation>Identifying critical bridges/links ({n} physical edges)...</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_critical_links.py" line="130"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation>Could not create output layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_critical_links.py" line="146"/>
        <source>Pontes/arcos críticos identificados: {n} de {total} trechos.</source>
        <translation>Critical bridges/links identified: {n} of {total} segments.</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_critical_links.py" line="162"/>
        <source>Pontes/Arcos Críticos da Malha Regional</source>
        <translation>Critical Bridges/Links of Regional Network</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_critical_links.py" line="165"/>
        <source>Indicadores Regionais</source>
        <translation>Regional Indicators</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_critical_links.py" line="171"/>
        <source>Identifica as pontes/arcos críticos (cut links) da malha rodoviária regional: trechos cuja remoção desconecta a rede, indicando ligações intermunicipais sem rota alternativa.

Parâmetros:
- Camada de malha rodoviária: feições de linha representando as rodovias.

Retorno:
- Camada de linhas com o campo 'is_critical_link' (booleano), uma feição por trecho físico único da malha.
- Número de pontes/arcos críticos identificados.</source>
        <translation>Identifies critical bridges/links (cut links) of the regional highway network: segments whose removal disconnects network, indicating intercity connections without alternative routes.

Parameters:
- Highway network layer: line features representing highways.

Returns:
- Line layer with field 'is_critical_link' (boolean), one feature per unique physical segment.
- Number of identified critical bridges/links.</translation>
    </message>
</context>
<context>
    <name>RegionalDock</name>
    <message>
        <location filename="../gui/regional_dock.py" line="168"/>
        <source>logis — Indicadores Regionais</source>
        <translation>logis — Regional Indicators</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="185"/>
        <source>&lt;b&gt;Indicadores Regionais&lt;/b&gt;</source>
        <translation>&lt;b&gt;Regional Indicators&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="189"/>
        <source>Selecione as camadas e parâmetros abaixo para calcular os indicadores de densidade rodoviária regional e percentual de pavimentação.</source>
        <translation>Select the layers and parameters below to calculate regional road density and paving percentage indicators.</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="200"/>
        <source>Camada de rede regional (Linhas):</source>
        <translation>Regional network layer (Lines):</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="206"/>
        <source>Camada de área de referência (Polígonos - para Densidade):</source>
        <translation>Reference area layer (Polygons - for Density):</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="212"/>
        <source>População da área de referência (habitantes):</source>
        <translation>Reference area population (inhabitants):</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="219"/>
        <source>Calcular Densidade Rodoviária</source>
        <translation>Calculate Road Density</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="225"/>
        <source>Calcular % Pavimentação</source>
        <translation>Calculate Paving %</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="231"/>
        <source>Calcular Pontes/Arcos Críticos</source>
        <translation>Calculate Critical Bridges/Links</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="237"/>
        <source>Resultados dos Indicadores Regionais:</source>
        <translation>Regional Indicators Results:</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="395"/>
        <source>Aviso</source>
        <translation>Warning</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="395"/>
        <source>Por favor, selecione uma camada de rede regional.</source>
        <translation>Please select a regional network layer.</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="400"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro: Camada de rede regional não selecionada.&lt;/span&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Error: Regional network layer not selected.&lt;/span&gt;</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="271"/>
        <source>Por favor, selecione uma camada de área de referência.</source>
        <translation>Please select a reference area layer.</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="276"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro: Camada de área de referência não selecionada.&lt;/span&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Error: Reference area layer not selected.&lt;/span&gt;</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="406"/>
        <source>Erro</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="406"/>
        <source>QGIS Processing não está disponível no ambiente atual.</source>
        <translation>QGIS Processing is not available in the current environment.</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="411"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro: QGIS Processing não disponível.&lt;/span&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Error: QGIS Processing not available.&lt;/span&gt;</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="291"/>
        <source>&lt;b&gt;=== CALCULANDO DENSIDADE RODOVIÁRIA REGIONAL ===&lt;/b&gt;&lt;br&gt;</source>
        <translation>&lt;b&gt;=== CALCULATING REGIONAL HIGHWAY DENSITY ===&lt;/b&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="303"/>
        <source>-&gt; &lt;b&gt;Densidade por Área:&lt;/b&gt; {value:.4f} km/1.000 km²</source>
        <translation>-&gt; &lt;b&gt;Density by Area:&lt;/b&gt; {value:.4f} km/1,000 km²</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="307"/>
        <source>-&gt; &lt;b&gt;Densidade por Área:&lt;/b&gt; N/A</source>
        <translation>-&gt; &lt;b&gt;Density by Area:&lt;/b&gt; N/A</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="310"/>
        <source>-&gt; &lt;b&gt;Densidade por População:&lt;/b&gt; {value:.4f} km/10.000 hab.&lt;br&gt;</source>
        <translation>-&gt; &lt;b&gt;Density by Population:&lt;/b&gt; {value:.4f} km/10,000 hab.&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="314"/>
        <source>-&gt; &lt;b&gt;Densidade por População:&lt;/b&gt; N/A&lt;br&gt;</source>
        <translation>-&gt; &lt;b&gt;Density by Population:&lt;/b&gt; N/A&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="317"/>
        <source>&lt;span style=&apos;color: #fc8181;&apos;&gt;Erro ao calcular densidade: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Error calculating density: {error}&lt;/span&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="440"/>
        <source>&lt;b&gt;=== CÁLCULO CONCLUÍDO ===&lt;/b&gt;</source>
        <translation>&lt;b&gt;=== CALCULATION COMPLETED ===&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="353"/>
        <source>&lt;b&gt;=== CALCULANDO PERCENTUAL DE PAVIMENTAÇÃO ===&lt;/b&gt;&lt;br&gt;</source>
        <translation>&lt;b&gt;=== CALCULATING PAVING PERCENTAGE ===&lt;/b&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="364"/>
        <source>-&gt; &lt;b&gt;Percentual Pavimentada:&lt;/b&gt; {value:.2f}%</source>
        <translation>-&gt; &lt;b&gt;Paved Percentage:&lt;/b&gt; {value:.2f}%</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="368"/>
        <source>-&gt; &lt;b&gt;Percentual Pavimentada:&lt;/b&gt; N/A</source>
        <translation>-&gt; &lt;b&gt;Paved Percentage:&lt;/b&gt; N/A</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="371"/>
        <source>-&gt; &lt;b&gt;Percentual Duplicada:&lt;/b&gt; {value:.2f}%&lt;br&gt;</source>
        <translation>-&gt; &lt;b&gt;Duplicated Percentage:&lt;/b&gt; {value:.2f}%&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="375"/>
        <source>-&gt; &lt;b&gt;Percentual Duplicada:&lt;/b&gt; N/A&lt;br&gt;</source>
        <translation>-&gt; &lt;b&gt;Duplicated Percentage:&lt;/b&gt; N/A&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="378"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro ao calcular pavimentação: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Error calculating paving: {error}&lt;/span&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="415"/>
        <source>&lt;b&gt;=== CALCULANDO PONTES/ARCOS CRÍTICOS ===&lt;/b&gt;&lt;br&gt;</source>
        <translation>&lt;b&gt;=== CALCULATING CRITICAL BRIDGES/LINKS ===&lt;/b&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="429"/>
        <source>-&gt; &lt;b&gt;Pontes/Arcos Críticos:&lt;/b&gt; {n} de {total} trechos.&lt;br&gt;</source>
        <translation>-&gt; &lt;b&gt;Bridges/Critical Links:&lt;/b&gt; {n} of {total} segments.&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/regional_dock.py" line="436"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro ao calcular pontes/arcos críticos: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Error calculating critical bridges/links: {error}&lt;/span&gt;&lt;br&gt;</translation>
    </message>
</context>
<context>
    <name>RegionalNetworkDensity</name>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="46"/>
        <source>Camada de malha rodoviária (Linhas)</source>
        <translation>Highway network layer (Lines)</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="53"/>
        <source>Camada de área de referência (UF, mesorregião, etc.)</source>
        <translation>Reference area layer (State, mesoregion, etc.)</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="60"/>
        <source>População da área de referência (hab.)</source>
        <translation>Reference area population (hab.)</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="68"/>
        <source>Densidade rodoviária por área (km/1.000 km²)</source>
        <translation>Road density by area (km/1,000 km²)</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="74"/>
        <source>Densidade rodoviária por população (km/10.000 hab.)</source>
        <translation>Road density by population (km/10,000 hab.)</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="87"/>
        <source>Camada de malha rodoviária inválida.</source>
        <translation>Invalid highway network layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="89"/>
        <source>Camada de área de referência inválida.</source>
        <translation>Invalid reference area layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="92"/>
        <source>O campo 'length' não foi encontrado na camada de malha rodoviária. Utilize a camada snv_links_{uf} gerada por core.network.snv_pipeline.</source>
        <translation>The 'length' field was not found in highway network layer. Use snv_links_{uf} layer generated by core.network.snv_pipeline.</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="104"/>
        <source>Somando a extensão total da malha rodoviária (campo 'length')...</source>
        <translation>Summing total length of highway network ('length' field)...</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="121"/>
        <source>Calculando a área total do polígono de referência...</source>
        <translation>Calculating total reference polygon area...</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="136"/>
        <source>A área calculada é de 0 km² ou negativa. Verifique a geometria de referência.</source>
        <translation>Calculated area is 0 km² or negative. Check reference geometry.</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="146"/>
        <source>Extensão da Malha: {length:.2f} m | Área: {area:.4f} km² | População: {pop:.0f} hab.</source>
        <translation>Network Length: {length:.2f} m | Area: {area:.4f} km² | Population: {pop:.0f} hab.</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="151"/>
        <source>Densidade por Área: {da:.4f} km/1.000 km² | Densidade por População: {dp:.4f} km/10.000 hab.</source>
        <translation>Density by Area: {da:.4f} km/1,000 km² | Density by Population: {dp:.4f} km/10,000 hab.</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="168"/>
        <source>Densidade da Malha Rodoviária Regional</source>
        <translation>Regional Highway Network Density</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="171"/>
        <source>Indicadores Regionais</source>
        <translation>Regional Indicators</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_network_density.py" line="177"/>
        <source>Calcula a densidade da malha rodoviária por área territorial (km/1.000 km²) e por população (km/10.000 hab.).

Parâmetros:
- Camada de malha rodoviária: feições de linha representando as rodovias.
- Camada de área de referência: feições de polígono definindo o território (UF, mesorregião, etc.).
- População da área de referência: número de habitantes do território.

Retornos:
- Densidade rodoviária por área (km/1.000 km²).
- Densidade rodoviária por população (km/10.000 hab.).</source>
        <translation>Calculates highway network density by land area (km/1,000 km²) and by population (km/10,000 hab.).

Parameters:
- Highway network layer: line features representing highways.
- Reference area layer: polygon features defining the territory (State, mesoregion, etc.).
- Reference area population: inhabitant count of territory.

Returns:
- Road density by area (km/1,000 km²).
- Road density by population (km/10,000 hab.).</translation>
    </message>
</context>
<context>
    <name>RegionalPavementPercentage</name>
    <message>
        <location filename="../algorithms/regional_pavement_percentage.py" line="42"/>
        <source>Camada de malha rodoviária (Linhas)</source>
        <translation>Highway network layer (Lines)</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_pavement_percentage.py" line="49"/>
        <source>Campo que indica o tipo de superfície (ex: 'ds_superfi')</source>
        <translation>Field indicating surface type (e.g. 'ds_superfi')</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_pavement_percentage.py" line="59"/>
        <source>Percentual de vias pavimentadas (%)</source>
        <translation>Percentage of paved roads (%)</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_pavement_percentage.py" line="65"/>
        <source>Percentual de vias duplicadas (%)</source>
        <translation>Percentage of duplicated roads (%)</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_pavement_percentage.py" line="77"/>
        <source>Camada de malha rodoviária inválida.</source>
        <translation>Invalid highway network layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_pavement_percentage.py" line="84"/>
        <source>O campo '{field}' não foi encontrado na camada de malha rodoviária. Campos disponíveis: {fields}</source>
        <translation>The field '{field}' was not found in highway network layer. Available fields: {fields}</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_pavement_percentage.py" line="90"/>
        <source>O campo 'length' não foi encontrado na camada de malha rodoviária. Utilize a camada snv_links_{uf} gerada por core.network.snv_pipeline.</source>
        <translation>The 'length' field was not found in highway network layer. Use snv_links_{uf} layer generated by core.network.snv_pipeline.</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_pavement_percentage.py" line="103"/>
        <source>Somando as extensões da malha rodoviária (campo 'length')...</source>
        <translation>Summing lengths of highway network ('length' field)...</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_pavement_percentage.py" line="124"/>
        <source>O comprimento total da malha é de 0 metros ou menor. Verifique as feições da camada de entrada.</source>
        <translation>Total network length is 0 meters or less. Check input layer features.</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_pavement_percentage.py" line="136"/>
        <source>Extensão Total: {total:.2f} m | Pavimentada: {paved:.2f} m | Duplicada: {dup:.2f} m</source>
        <translation>Total Length: {total:.2f} m | Paved: {paved:.2f} m | Duplicated: {dup:.2f} m</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_pavement_percentage.py" line="141"/>
        <source>Percentual Pavimentada: {p_paved:.2f}% | Percentual Duplicada: {p_dup:.2f}%</source>
        <translation>Paved Percentage: {p_paved:.2f}% | Duplicated Percentage: {p_dup:.2f}%</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_pavement_percentage.py" line="158"/>
        <source>Percentual de Pavimentação e Duplicação</source>
        <translation>Paving and Dual-Carriageway Percentage</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_pavement_percentage.py" line="161"/>
        <source>Indicadores Regionais</source>
        <translation>Regional Indicators</translation>
    </message>
    <message>
        <location filename="../algorithms/regional_pavement_percentage.py" line="167"/>
        <source>Calcula o percentual da malha rodoviária regional que é pavimentada e o percentual que é duplicada.

Parâmetros:
- Camada de malha rodoviária: feições de linha representando as rodovias.
- Campo de superfície: o atributo que armazena a superfície física (ex: 'ds_superfi').

Retornos:
- Percentual da malha pavimentada (%).
- Percentual da malha duplicada (%).</source>
        <translation>Calculates the percentage of the regional highway network that is paved and the percentage that is duplicated/divided.

Parameters:
- Highway network layer: line features representing highways.
- Surface field: attribute storing physical surface (e.g. 'ds_superfi').

Returns:
- Paved highway percentage (%).
- Duplicated highway percentage (%).</translation>
    </message>
</context>
<context>
    <name>RoutingDock</name>
    <message>
        <location filename="../gui/routing_dock.py" line="254"/>
        <source>logis — Roteirização</source>
        <translation>logis — Routing</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="291"/>
        <source>&lt;b&gt;Roteirização&lt;/b&gt;</source>
        <translation>&lt;b&gt;Routing&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="202"/>
        <source>Selecione as camadas de origem, pontos a visitar e rede viária para calcular a rota otimizada (Problema do Caixeiro Viajante - TSP).</source>
        <translation type="obsolete">Select origin, visit points, and road network layers to calculate optimized route (Traveling Salesperson Problem - TSP).</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="340"/>
        <source>Camada do ponto inicial (Pontos):</source>
        <translation>Start point layer (Points):</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="346"/>
        <source>Camada de pontos a visitar (Pontos):</source>
        <translation>Points to visit layer (Points):</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="352"/>
        <source>Camada do ponto final (Pontos - opcional, vazio fecha no ponto inicial):</source>
        <translation>End point layer (Points - optional, empty closes at start point):</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="307"/>
        <source>Camada de rede viária (Linhas - opcional):</source>
        <translation>Road network layer (Lines - optional):</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="494"/>
        <source>Aplicar busca local (2-opt e Or-opt)</source>
        <translation>Apply local search (2-opt and Or-opt)</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="405"/>
        <source>Calcular Rota (TSP)</source>
        <translation>Calculate Route (TSP)</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="318"/>
        <source>Resultados da Roteirização:</source>
        <translation>Routing Results:</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="933"/>
        <source>Aviso</source>
        <translation>Warning</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="705"/>
        <source>Por favor, selecione a camada do ponto inicial.</source>
        <translation>Please select the start point layer.</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="710"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro: Ponto inicial não selecionado.&lt;/span&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Error: Start point not selected.&lt;/span&gt;</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="714"/>
        <source>Por favor, selecione a camada de pontos a visitar.</source>
        <translation>Please select points to visit layer.</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="719"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro: Pontos a visitar não selecionados.&lt;/span&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Error: Points to visit not selected.&lt;/span&gt;</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="300"/>
        <source>Erro</source>
        <translation type="obsolete">Error</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="301"/>
        <source>QGIS Processing não está disponível no ambiente atual.</source>
        <translation type="obsolete">QGIS Processing is not available in the current environment.</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="303"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro: QGIS Processing não disponível.&lt;/span&gt;</source>
        <translation type="obsolete">&lt;span style='color: #fc8181;'&gt;Error: QGIS Processing not available.&lt;/span&gt;</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="739"/>
        <source>&lt;b&gt;=== CALCULANDO ROTA (TSP) ===&lt;/b&gt;&lt;br&gt;</source>
        <translation>&lt;b&gt;=== CALCULATING ROUTE (TSP) ===&lt;/b&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="861"/>
        <source>-&gt; &lt;b&gt;Pontos visitados:&lt;/b&gt; {n}</source>
        <translation>-&gt; &lt;b&gt;Visited points:&lt;/b&gt; {n}</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="371"/>
        <source>-&gt; &lt;b&gt;Distância total do tour:&lt;/b&gt; {dist:.2f}</source>
        <translation type="obsolete">-&gt; &lt;b&gt;Total tour distance:&lt;/b&gt; {dist:.2f}</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="374"/>
        <source>-&gt; &lt;b&gt;Custo de acesso:&lt;/b&gt; {acc:.2f}</source>
        <translation type="obsolete">-&gt; &lt;b&gt;Access cost:&lt;/b&gt; {acc:.2f}</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="377"/>
        <source>-&gt; &lt;b&gt;Custo de retorno:&lt;/b&gt; {ret:.2f}</source>
        <translation type="obsolete">-&gt; &lt;b&gt;Return cost:&lt;/b&gt; {ret:.2f}</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="873"/>
        <source>-&gt; &lt;b&gt;Razão de deadhead (dead_ratio):&lt;/b&gt; {dr:.4f}</source>
        <translation>-&gt; &lt;b&gt;Deadhead ratio (dead_ratio):&lt;/b&gt; {dr:.4f}</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="876"/>
        <source>Sim (fecha no ponto inicial)</source>
        <translation>Yes (closes at start point)</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="876"/>
        <source>Não (termina no ponto final)</source>
        <translation>No (ends at end point)</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="877"/>
        <source>-&gt; &lt;b&gt;Fechamento:&lt;/b&gt; {closed}</source>
        <translation>-&gt; &lt;b&gt;Closure:&lt;/b&gt; {closed}</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="387"/>
        <source>-&gt; &lt;b&gt;Backend de otimização:&lt;/b&gt; {backend}&lt;br&gt;</source>
        <translation type="obsolete">-&gt; &lt;b&gt;Optimization backend:&lt;/b&gt; {backend}&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="902"/>
        <source>&lt;span style=&apos;color: #fc8181;&apos;&gt;Erro ao calcular rota: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Error calculating route: {error}&lt;/span&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="1082"/>
        <source>&lt;b&gt;=== CÁLCULO CONCLUÍDO ===&lt;/b&gt;</source>
        <translation>&lt;b&gt;=== CALCULATION FINISHED ===&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="234"/>
        <source>O painel reúne o Caixeiro Viajante e a Roteirização de Veículos Capacitados; a camada de rede viária escolhida abaixo vale para as duas abas.</source>
        <translation type="obsolete">The panel brings together Traveling Salesperson and Capacitated Vehicle Routing; the road network layer chosen below applies to both tabs.</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="337"/>
        <source>TSP</source>
        <translation>TSP</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="413"/>
        <source>CVRP</source>
        <translation>CVRP</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="415"/>
        <source>Resolve a roteirização de uma frota com capacidade a partir de um depósito.</source>
        <translation type="obsolete">Solves vehicle routing for a fleet with capacity starting from a depot.</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="422"/>
        <source>Nota: A camada de rede viária utilizada é a selecionada no topo do painel.</source>
        <translation>Note: The road network layer used is the one selected at the top of the panel.</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="430"/>
        <source>Camada de depósito (Pontos):</source>
        <translation type="obsolete">Depot layer (Points):</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="445"/>
        <source>Camada de demanda / clientes (Pontos):</source>
        <translation>Demand / customer layer (Points):</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="460"/>
        <source>Campo de peso/demanda (opcional, default = 1,0):</source>
        <translation>Weight/demand field (optional, default = 1.0):</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="469"/>
        <source>Capacidade do veículo:</source>
        <translation>Vehicle capacity:</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="506"/>
        <source>Executar Roteirização (CVRP)</source>
        <translation>Execute Routing (CVRP)</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="924"/>
        <source>Por favor, selecione a camada de depósito.</source>
        <translation>Please select the depot layer.</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="929"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro: Depósito não selecionado.&lt;/span&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Error: Depot not selected.&lt;/span&gt;</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="933"/>
        <source>Por favor, selecione a camada de demanda / clientes.</source>
        <translation>Please select the demand / customer layer.</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="938"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro: Camada de demanda não selecionada.&lt;/span&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Error: Demand layer not selected.&lt;/span&gt;</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="941"/>
        <source>&lt;b&gt;=== EXECUTANDO ROTEIRIZAÇÃO (CVRP) ===&lt;/b&gt;&lt;br&gt;</source>
        <translation>&lt;b&gt;=== EXECUTING ROUTING (CVRP) ===&lt;/b&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="583"/>
        <source>Rota {id}: {n} paradas | carga {load:.2f} | distância {dist:.2f}</source>
        <translation type="obsolete">Route {id}: {n} stops | load {load:.2f} | distance {dist:.2f}</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="1055"/>
        <source>-&gt; &lt;b&gt;Rotas geradas:&lt;/b&gt; {n}</source>
        <translation>-&gt; &lt;b&gt;Routes generated:&lt;/b&gt; {n}</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="1058"/>
        <source>-&gt; &lt;b&gt;Paradas atendidas:&lt;/b&gt; {n}</source>
        <translation>-&gt; &lt;b&gt;Stops served:&lt;/b&gt; {n}</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="1061"/>
        <source>-&gt; &lt;b&gt;Carga total:&lt;/b&gt; {load:.2f}</source>
        <translation>-&gt; &lt;b&gt;Total load:&lt;/b&gt; {load:.2f}</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="598"/>
        <source>-&gt; &lt;b&gt;Distância total:&lt;/b&gt; {dist:.2f}&lt;br&gt;</source>
        <translation type="obsolete">-&gt; &lt;b&gt;Total distance:&lt;/b&gt; {dist:.2f}&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="1084"/>
        <source>&lt;span style=&apos;color: #fc8181;&apos;&gt;Erro ao executar CVRP: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Error executing CVRP: {error}&lt;/span&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="295"/>
        <source>O painel reúne o Caixeiro Viajante e a Roteirização de Veículos Capacitados; a camada de rede viária escolhida abaixo vale para a aba CVRP e, na aba TSP, quando o modo &quot;pela rede viária&quot; está selecionado.</source>
        <translation>The panel brings together Traveling Salesperson and Capacitated Vehicle Routing; the road network layer selected below applies to the CVRP tab and, in the TSP tab, when the &quot;via road network&quot; mode is selected.</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="324"/>
        <source>Cancelar</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="360"/>
        <source>Modo de cálculo da distância:</source>
        <translation>Distance calculation mode:</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="362"/>
        <source>Linha reta (euclidiana)</source>
        <translation>Straight line (Euclidean)</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="362"/>
        <source>Pela rede viária (Dijkstra)</source>
        <translation>Via road network (Dijkstra)</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="368"/>
        <source>Nota: O modo &quot;pela rede viária&quot; utiliza a camada de rede escolhida no topo do painel.</source>
        <translation>Note: The &quot;via road network&quot; mode uses the network layer selected at the top of the panel.</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="477"/>
        <source>Backend de otimização:</source>
        <translation>Optimization backend:</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="479"/>
        <source>Automático (OR-Tools quando disponível)</source>
        <translation>Automatic (OR-Tools when available)</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="479"/>
        <source>Python puro (heurística)</source>
        <translation>Pure Python (heuristic)</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="479"/>
        <source>OR-Tools</source>
        <translation>OR-Tools</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="486"/>
        <source>Nota: Em modo automático, o OR-Tools é utilizado se disponível, com fallback para Python puro.</source>
        <translation>Note: In automatic mode, OR-Tools is used if available, with fallback to pure Python.</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="498"/>
        <source>Refina a rota inicial invertendo trechos (2-opt) e reposicionando paradas (Or-opt). Reduz a distância total e aumenta o tempo de cálculo.</source>
        <translation>Refines the initial route by reversing segments (2-opt) and repositioning stops (Or-opt). Reduces total distance and increases calculation time.</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="616"/>
        <source>-&gt; &lt;b&gt;Destino das saídas:&lt;/b&gt; camada temporária</source>
        <translation>-&gt; &lt;b&gt;Output destination:&lt;/b&gt; temporary layer</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="666"/>
        <source>&lt;span style='color: #ecc94b;'&gt;Aviso: Falha ao carregar camada do GPKG ({nome}). Usando camada temporária.&lt;/span&gt;</source>
        <translation>&lt;span style='color: #ecc94b;'&gt;Warning: Failed to load layer from GPKG ({nome}). Using temporary layer.&lt;/span&gt;</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="676"/>
        <source>Erro desconhecido</source>
        <translation>Unknown error</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="677"/>
        <source>&lt;span style='color: #ecc94b;'&gt;Aviso: Falha ao gravar no GPKG ({err}). Usando camada temporária.&lt;/span&gt;</source>
        <translation>&lt;span style='color: #ecc94b;'&gt;Warning: Failed to write to GPKG ({err}). Using temporary layer.&lt;/span&gt;</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="687"/>
        <source>-&gt; &lt;b&gt;Destino das saídas:&lt;/b&gt; {dest}</source>
        <translation>-&gt; &lt;b&gt;Output destination:&lt;/b&gt; {dest}</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="723"/>
        <source>O modo pela rede viária exige uma camada de rede viária no topo do painel (ex: osm_links_&lt;code_muni&gt; do pipeline OSM).</source>
        <translation>The road network mode requires a road network layer at the top of the panel (e.g. osm_links_&lt;code_muni&gt; from the OSM pipeline).</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="731"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro: O modo pela rede exige uma camada de rede viária no topo do painel (ex: osm_links_&lt;code_muni&gt; do pipeline OSM).&lt;/span&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Error: The network mode requires a road network layer at the top of the panel (e.g. osm_links_&lt;code_muni&gt; from the OSM pipeline).&lt;/span&gt;</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="944"/>
        <source>&lt;span style='color: #ecc94b;'&gt;Aviso: O OR-Tools está desativado por ter derrubado a sessão anterior. O rearme fica no diálogo de Dependências.&lt;/span&gt;&lt;br&gt;</source>
        <translation>&lt;span style='color: #ecc94b;'&gt;Warning: OR-Tools is disabled because it crashed the previous session. Reset it in the Dependencies dialog.&lt;/span&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="1002"/>
        <source>&lt;span style='color: #ecc94b;'&gt;Cálculo cancelado pelo usuário.&lt;/span&gt;&lt;br&gt;</source>
        <translation>&lt;span style='color: #ecc94b;'&gt;Calculation canceled by user.&lt;/span&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="806"/>
        <source>Erro ao calcular rota.</source>
        <translation>Error calculating route.</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="864"/>
        <source>-&gt; &lt;b&gt;Distância total do tour:&lt;/b&gt; {dist:.2f}&amp;nbsp;m</source>
        <translation>-&gt; &lt;b&gt;Total tour distance:&lt;/b&gt; {dist:.2f}&amp;nbsp;m</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="867"/>
        <source>-&gt; &lt;b&gt;Custo de acesso:&lt;/b&gt; {acc:.2f}&amp;nbsp;m</source>
        <translation>-&gt; &lt;b&gt;Access cost:&lt;/b&gt; {acc:.2f}&amp;nbsp;m</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="870"/>
        <source>-&gt; &lt;b&gt;Custo de retorno:&lt;/b&gt; {ret:.2f}&amp;nbsp;m</source>
        <translation>-&gt; &lt;b&gt;Return cost:&lt;/b&gt; {ret:.2f}&amp;nbsp;m</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="880"/>
        <source>-&gt; &lt;b&gt;Modo de distância:&lt;/b&gt; {mode}</source>
        <translation>-&gt; &lt;b&gt;Distance mode:&lt;/b&gt; {mode}</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="883"/>
        <source>-&gt; &lt;b&gt;Backend de otimização:&lt;/b&gt; {backend}</source>
        <translation>-&gt; &lt;b&gt;Optimization backend:&lt;/b&gt; {backend}</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="1075"/>
        <source>-&gt; &lt;b&gt;Tempo de cálculo:&lt;/b&gt; {t} s</source>
        <translation>-&gt; &lt;b&gt;Calculation time:&lt;/b&gt; {t} s</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="1078"/>
        <source>-&gt; &lt;b&gt;Unidade das distâncias:&lt;/b&gt; metros&lt;br&gt;</source>
        <translation>-&gt; &lt;b&gt;Distance unit:&lt;/b&gt; meters&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="894"/>
        <source>&lt;span style='color: #ecc94b;'&gt;Aviso: {n} trecho(s) caíram no segmento reto por falta de caminho na malha.&lt;/span&gt;&lt;br&gt;</source>
        <translation>&lt;span style='color: #ecc94b;'&gt;Warning: {n} segment(s) fell back to straight line due to missing path in network.&lt;/span&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="1011"/>
        <source>Erro ao executar CVRP.</source>
        <translation>Error executing CVRP.</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="1050"/>
        <source>Rota {id}: {n} paradas | carga {load:.2f} | distância {dist:.2f}&amp;nbsp;m</source>
        <translation>Route {id}: {n} stops | load {load:.2f} | distance {dist:.2f}&amp;nbsp;m</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="1064"/>
        <source>-&gt; &lt;b&gt;Distância total:&lt;/b&gt; {dist:.2f}&amp;nbsp;m&lt;br&gt;</source>
        <translation>-&gt; &lt;b&gt;Total distance:&lt;/b&gt; {dist:.2f}&amp;nbsp;m&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="989"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro ao iniciar o cálculo: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Error starting the calculation: {error}&lt;/span&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="415"/>
        <source>Resolve a roteirização de uma frota com capacidade a partir de um ou mais depósitos.</source>
        <translation>Solves vehicle routing for a fleet with capacity starting from one or more depots.</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="430"/>
        <source>Camada de depósitos (Pontos) — origem/destino das rotas:</source>
        <translation>Depot layer (Points) — origin/destination of routes:</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="436"/>
        <source>Campo ID do depósito (opcional):</source>
        <translation>Depot ID field (optional):</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="451"/>
        <source>Campo do depósito de cada ponto (opcional — vazio: depósito mais próximo):</source>
        <translation>Depot field for each point (optional — empty: nearest depot):</translation>
    </message>
    <message>
        <location filename="../gui/routing_dock.py" line="1049"/>
        <source>depósito {id}</source>
        <translation type="obsolete">depot {id}</translation>
    </message>
</context>
<context>
    <name>UrbanCargoRestriction</name>
    <message>
        <location filename="../algorithms/urban_cargo_restriction.py" line="74"/>
        <source>Camada de rede viária (Linhas)</source>
        <translation>Road network layer (Lines)</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_cargo_restriction.py" line="81"/>
        <source>Expressão de restrição (retorna verdadeiro para trechos restritos). Se vazia, usa o filtro default por tipo de via (highway), largura e peso máximo, quando esses campos existirem na camada.</source>
        <translation>Restriction expression (returns true for restricted segments). If empty, uses default filter by highway type, width, and max weight when available.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_cargo_restriction.py" line="94"/>
        <source>Índice de restrição de circulação (%)</source>
        <translation>Traffic restriction index (%)</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_cargo_restriction.py" line="106"/>
        <source>Camada de rede viária inválida.</source>
        <translation>Invalid road network layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_cargo_restriction.py" line="112"/>
        <source>Usando expressão de restrição default: {}</source>
        <translation>Using default restriction expression: {}</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_cargo_restriction.py" line="122"/>
        <source>Expressão de restrição inválida: {}</source>
        <translation>Invalid restriction expression: {}</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_cargo_restriction.py" line="134"/>
        <source>Calculando a extensão total e restrita da rede viária...</source>
        <translation>Calculating total and restricted road network length...</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_cargo_restriction.py" line="154"/>
        <source>Erro ao avaliar a expressão de restrição: {}</source>
        <translation>Error evaluating restriction expression: {}</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_cargo_restriction.py" line="168"/>
        <source>O comprimento total da rede viária calculada é 0 m ou negativo. Verifique as geometrias.</source>
        <translation>Calculated total road network length is 0 m or negative. Check geometries.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_cargo_restriction.py" line="178"/>
        <source>Comprimento Total: {total:.2f} m | Comprimento Restrito: {restricted:.2f} m</source>
        <translation>Total Length: {total:.2f} m | Restricted Length: {restricted:.2f} m</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_cargo_restriction.py" line="183"/>
        <source>Índice de Acessibilidade de Carga: {index:.2f}%</source>
        <translation>Freight Accessibility Index: {index:.2f}%</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_cargo_restriction.py" line="195"/>
        <source>Índice de Restrição de Circulação de Carga</source>
        <translation>Freight Traffic Restriction Index</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_cargo_restriction.py" line="198"/>
        <source>Indicadores Urbanos</source>
        <translation>Urban Indicators</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_cargo_restriction.py" line="204"/>
        <source>Calcula o índice de restrição de circulação para veículos de carga (acessibilidade de carga).
O índice representa o percentual da rede viária urbana que está livre de restrições de circulação.

Parâmetros:
- Camada de rede viária: feições de linha representando as vias.
- Expressão de restrição: expressão QGIS opcional que define quais trechos possuem restrições (ex: &quot;maxweight&quot; IS NOT NULL ou &quot;largura&quot; &lt; 3.0).

Retorno:
- Valor numérico (%) de 0.0 a 100.0, onde 100.0 indica que nenhuma via é restrita.</source>
        <translation>Calculates freight vehicle traffic restriction index (freight accessibility).
The index represents the percentage of the urban road network free of traffic restrictions.

Parameters:
- Road network layer: line features representing roads.
- Restriction expression: optional QGIS expression defining restricted segments (e.g. &quot;maxweight&quot; IS NOT NULL or &quot;width&quot; &lt; 3.0).

Returns:
- Numeric value (%) from 0.0 to 100.0, where 100.0 indicates no restricted roads.</translation>
    </message>
</context>
<context>
    <name>UrbanDeliveryDistance</name>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="55"/>
        <source>Camada de rede viária (Linhas)</source>
        <translation>Road network layer (Lines)</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="62"/>
        <source>Camada de depósitos candidatos (Pontos)</source>
        <translation>Candidate depots layer (Points)</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="69"/>
        <source>Camada de zonas/centroides (Pontos)</source>
        <translation>Zones/centroids layer (Points)</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="76"/>
        <source>Critério de custo</source>
        <translation>Cost criterion</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="76"/>
        <source>Distância</source>
        <translation>Distance</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="76"/>
        <source>Tempo de viagem</source>
        <translation>Travel time</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="84"/>
        <source>Zonas com custo de entrega</source>
        <translation>Zones with delivery cost</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="98"/>
        <source>Camada de rede viária inválida.</source>
        <translation>Invalid road network layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="100"/>
        <source>Camada de depósitos inválida.</source>
        <translation>Invalid depots layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="102"/>
        <source>Camada de zonas inválida.</source>
        <translation>Invalid zones layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="108"/>
        <source>Lendo depósitos...</source>
        <translation>Reading depots...</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="117"/>
        <source>Nenhum depósito válido encontrado na camada de depósitos.</source>
        <translation>No valid depot found in depots layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="120"/>
        <source>Lendo zonas...</source>
        <translation>Reading zones...</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="129"/>
        <source>Nenhuma zona válida encontrada na camada de zonas.</source>
        <translation>No valid zone found in zones layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="132"/>
        <source>Construindo o grafo a partir da rede viária...</source>
        <translation>Building graph from road network...</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="137"/>
        <source>Erro ao construir o grafo: {}</source>
        <translation>Error building graph: {}</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="143"/>
        <source>O grafo construído possui menos de 2 vértices. Não é possível calcular as distâncias.</source>
        <translation>Constructed graph has fewer than 2 vertices. Cannot calculate distances.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="154"/>
        <source>Não foi possível amarrar um ou mais depósitos à rede viária.</source>
        <translation>Could not snap one or more depots to the road network.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="156"/>
        <source>Não foi possível amarrar uma ou mais zonas à rede viária.</source>
        <translation>Could not snap one or more zones to the road network.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="159"/>
        <source>Calculando matriz de distâncias/tempos de viagem depósito-zona...</source>
        <translation>Calculating depot-zone distance/travel time matrix...</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="167"/>
        <source>Erro ao calcular a matriz OD: {}</source>
        <translation>Error calculating OD matrix: {}</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="184"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation>Could not create output layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="192"/>
        <source>Custo de entrega ao depósito mais próximo calculado para {count} zona(s).</source>
        <translation>Delivery cost to nearest depot calculated for {count} zone(s).</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="203"/>
        <source>Distância de Entrega Urbana</source>
        <translation>Urban Delivery Distance</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="206"/>
        <source>Indicadores Urbanos</source>
        <translation>Urban Indicators</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="212"/>
        <source>Calcula a distância ou tempo de entrega ao depósito mais próximo para cada zona de demanda (centroide de setor) a partir de uma camada de depósitos candidatos, usando caminhos mínimos na rede viária.

Parâmetros:
- Camada de rede viária: feições de linha representando as vias.
- Camada de depósitos candidatos: feições de ponto representando os depósitos/centros de distribuição.
- Camada de zonas/centroides: feições de ponto representando as zonas de demanda/entregas.
- Critério de custo: define se o cálculo de custo de caminho mínimo é baseado em Distância ou Tempo de viagem.

Retorno:
- Cópia da camada de zonas com a coluna 'dist_entrega' (contendo a menor distância ou tempo de viagem até o depósito mais próximo).</source>
        <translation>Calculates delivery distance or travel time to the nearest depot for each demand zone (sector centroid) from candidate depots layer, using shortest paths on road network.

Parameters:
- Road network layer: line features representing roads.
- Candidate depots layer: point features representing depots/distribution centers.
- Zones/centroids layer: point features representing demand/delivery zones.
- Cost criterion: defines whether shortest path calculation is based on Distance or Travel time.

Returns:
- Copy of zones layer with column 'dist_entrega' (containing shortest distance or travel time to nearest depot).</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="110"/>
        <source>camada de depósitos</source>
        <translation>depot layer</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_delivery_distance.py" line="122"/>
        <source>camada de zonas</source>
        <translation>zone layer</translation>
    </message>
</context>
<context>
    <name>UrbanDemandDensity</name>
    <message>
        <location filename="../algorithms/urban_demand_density.py" line="47"/>
        <source>Código IBGE do município (7 dígitos)</source>
        <translation>Municipal IBGE code (7 digits)</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_demand_density.py" line="53"/>
        <source>Campo de população (ou domicílios/empregos) na camada do censobr unida por gisbr:join_censo</source>
        <translation>Population field (or households/jobs) in censobr layer joined via gisbr:join_censo</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_demand_density.py" line="62"/>
        <source>Setores censitários com densidade de demanda</source>
        <translation>Census tracts with demand density</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_demand_density.py" line="74"/>
        <source>Código do município é obrigatório.</source>
        <translation>Municipal code is required.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_demand_density.py" line="76"/>
        <source>Campo de população é obrigatório.</source>
        <translation>Population field is required.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_demand_density.py" line="78"/>
        <source>Obtendo setores censitários do município {}...</source>
        <translation>Fetching census tracts for municipality {}...</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_demand_density.py" line="87"/>
        <source>Campo de população '{field}' não encontrado. Campos disponíveis: {available}</source>
        <translation>Population field '{field}' not found. Available fields: {available}</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_demand_density.py" line="101"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation>Could not create output layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_demand_density.py" line="107"/>
        <source>Calculando densidade de demanda por setor...</source>
        <translation>Calculating demand density per sector...</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_demand_density.py" line="123"/>
        <source>Setor {fid}: {error}</source>
        <translation>Sector {fid}: {error}</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_demand_density.py" line="136"/>
        <source>Densidade de demanda calculada para {count} setor(es).</source>
        <translation>Demand density calculated for {count} sector(s).</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_demand_density.py" line="145"/>
        <source>Densidade de Demanda Urbana</source>
        <translation>Urban Demand Density</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_demand_density.py" line="148"/>
        <source>Indicadores Urbanos</source>
        <translation>Urban Indicators</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_demand_density.py" line="154"/>
        <source>Calcula a densidade de demanda (população, domicílios ou empregos por km²) de cada setor censitário de um município, a partir dos setores + variáveis do censobr (gisbr:read_census_tract + gisbr:join_censo). Requer o plugin GisBR instalado.

Parâmetros:
- Código IBGE do município: código de 7 dígitos.
- Campo de população: nome do campo de população/domicílios/empregos na camada unida pelo censobr (varia conforme o dataset do censobr).

Retorno:
- Cópia dos setores censitários com o campo 'dens_demanda_hab_km2'.</source>
        <translation>Calculates demand density (population, households, or jobs per km²) for each census tract of a municipality, from tracts + censobr variables (gisbr:read_census_tract + gisbr:join_censo). Requires GisBR plugin installed.

Parameters:
- Municipal IBGE code: 7-digit code.
- Population field: field name for population/households/jobs in censobr joined layer (varies by censobr dataset).

Returns:
- Copy of census tracts with field 'dens_demanda_hab_km2'.</translation>
    </message>
</context>
<context>
    <name>UrbanDock</name>
    <message>
        <location filename="../gui/urban_dock.py" line="184"/>
        <source>logis — Indicadores Urbanos</source>
        <translation>logis — Urban Indicators</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="217"/>
        <source>&lt;b&gt;Indicadores Urbanos&lt;/b&gt;</source>
        <translation>&lt;b&gt;Urban Indicators&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="219"/>
        <source>Selecione as camadas e clique no botão abaixo para calcular os indicadores de densidade, conectividade, circuidade e restrição de circulação de carga.</source>
        <translation type="obsolete">Select the layers and click the button below to calculate density, connectivity, circuity, and freight traffic restriction indicators.</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="230"/>
        <source>Camada de rede viária (Linhas):</source>
        <translation type="obsolete">Road network layer (Lines):</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="254"/>
        <source>Camada de área de referência (Polígonos - para Densidade):</source>
        <translation>Reference area layer (Polygons - for Density):</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="260"/>
        <source>Calcular Indicadores</source>
        <translation>Calculate Indicators</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="241"/>
        <source>Resultados dos Indicadores:</source>
        <translation>Indicators Results:</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="292"/>
        <source>&lt;b&gt;Densidade de Demanda&lt;/b&gt;</source>
        <translation>&lt;b&gt;Demand Density&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="296"/>
        <source>Código IBGE do município (7 dígitos):</source>
        <translation>Municipal IBGE code (7 digits):</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="300"/>
        <source>Campo de população (setor + censobr, requer GisBR):</source>
        <translation>Population field (sector + censobr, requires GisBR):</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="304"/>
        <source>Calcular Densidade de Demanda</source>
        <translation>Calculate Demand Density</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="309"/>
        <source>&lt;b&gt;Acessibilidade Gravitacional&lt;/b&gt;</source>
        <translation>&lt;b&gt;Gravitational Accessibility&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="313"/>
        <source>Camada de origem (pontos/centroides):</source>
        <translation>Origin layer (points/centroids):</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="318"/>
        <source>Camada de destinos (POIs):</source>
        <translation>Destinations layer (POIs):</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="323"/>
        <source>Campo de peso do destino (opcional, default 1):</source>
        <translation>Destination weight field (optional, default 1):</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="329"/>
        <source>Beta (decaimento por distância):</source>
        <translation>Beta (distance decay):</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="336"/>
        <source>Calcular Acessibilidade Gravitacional</source>
        <translation>Calculate Gravitational Accessibility</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="266"/>
        <source>&lt;b&gt;Centralidade de Intermediação (Betweenness)&lt;/b&gt;</source>
        <translation>&lt;b&gt;Betweenness Centrality&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="270"/>
        <source>Número de amostras (pares OD):</source>
        <translation>Number of samples (OD pairs):</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="283"/>
        <source>Calcular Centralidade de Intermediação</source>
        <translation>Calculate Betweenness Centrality</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="361"/>
        <source>&lt;b&gt;Distância de Entrega&lt;/b&gt;</source>
        <translation>&lt;b&gt;Delivery Distance&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="365"/>
        <source>Camada de depósitos candidatos (Pontos):</source>
        <translation>Candidate depots layer (Points):</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="370"/>
        <source>Camada de zonas/centroides (Pontos):</source>
        <translation>Zones/centroids layer (Points):</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="375"/>
        <source>Critério de custo:</source>
        <translation>Cost criterion:</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="377"/>
        <source>Distância</source>
        <translation>Distance</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="377"/>
        <source>Tempo de viagem</source>
        <translation>Travel time</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="380"/>
        <source>Calcular Distância de Entrega</source>
        <translation>Calculate Delivery Distance</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="741"/>
        <source>Aviso</source>
        <translation>Warning</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="727"/>
        <source>Por favor, selecione uma camada de rede viária.</source>
        <translation>Please select a road network layer.</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="404"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro: Camada de rede viária não selecionada.&lt;/span&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Error: Road network layer not selected.&lt;/span&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="751"/>
        <source>Erro</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="751"/>
        <source>QGIS Processing não está disponível no ambiente atual.</source>
        <translation>QGIS Processing is not available in the current environment.</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="415"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro: QGIS Processing não disponível.&lt;/span&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Error: QGIS Processing not available.&lt;/span&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="419"/>
        <source>&lt;b&gt;=== INICIANDO CÁLCULO DOS INDICADORES ===&lt;/b&gt;&lt;br&gt;</source>
        <translation>&lt;b&gt;=== STARTING INDICATORS CALCULATION ===&lt;/b&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="423"/>
        <source>&lt;i&gt;1) Densidade viária: Pulado (camada de área não selecionada)&lt;/i&gt;&lt;br&gt;</source>
        <translation>&lt;i&gt;1) Road density: Skipped (unselected area layer)&lt;/i&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="425"/>
        <source>1) Calculando densidade viária...</source>
        <translation>1) Calculating road density...</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="433"/>
        <source>   -&gt; &lt;b&gt;Densidade viária:&lt;/b&gt; {value:.4f} km/km²&lt;br&gt;</source>
        <translation>   -&gt; &lt;b&gt;Road density:&lt;/b&gt; {value:.4f} km/km²&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="437"/>
        <source>   -&gt; &lt;b&gt;Densidade viária:&lt;/b&gt; N/A (resultado vazio)&lt;br&gt;</source>
        <translation>   -&gt; &lt;b&gt;Road density:&lt;/b&gt; N/A (empty result)&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="439"/>
        <source>   -&gt; &lt;span style=&apos;color: #fc8181;&apos;&gt;Erro ao calcular densidade: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation>   -&gt; &lt;span style='color: #fc8181;'&gt;Error calculating density: {error}&lt;/span&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="444"/>
        <source>2) Calculando conectividade da rede...</source>
        <translation>2) Calculating network connectivity...</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="457"/>
        <source>   -&gt; &lt;b&gt;Número de nós (v):&lt;/b&gt; {v}</source>
        <translation>   -&gt; &lt;b&gt;Number of nodes (v):&lt;/b&gt; {v}</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="458"/>
        <source>   -&gt; &lt;b&gt;Número de arestas (e):&lt;/b&gt; {e}</source>
        <translation>   -&gt; &lt;b&gt;Number of edges (e):&lt;/b&gt; {e}</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="460"/>
        <source>   -&gt; &lt;b&gt;Índice Alfa:&lt;/b&gt; {v:.4f}</source>
        <translation>   -&gt; &lt;b&gt;Alpha Index:&lt;/b&gt; {v:.4f}</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="462"/>
        <source>   -&gt; &lt;b&gt;Índice Beta:&lt;/b&gt; {v:.4f}</source>
        <translation>   -&gt; &lt;b&gt;Beta Index:&lt;/b&gt; {v:.4f}</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="464"/>
        <source>   -&gt; &lt;b&gt;Índice Gama:&lt;/b&gt; {v:.4f}</source>
        <translation>   -&gt; &lt;b&gt;Gamma Index:&lt;/b&gt; {v:.4f}</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="466"/>
        <source>   -&gt; &lt;b&gt;Cruzamentos 4+ pernas:&lt;/b&gt; {v:.2f}%</source>
        <translation>   -&gt; &lt;b&gt;4+ leg intersections:&lt;/b&gt; {v:.2f}%</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="468"/>
        <source>   -&gt; &lt;b&gt;Becos sem saída:&lt;/b&gt; {v:.2f}%&lt;br&gt;</source>
        <translation>   -&gt; &lt;b&gt;Dead-end streets:&lt;/b&gt; {v:.2f}%&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="470"/>
        <source>   -&gt; &lt;span style=&apos;color: #fc8181;&apos;&gt;Erro ao calcular conectividade: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation>   -&gt; &lt;span style='color: #fc8181;'&gt;Error calculating connectivity: {error}&lt;/span&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="475"/>
        <source>3) Calculando circuidade média (amostragem)...</source>
        <translation>3) Calculating average circuity (sampling)...</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="484"/>
        <source>   -&gt; &lt;b&gt;Circuidade média:&lt;/b&gt; {value:.4f}&lt;br&gt;</source>
        <translation>   -&gt; &lt;b&gt;Average circuity:&lt;/b&gt; {value:.4f}&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="488"/>
        <source>   -&gt; &lt;b&gt;Circuidade média:&lt;/b&gt; N/A (resultado vazio)&lt;br&gt;</source>
        <translation>   -&gt; &lt;b&gt;Average circuity:&lt;/b&gt; N/A (empty result)&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="490"/>
        <source>   -&gt; &lt;span style=&apos;color: #fc8181;&apos;&gt;Erro ao calcular circuidade: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation>   -&gt; &lt;span style='color: #fc8181;'&gt;Error calculating circuity: {error}&lt;/span&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="414"/>
        <source>4) Calculando acessibilidade/restrição de carga...</source>
        <translation type="obsolete">4) Calculating freight accessibility/restriction...</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="531"/>
        <source>   -&gt; &lt;b&gt;Acessibilidade de carga:&lt;/b&gt; {value:.2f}%&lt;br&gt;</source>
        <translation>   -&gt; &lt;b&gt;Freight accessibility:&lt;/b&gt; {value:.2f}%&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="535"/>
        <source>   -&gt; &lt;b&gt;Acessibilidade de carga:&lt;/b&gt; N/A (resultado vazio)&lt;br&gt;</source>
        <translation>   -&gt; &lt;b&gt;Freight accessibility:&lt;/b&gt; N/A (empty result)&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="537"/>
        <source>   -&gt; &lt;span style='color: #fc8181;'&gt;Erro ao calcular restrição: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation>   -&gt; &lt;span style='color: #fc8181;'&gt;Error calculating restriction: {error}&lt;/span&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="494"/>
        <source>&lt;b&gt;=== CÁLCULO CONCLUÍDO ===&lt;/b&gt;</source>
        <translation>&lt;b&gt;=== CALCULATION COMPLETED ===&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="550"/>
        <source>Por favor, informe o código IBGE do município.</source>
        <translation>Please specify the municipal IBGE code.</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="557"/>
        <source>Por favor, informe o campo de população.</source>
        <translation>Please specify the population field.</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="574"/>
        <source>&lt;b&gt;Calculando densidade de demanda...&lt;/b&gt;</source>
        <translation>&lt;b&gt;Calculating demand density...&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="585"/>
        <source>   -&gt; &lt;b&gt;Densidade de demanda:&lt;/b&gt; camada adicionada ao projeto com {count} setor(es).&lt;br&gt;</source>
        <translation>   -&gt; &lt;b&gt;Demand density:&lt;/b&gt; layer added to the project with {count} tract(s).&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="589"/>
        <source>   -&gt; &lt;b&gt;Densidade de demanda:&lt;/b&gt; N/A (resultado vazio)&lt;br&gt;</source>
        <translation>   -&gt; &lt;b&gt;Demand density:&lt;/b&gt; N/A (empty result)&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="591"/>
        <source>   -&gt; &lt;span style=&apos;color: #fc8181;&apos;&gt;Erro ao calcular densidade de demanda: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation>   -&gt; &lt;span style='color: #fc8181;'&gt;Error calculating demand density: {error}&lt;/span&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="614"/>
        <source>Por favor, selecione uma camada de origem.</source>
        <translation>Please select an origin layer.</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="621"/>
        <source>Por favor, selecione uma camada de destinos.</source>
        <translation>Please select a destinations layer.</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="638"/>
        <source>&lt;b&gt;Calculando acessibilidade gravitacional...&lt;/b&gt;</source>
        <translation>&lt;b&gt;Calculating gravitational accessibility...&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="654"/>
        <source>   -&gt; &lt;b&gt;Acessibilidade gravitacional:&lt;/b&gt; camada adicionada ao projeto com {count} origem(ns).&lt;br&gt;</source>
        <translation>   -&gt; &lt;b&gt;Gravitational accessibility:&lt;/b&gt; layer added to the project with {count} origin(s).&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="658"/>
        <source>   -&gt; &lt;b&gt;Acessibilidade gravitacional:&lt;/b&gt; N/A (resultado vazio)&lt;br&gt;</source>
        <translation>   -&gt; &lt;b&gt;Gravitational accessibility:&lt;/b&gt; N/A (empty result)&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="660"/>
        <source>   -&gt; &lt;span style=&apos;color: #fc8181;&apos;&gt;Erro ao calcular acessibilidade gravitacional: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation>   -&gt; &lt;span style='color: #fc8181;'&gt;Error calculating gravitational accessibility: {error}&lt;/span&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="692"/>
        <source>&lt;b&gt;Calculando centralidade de intermediação...&lt;/b&gt;</source>
        <translation>&lt;b&gt;Calculating betweenness centrality...&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="706"/>
        <source>   -&gt; &lt;b&gt;Centralidade de intermediação:&lt;/b&gt; camada adicionada ao projeto com {count} aresta(s).&lt;br&gt;</source>
        <translation>   -&gt; &lt;b&gt;Betweenness centrality:&lt;/b&gt; layer added to the project with {count} edge(s).&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="710"/>
        <source>   -&gt; &lt;b&gt;Centralidade de intermediação:&lt;/b&gt; N/A (resultado vazio)&lt;br&gt;</source>
        <translation>   -&gt; &lt;b&gt;Betweenness centrality:&lt;/b&gt; N/A (empty result)&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="712"/>
        <source>   -&gt; &lt;span style='color: #fc8181;'&gt;Erro ao calcular centralidade de intermediação: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation>   -&gt; &lt;span style='color: #fc8181;'&gt;Error calculating betweenness centrality: {error}&lt;/span&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="734"/>
        <source>Por favor, selecione uma camada de depósitos candidatos.</source>
        <translation>Please select a candidate depots layer.</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="741"/>
        <source>Por favor, selecione uma camada de zonas/centroides.</source>
        <translation>Please select a zones/centroids layer.</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="758"/>
        <source>&lt;b&gt;Calculando distância de entrega...&lt;/b&gt;</source>
        <translation>&lt;b&gt;Calculating delivery distance...&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="771"/>
        <source>   -&gt; &lt;b&gt;Distância de entrega:&lt;/b&gt; camada adicionada ao projeto com {count} zona(s).&lt;br&gt;</source>
        <translation>   -&gt; &lt;b&gt;Delivery distance:&lt;/b&gt; layer added to the project with {count} zone(s).&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="775"/>
        <source>   -&gt; &lt;b&gt;Distância de entrega:&lt;/b&gt; N/A (resultado vazio)&lt;br&gt;</source>
        <translation>   -&gt; &lt;b&gt;Delivery distance:&lt;/b&gt; N/A (empty result)&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="777"/>
        <source>   -&gt; &lt;span style='color: #fc8181;'&gt;Erro ao calcular distância de entrega: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation>   -&gt; &lt;span style='color: #fc8181;'&gt;Error calculating delivery distance: {error}&lt;/span&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="251"/>
        <source>Rede</source>
        <translation>Network</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="289"/>
        <source>Demanda</source>
        <translation>Demand</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="342"/>
        <source>Carga</source>
        <translation>Cargo</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="345"/>
        <source>&lt;b&gt;Restrição de Circulação de Carga&lt;/b&gt;</source>
        <translation>&lt;b&gt;Cargo Circulation Restriction&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="349"/>
        <source>Expressão de restrição (opcional, ex: maxweight / highway):</source>
        <translation>Restriction expression (optional, e.g., maxweight / highway):</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="351"/>
        <source>Ex: &quot;highway&quot; = &apos;residential&apos; OR &quot;maxweight&quot; &lt; 3.5</source>
        <translation>E.g.: &quot;highway&quot; = 'residential' OR &quot;maxweight&quot; &lt; 3.5</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="356"/>
        <source>Calcular Restrição de Carga</source>
        <translation>Calculate Cargo Restriction</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="523"/>
        <source>&lt;b&gt;Calculando restrição de circulação de carga...&lt;/b&gt;</source>
        <translation>&lt;b&gt;Calculating cargo circulation restriction...&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="221"/>
        <source>A camada de rede viária escolhida abaixo vale para as três abas (Rede, Demanda, Carga); cada aba tem seu próprio botão de cálculo.</source>
        <translation>The road network layer selected below applies to all three tabs (Network, Demand, Cargo); each tab has its own calculation button.</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="232"/>
        <source>Camada de rede viária (Linhas) — usada por todas as abas:</source>
        <translation>Road network layer (Lines) — used by all tabs:</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="276"/>
        <source>Semente da amostragem (opcional, 0 = aleatório):</source>
        <translation>Sampling seed (optional, 0 = random):</translation>
    </message>
    <message>
        <location filename="../gui/urban_dock.py" line="279"/>
        <source>Aleatória</source>
        <translation>Random</translation>
    </message>
</context>
<context>
    <name>UrbanEdgeBetweenness</name>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="57"/>
        <source>Camada de rede viária (Linhas)</source>
        <translation>Road network layer (Lines)</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="64"/>
        <source>Número de amostras (pares OD)</source>
        <translation>Number of samples (OD pairs)</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="73"/>
        <source>Semente aleatória (opcional, para reprodutibilidade)</source>
        <translation>Random seed (optional, for reproducibility)</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="80"/>
        <source>Arestas com centralidade de intermediação</source>
        <translation>Edges with betweenness centrality</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="96"/>
        <source>Camada de rede viária inválida.</source>
        <translation>Invalid road network layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="98"/>
        <source>Construindo o grafo a partir da rede viária...</source>
        <translation>Building graph from road network...</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="102"/>
        <source>Erro ao construir o grafo: {}</source>
        <translation>Error building graph: {}</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="108"/>
        <source>O grafo construído está vazio.</source>
        <translation>The constructed graph is empty.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="110"/>
        <source>Grafo construído: {v} vértices, {e} arestas.</source>
        <translation>Graph built: {v} vertices, {e} edges.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="116"/>
        <source>Amostrando pares OD e calculando a centralidade de intermediação...</source>
        <translation>Sampling OD pairs and calculating betweenness centrality...</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="132"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation>Could not create output layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="147"/>
        <source>Centralidade de intermediação máxima observada: {max_score:.4f}</source>
        <translation>Maximum observed betweenness centrality: {max_score:.4f}</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="160"/>
        <source>Centralidade de Intermediação de Arestas (Betweenness)</source>
        <translation>Edge Betweenness Centrality</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="163"/>
        <source>Indicadores Urbanos</source>
        <translation>Urban Indicators</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_edge_betweenness.py" line="169"/>
        <source>Calcula a centralidade de intermediação (betweenness) aproximada de cada aresta de uma rede viária urbana, por amostragem de pares origem-destino e caminhos mínimos de Dijkstra.

Parâmetros:
- Camada de rede viária: feições de linha representando as vias.
- Número de amostras (pares OD): número de pares a amostrar (default 1000).
- Semente aleatória: opcional, para reprodutibilidade da amostragem.

Retorno:
- Camada de linhas com o campo 'betweenness' (0.0 a 1.0), uma feição por aresta do grafo.</source>
        <translation>Calculates approximate edge betweenness centrality for an urban road network via shortest path sampling between random OD pairs.

Parameters:
- Road network layer: line features representing roads.
- Sample count: number of random origin-destination pairs to sample (default=1,000).
- Seed: integer for reproducibility (optional).

Returns:
- Copy of road network layer with new column 'betweenness' (calculated score).</translation>
    </message>
</context>
<context>
    <name>UrbanGravityAccessibility</name>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="57"/>
        <source>Camada de rede viária (Linhas)</source>
        <translation>Road network layer (Lines)</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="64"/>
        <source>Camada de origem (pontos/centroides)</source>
        <translation>Origin layer (points/centroids)</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="71"/>
        <source>Camada de destinos (POIs)</source>
        <translation>Destinations layer (POIs)</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="78"/>
        <source>Campo de peso/atratividade do destino (opcional, default 1 para todos)</source>
        <translation>Destination weight/attractiveness field (optional, default 1 for all)</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="87"/>
        <source>Parâmetro de decaimento por distância (beta)</source>
        <translation>Distance decay parameter (beta)</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="96"/>
        <source>Origem com acessibilidade gravitacional</source>
        <translation>Origin with gravitational accessibility</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="111"/>
        <source>Camada de rede viária inválida.</source>
        <translation>Invalid road network layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="113"/>
        <source>Camada de origem inválida.</source>
        <translation>Invalid origin layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="115"/>
        <source>Camada de destinos inválida.</source>
        <translation>Invalid destinations layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="125"/>
        <source>Lendo origens...</source>
        <translation>Reading origins...</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="134"/>
        <source>Nenhuma origem válida encontrada na camada de origem.</source>
        <translation>No valid origin found in origin layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="137"/>
        <source>Lendo destinos e pesos...</source>
        <translation>Reading destinations and weights...</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="153"/>
        <source>Nenhum destino válido encontrado na camada de destinos.</source>
        <translation>No valid destination found in destinations layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="156"/>
        <source>Construindo o grafo a partir da rede viária...</source>
        <translation>Building graph from road network...</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="161"/>
        <source>Erro ao construir o grafo: {}</source>
        <translation>Error building graph: {}</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="167"/>
        <source>O grafo construído possui menos de 2 vértices. Não é possível calcular a acessibilidade.</source>
        <translation>Constructed graph has fewer than 2 vertices. Cannot calculate accessibility.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="178"/>
        <source>Não foi possível amarrar uma ou mais origens à rede viária.</source>
        <translation>Could not snap one or more origins to the road network.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="180"/>
        <source>Não foi possível amarrar um ou mais destinos à rede viária.</source>
        <translation>Could not snap one or more destinations to the road network.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="183"/>
        <source>Calculando matriz de distâncias origem-destino...</source>
        <translation>Calculating origin-destination distance matrix...</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="190"/>
        <source>Erro ao calcular a matriz OD: {}</source>
        <translation>Error calculating OD matrix: {}</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="207"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation>Could not create output layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="215"/>
        <source>Acessibilidade gravitacional calculada para {count} origem(ns).</source>
        <translation>Gravitational accessibility calculated for {count} origin(s).</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="226"/>
        <source>Acessibilidade Gravitacional Urbana</source>
        <translation>Urban Gravitational Accessibility</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="229"/>
        <source>Indicadores Urbanos</source>
        <translation>Urban Indicators</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="235"/>
        <source>Calcula a acessibilidade gravitacional de cada origem (ex.: centroides de setor) a uma camada de destinos ponderados (ex.: POIs, comércio, empregos), usando caminhos mínimos sobre a rede viária urbana.

Parâmetros:
- Camada de rede viária: feições de linha representando as vias.
- Camada de origem: feições de ponto (ex.: centroides de setor, saída do indicador de densidade de demanda).
- Camada de destinos (POIs): feições de ponto com os destinos.
- Campo de peso/atratividade do destino: campo numérico opcional (default 1 para todos os destinos).
- Beta: parâmetro de decaimento por distância do modelo gravitacional (default 2.0).

Retorno:
- Cópia da camada de origem com o campo 'acess_gravit' (índice de acessibilidade gravitacional).</source>
        <translation>Calculates gravitational accessibility to points of interest (destinations) for each origin point or polygon centroid, weighted by travel distance or time on the road network.

Parameters:
- Origin layer: point or polygon features representing demand origins.
- Destinations layer: point features representing POIs or destinations.
- Destination weight field (optional): numeric field with the weight/attractiveness of each destination (default=1.0 for all).
- Road network layer: line features representing the road network.
- Cost criterion: Distance (m) or Travel time (min).
- Maximum search distance: limit beyond which destinations are ignored (default=10,000 m or min).

Returns:
- Copy of origin layer with new column 'grav_access' (calculated gravitational accessibility score).</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="127"/>
        <source>camada de origem</source>
        <translation>origin layer</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_gravity_accessibility.py" line="139"/>
        <source>camada de destinos</source>
        <translation>destination layer</translation>
    </message>
</context>
<context>
    <name>UrbanMeanCircuity</name>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="51"/>
        <source>Camada de rede viária (Linhas)</source>
        <translation>Road network layer (Lines)</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="58"/>
        <source>Número de amostras (pares OD)</source>
        <translation>Number of samples (OD pairs)</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="67"/>
        <source>Distância euclidiana mínima (metros)</source>
        <translation>Minimum euclidean distance (meters)</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="76"/>
        <source>Circuidade média</source>
        <translation>Average circuity</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="89"/>
        <source>Camada de rede viária inválida.</source>
        <translation>Invalid road network layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="91"/>
        <source>Construindo o grafo a partir da rede viária...</source>
        <translation>Building graph from road network...</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="95"/>
        <source>Erro ao construir o grafo: {}</source>
        <translation>Error building graph: {}</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="101"/>
        <source>O grafo construído possui menos de 2 vértices. Não é possível calcular a circuidade.</source>
        <translation>Constructed graph has fewer than 2 vertices. Cannot calculate circuity.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="105"/>
        <source>Grafo construído: {v} vértices, {e} arestas.</source>
        <translation>Graph built: {v} vertices, {e} edges.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="111"/>
        <source>Amostrando pares de pontos para o cálculo da circuidade...</source>
        <translation>Sampling point pairs for circuity calculation...</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="169"/>
        <source>Não foi possível encontrar nenhum par de pontos válido que satisfaça a distância mínima de {min_dist} metros.</source>
        <translation>Could not find any valid point pair satisfying minimum distance of {min_dist} meters.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="176"/>
        <source>Calculando circuidade média com {count} amostras válidas...</source>
        <translation>Calculating average circuity with {count} valid samples...</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="187"/>
        <source>Circuidade média calculada: {circuity:.4f}</source>
        <translation>Average circuity calculated: {circuity:.4f}</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="196"/>
        <source>Circuidade Média de Rede Viária Urbana</source>
        <translation>Average Circuity of Urban Road Network</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="199"/>
        <source>Indicadores Urbanos</source>
        <translation>Urban Indicators</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_mean_circuity.py" line="205"/>
        <source>Calcula a circuidade média de uma rede viária urbana a partir de amostras de caminhos mínimos.

Parâmetros:
- Camada de rede viária: feições de linha representando as vias.
- Número de amostras (pares OD): número de caminhos a amostrar (default 1000).
- Distância euclidiana mínima: distância mínima em metros entre origem e destino (default 100m).

Retorno:
- Valor numérico contendo a circuidade média (distância rede / distância euclidiana).</source>
        <translation>Calculates the average circuity (network distance / euclidean distance) of an urban road network via shortest path sampling between random OD pairs.

Parameters:
- Road network layer: line features representing roads.
- Sample count: number of random origin-destination pairs to sample (default=500).
- Seed: integer for reproducibility (optional).

Returns:
- Numeric value (float &gt;= 1.0) representing the average circuity ratio.</translation>
    </message>
</context>
<context>
    <name>UrbanNetworkConnectivity</name>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="47"/>
        <source>Camada de rede viária (Linhas)</source>
        <translation>Road network layer (Lines)</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="54"/>
        <source>Número de nós (v)</source>
        <translation>Number of nodes (v)</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="60"/>
        <source>Número de arestas (e)</source>
        <translation>Number of edges (e)</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="66"/>
        <source>Índice Alfa</source>
        <translation>Alpha Index</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="72"/>
        <source>Índice Beta</source>
        <translation>Beta Index</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="78"/>
        <source>Índice Gama</source>
        <translation>Gamma Index</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="84"/>
        <source>Percentual de interseções com grau 4 ou mais</source>
        <translation>Percentage of 4+ leg intersections</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="90"/>
        <source>Percentual de becos sem saída</source>
        <translation>Percentage of dead-end streets</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="101"/>
        <source>Camada de rede viária inválida.</source>
        <translation>Invalid road network layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="103"/>
        <source>Construindo o grafo a partir da rede viária...</source>
        <translation>Building graph from road network...</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="108"/>
        <source>Erro ao construir o grafo: {}</source>
        <translation>Error building graph: {}</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="113"/>
        <source>O grafo construído não possui vértices.</source>
        <translation>The constructed graph has no vertices.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="116"/>
        <source>Calculando os graus dos nós...</source>
        <translation>Calculating node degrees...</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="140"/>
        <source>Calculando os indicadores de conectividade...</source>
        <translation>Calculating connectivity indicators...</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="147"/>
        <source>Nós (v): {v} | Arestas (e): {e}</source>
        <translation>Nodes (v): {v} | Edges (e): {e}</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="150"/>
        <source>Índices: Alfa={alpha:.4f} | Beta={beta:.4f} | Gama={gamma:.4f}</source>
        <translation>Indices: Alpha={alpha:.4f} | Beta={beta:.4f} | Gamma={gamma:.4f}</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="155"/>
        <source>Interseções 4+ pernas: {pct_4:.2f}% | Becos sem saída: {pct_dead:.2f}%</source>
        <translation>4+ leg intersections: {pct_4:.2f}% | Dead-end streets: {pct_dead:.2f}%</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="177"/>
        <source>Conectividade de Rede Viária Urbana</source>
        <translation>Urban Road Network Connectivity</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="180"/>
        <source>Indicadores Urbanos</source>
        <translation>Urban Indicators</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_connectivity.py" line="186"/>
        <source>Calcula indicadores de conectividade para uma rede viária urbana a partir dos graus de seus nós.

Parâmetros:
- Camada de rede viária: feições de linha representando as vias.

Retornos:
- Número de nós (v)
- Número de arestas (e)
- Índice Alfa (0 a 1)
- Índice Beta (links por nó)
- Índice Gama (0 a 1)
- Percentual de interseções com grau 4 ou mais (cruzamentos de 4 pernas)
- Percentual de becos sem saída (grau 1)</source>
        <translation>Calculates connectivity indicators for an urban road network based on node degrees.

Parameters:
- Road network layer: line features representing roads.

Returns:
- Number of nodes (v)
- Number of edges (e)
- Alpha Index (0 to 1)
- Beta Index (links per node)
- Gamma Index (0 to 1)
- Percentage of 4+ leg intersections
- Percentage of dead-end streets (degree 1)</translation>
    </message>
</context>
<context>
    <name>UrbanNetworkDensity</name>
    <message>
        <location filename="../algorithms/urban_network_density.py" line="42"/>
        <source>Camada de rede viária (Linhas)</source>
        <translation>Road network layer (Lines)</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_density.py" line="49"/>
        <source>Camada de área de referência (Polígonos)</source>
        <translation>Reference area layer (Polygons)</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_density.py" line="56"/>
        <source>Densidade da rede viária (km/km²)</source>
        <translation>Road network density (km/km²)</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_density.py" line="68"/>
        <source>Camada de rede viária inválida.</source>
        <translation>Invalid road network layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_density.py" line="70"/>
        <source>Camada de área de referência inválida.</source>
        <translation>Invalid reference area layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_density.py" line="79"/>
        <source>Calculando a extensão total da rede viária...</source>
        <translation>Calculating total road network length...</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_density.py" line="96"/>
        <source>Calculando a área total do polígono de referência...</source>
        <translation>Calculating total reference polygon area...</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_density.py" line="111"/>
        <source>A área calculada é de 0 km² ou negativa. Verifique a geometria de referência.</source>
        <translation>Calculated area is 0 km² or negative. Check reference geometry.</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_density.py" line="121"/>
        <source>Comprimento da Rede: {length:.2f} m | Área: {area:.4f} km²</source>
        <translation>Network Length: {length:.2f} m | Area: {area:.4f} km²</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_density.py" line="126"/>
        <source>Densidade Calculada: {density:.4f} km/km²</source>
        <translation>Calculated Density: {density:.4f} km/km²</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_density.py" line="136"/>
        <source>Densidade de Rede Viária Urbana</source>
        <translation>Urban Road Network Density</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_density.py" line="139"/>
        <source>Indicadores Urbanos</source>
        <translation>Urban Indicators</translation>
    </message>
    <message>
        <location filename="../algorithms/urban_network_density.py" line="145"/>
        <source>Calcula a densidade da rede viária em km de via por km² de área de referência.

Parâmetros:
- Camada de rede viária: feições de linha representando as vias.
- Camada de área de referência: feições de polígono definindo a área territorial.

Retorno:
- Valor numérico contendo a densidade em km/km².</source>
        <translation>Calculates road network density in km of road per km² of reference area.

Parameters:
- Road network layer: line features representing roads.
- Reference area layer: polygon features defining land area.

Returns:
- Numeric value containing density in km/km².</translation>
    </message>
</context>
<context>
    <name>VrpCvrp</name>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="181"/>
        <source>Camada de depósito (Pontos/Polígonos)</source>
        <translation>Depot layer (Points/Polygons)</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="197"/>
        <source>Camada de demanda / clientes (Pontos/Polígonos)</source>
        <translation>Demand / customer layer (Points/Polygons)</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="213"/>
        <source>Campo de peso/demanda (opcional, default=1.0)</source>
        <translation>Demand/weight field (optional, default=1.0)</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="222"/>
        <source>Capacidade do veículo</source>
        <translation>Vehicle capacity</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="231"/>
        <source>Camada de rede viária (Linhas) (opcional)</source>
        <translation>Road network layer (Lines) (optional)</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="239"/>
        <source>Aplicar busca local (2-opt e Or-opt)</source>
        <translation>Apply local search (2-opt and Or-opt)</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="258"/>
        <source>Rotas geradas</source>
        <translation>Generated routes</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="264"/>
        <source>Paradas por rota (opcional)</source>
        <translation>Stops per route (optional)</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="297"/>
        <source>Camada de depósito inválida.</source>
        <translation>Invalid depot layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="299"/>
        <source>Camada de demanda inválida.</source>
        <translation>Invalid demand layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="301"/>
        <source>A capacidade do veículo deve ser estritamente maior que zero.</source>
        <translation>Vehicle capacity must be strictly greater than zero.</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="318"/>
        <source>Nenhum ponto de depósito válido encontrado.</source>
        <translation>No valid depot point found.</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="326"/>
        <source>Lendo pontos de demanda...</source>
        <translation>Reading demand points...</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="360"/>
        <source>A demanda do nó excede a capacidade máxima do veículo ({weight} &gt; {cap}).</source>
        <translation>Node demand exceeds maximum vehicle capacity ({weight} &gt; {cap}).</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="387"/>
        <source>Nenhum ponto de demanda válido encontrado.</source>
        <translation>No valid demand point found.</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="509"/>
        <source>Construindo o grafo e calculando a matriz OD na rede...</source>
        <translation>Building graph and calculating network OD matrix...</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="543"/>
        <source>Erro ao construir o grafo: {}</source>
        <translation>Error building graph: {}</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="550"/>
        <source>O grafo construído possui menos de 2 vértices.</source>
        <translation>The constructed graph has fewer than 2 vertices.</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="569"/>
        <source>Erro ao calcular a matriz OD: {}</source>
        <translation>Error calculating OD matrix: {}</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="574"/>
        <source>Calculando matriz de distâncias euclidianas...</source>
        <translation>Calculating euclidean distance matrix...</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="272"/>
        <source>Executando a otimização CVRP (Clarke-Wright + 2-opt/Or-opt)...</source>
        <translation type="obsolete">Running CVRP optimization (Clarke-Wright + 2-opt/Or-opt)...</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="284"/>
        <source>Roteirização concluída. Rotas geradas: {count} | Distância Total: {dist:.2f}</source>
        <translation type="obsolete">Routing completed. Generated routes: {count} | Total Distance: {dist:.2f}</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="800"/>
        <source>Roteirização de Veículos Capacitados (CVRP)</source>
        <translation>Capacitated Vehicle Routing (CVRP)</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="803"/>
        <source>Roteirização</source>
        <translation>Routing</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="364"/>
        <source>Resolve o Problema de Roteirização de Veículos Capacitados (CVRP) a partir de uma camada de depósito e uma camada de pontos de demanda (clientes).

Constroi rotas que iniciam e terminam no depósito, respeitando a capacidade máxima do veículo, utilizando a heurística de economias de Clarke &amp; Wright (1964) e refinamento opcional por busca local 2-opt (Lin, 1965) e Or-opt (Or, 1976).

Parâmetros:
- Camada de depósito: feição de ponto/polígono representando o depósito de partida/chegada.
- Camada de demanda / clientes: feições de pontos ou polígonos com demandas a atender.
- Campo de peso/demanda: campo numérico da demanda de cada cliente (opcional, default=1.0).
- Capacidade do veículo: carga máxima transportada por cada veículo em uma rota.
- Camada de rede viária: rede viária para distâncias reais (opcional, usa distância euclidiana se omitida).
- Aplicar busca local: se verdadeiro, aplica 2-opt e Or-opt para otimização de cada rota.

Saídas:
- Rotas geradas: camada de linhas com a geometria das rotas e estatísticas de carga e distância.
- Paradas por rota: camada de pontos ordenada com atribuição de rota e carga acumulada.</source>
        <translation type="obsolete">Builds routes starting and ending at the depot while respecting maximum vehicle capacity, using Clarke &amp; Wright (1964) savings heuristic and optional local search refinement via 2-opt (Lin, 1965) and Or-opt (Or, 1976).

Parameters:
- Depot layer: point/polygon feature representing departure/arrival depot.
- Demand / customer layer: point or polygon features with demands to serve.
- Weight/demand field: numeric field of each customer's demand (optional, default=1.0).
- Vehicle capacity: maximum payload transported by each vehicle on a route.
- Road network layer: road network for real distances (optional, uses euclidean distance if omitted).
- Apply local search: if true, applies 2-opt and Or-opt to optimize each route.

Outputs:
- Generated routes: line layer with route geometries and payload/distance statistics.
- Stops per route: ordered point layer with route assignment and cumulative payload.</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="246"/>
        <source>Backend de otimização</source>
        <translation>Optimization backend</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="246"/>
        <source>Automático (OR-Tools quando disponível)</source>
        <translation>Automatic (OR-Tools when available)</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="246"/>
        <source>Python puro (heurística)</source>
        <translation>Pure Python (heuristic)</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="246"/>
        <source>OR-Tools</source>
        <translation>OR-Tools</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="325"/>
        <source>Lendo pontos de demanda…</source>
        <translation>Reading demand points…</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="535"/>
        <source>Janela de análise: {}</source>
        <translation>Analysis window: {}</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="539"/>
        <source>Construindo o grafo…</source>
        <translation>Building graph…</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="557"/>
        <source>Calculando a matriz OD…</source>
        <translation>Calculating OD matrix…</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="573"/>
        <source>Calculando matriz de distâncias euclidianas…</source>
        <translation>Calculating Euclidean distance matrix…</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="589"/>
        <source>Otimizando (OR-Tools)…</source>
        <translation>Optimizing (OR-Tools)…</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="591"/>
        <source>Otimizando (heurística Python)…</source>
        <translation>Optimizing (Python heuristic)…</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="599"/>
        <source>Executando a otimização CVRP...</source>
        <translation>Executing CVRP optimization...</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="618"/>
        <source>Roteirização concluída. Rotas geradas: {count} | Backend: {backend} | Distância Total: {dist:.2f}</source>
        <translation>Routing completed. Generated routes: {count} | Backend: {backend} | Total Distance: {dist:.2f}</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="625"/>
        <source>Gravando as saídas…</source>
        <translation>Writing outputs…</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="725"/>
        <source>Resolve o Problema de Roteirização de Veículos Capacitados (CVRP) a partir de uma camada de depósito e uma camada de pontos de demanda (clientes).

Constroi rotas que iniciam e terminam no depósito, respeitando a capacidade máxima do veículo, utilizando a heurística de economias de Clarke &amp; Wright (1964) e refinamento opcional por busca local 2-opt (Lin, 1965) e Or-opt (Or, 1976).

Parâmetros:
- Camada de depósito: feição de ponto/polígono representando o depósito de partida/chegada.
- Camada de demanda / clientes: feições de pontos ou polígonos com demandas a atender.
- Campo de peso/demanda: campo numérico da demanda de cada cliente (opcional, default=1.0).
- Capacidade do veículo: carga máxima transportada por cada veículo em uma rota.
- Camada de rede viária: rede viária para distâncias reais (opcional, usa distância euclidiana se omitida).
- Aplicar busca local: se verdadeiro, aplica 2-opt e Or-opt para otimização de cada rota.
- Backend de otimização: qual motor usar (Automático/Python/OR-Tools).

Saídas:
- Rotas geradas: camada de linhas com a geometria das rotas e estatísticas de carga e distância.
- Paradas por rota: camada de pontos ordenada com atribuição de rota e carga acumulada.</source>
        <translation type="obsolete">Solves the Capacitated Vehicle Routing Problem (CVRP) from a depot layer and a demand points layer (customers).

Builds routes starting and ending at the depot while adhering to maximum vehicle capacity, using the Clarke &amp; Wright (1964) savings heuristic and optional local search refinement via 2-opt (Lin, 1965) and Or-opt (Or, 1976).

Parameters:
- Depot layer: point/polygon feature representing the start/end depot.
- Demand / customer layer: point or polygon features with demands to be served.
- Weight/demand field: numeric demand field for each customer (optional, default=1.0).
- Vehicle capacity: maximum payload transported by each vehicle per route.
- Road network layer: road network for actual distances (optional, uses Euclidean distance if omitted).
- Apply local search: if true, applies 2-opt and Or-opt to optimize each route.
- Optimization backend: solver choice (Automatic/Python/OR-Tools).

Outputs:
- Generated routes: line layer with route geometry and load/distance statistics.
- Stops per route: ordered point layer with route assignment and cumulative load.</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="390"/>
        <source>depósito</source>
        <translation>depot</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="391"/>
        <source>demanda</source>
        <translation>demand</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="399"/>
        <source>SRC da rede: {}</source>
        <translation>Network CRS: {}</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="484"/>
        <source>SRC de depósito: {} → {}</source>
        <translation>Depot CRS: {} → {}</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="485"/>
        <source>SRC de demanda: {} → {}</source>
        <translation>Demand CRS: {} → {}</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="522"/>
        <source>Janela de análise calculada a partir dos pontos é inválida: {}</source>
        <translation>Analysis window calculated from points is invalid: {}</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="529"/>
        <source>Os pontos ({}) não caem na área da rede viária (rede em {}) — confira o SRC das camadas.</source>
        <translation>The points ({}) do not fall within the road network area (network in {}) — check the CRS of the layers.</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="477"/>
        <source>Transformação {src} → {dst} ok (prova ({x1:.4f}, {y1:.4f}) → ({x2:.4f}, {y2:.4f}))</source>
        <translation>Transformation {src} → {dst} ok (probe ({x1:.4f}, {y1:.4f}) → ({x2:.4f}, {y2:.4f}))</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="464"/>
        <source>Transformação para EPSG:5880 falhou ({exc}) — adotando fallback para {utm_auth}</source>
        <translation>Transformation to EPSG:5880 failed ({exc}) — adopting fallback to {utm_auth}</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="462"/>
        <source>Transformação para UTM ({utm}) falhou: {exc}</source>
        <translation>Transformation to UTM ({utm}) failed: {exc}</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="461"/>
        <source>Transformação de coordenadas falhou: {exc}</source>
        <translation>Coordinate transformation failed: {exc}</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="284"/>
        <source>Campo de ID do depósito (opcional)</source>
        <translation>Depot ID field (optional)</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="284"/>
        <source>Campo do depósito de cada ponto (opcional)</source>
        <translation>Depot field for each point (optional)</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="284"/>
        <source>O parâmetro '{param1}' não pode ser preenchido sem o '{param2}'.</source>
        <translation>Parameter '{param1}' cannot be filled without '{param2}'.</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="321"/>
        <source>ID de depósito repetido na camada de depósito.</source>
        <translation>Duplicate depot ID in depot layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="372"/>
        <source>O valor '{val}' no campo de depósito da demanda não existe na camada de depósitos. IDs válidos: {ids}</source>
        <translation>Value '{val}' in demand depot field does not exist in depot layer. Valid IDs: {ids}</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="384"/>
        <source>{count} ponto(s) de demanda com o campo de depósito vazio; serão alocados ao depósito mais próximo.</source>
        <translation>{count} demand point(s) with empty depot field; will be allocated to the nearest depot.</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="786"/>
        <source>Depósito {did}: {count} rota(s), carga {load:.2f}</source>
        <translation>Depot {did}: {count} route(s), load {load:.2f}</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_cvrp.py" line="809"/>
        <source>Resolve o Problema de Roteirização de Veículos Capacitados (CVRP) a partir de uma ou mais feições de depósito e uma camada de pontos de demanda (clientes).

Limitação (agrupa primeiro, roteiriza depois): os pontos são alocados aos depósitos antes da roteirização (Gillett &amp; Johnson, 1976) e nunca trocam de depósito, sendo uma solução boa, não ótima. Se o campo de depósito da demanda for vazio, o cliente é alocado ao depósito mais próximo.

Constroi rotas que iniciam e terminam no depósito, respeitando a capacidade máxima do veículo, utilizando a heurística de economias de Clarke &amp; Wright (1964) e refinamento opcional por busca local 2-opt (Lin, 1965) e Or-opt (Or, 1976).

Parâmetros:
- Camada de depósito: feição(ões) de ponto/polígono representando o(s) depósito(s).
- Campo de ID do depósito: campo que identifica cada depósito (opcional).
- Camada de demanda / clientes: feições de pontos ou polígonos com demandas a atender.
- Campo do depósito de cada ponto: indica qual depósito atende o cliente (opcional).
- Campo de peso/demanda: campo numérico da demanda de cada cliente (opcional, default=1.0).
- Capacidade do veículo: carga máxima transportada por cada veículo em uma rota.
- Camada de rede viária: rede viária para distâncias reais (opcional, usa distância euclidiana se omitida).
- Aplicar busca local: se verdadeiro, aplica 2-opt e Or-opt para otimização de cada rota.
- Backend de otimização: qual motor usar (Automático/Python/OR-Tools).

Saídas:
- Rotas geradas: camada de linhas com a geometria das rotas e estatísticas de carga e distância.
- Paradas por rota: camada de pontos ordenada com atribuição de rota e carga acumulada.</source>
        <translation>Solves the Capacitated Vehicle Routing Problem (CVRP) from one or more depot features and a demand points layer (customers).

Limitation (cluster first, route second): points are allocated to depots prior to routing (Gillett &amp; Johnson, 1976) and never change depots, providing a good but not optimal solution. If the demand depot field is empty, the customer is assigned to the nearest depot.

Builds routes starting and ending at the depot while adhering to maximum vehicle capacity, using the Clarke &amp; Wright (1964) savings heuristic and optional local search refinement via 2-opt (Lin, 1965) and Or-opt (Or, 1976).

Parameters:
- Depot layer: point/polygon feature(s) representing the depot(s).
- Depot ID field: field identifying each depot (optional).
- Demand / customer layer: point or polygon features with demands to be served.
- Depot field for each point: indicates which depot serves the customer (optional).
- Weight/demand field: numeric field for each customer's demand (optional, default=1.0).
- Vehicle capacity: maximum cargo transported by each vehicle on a route.
- Road network layer: road network for real distances (optional, uses Euclidean distance if omitted).
- Apply local search: if true, applies 2-opt and Or-opt for optimization of each route.
- Optimization backend: which engine to use (Automatic/Python/OR-Tools).

Outputs:
- Generated routes: line layer with route geometry and load and distance statistics.
- Stops per route: ordered point layer with route assignment and cumulative load.</translation>
    </message>
</context>
<context>
    <name>VrpTsp</name>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="176"/>
        <source>Camada do ponto inicial</source>
        <translation>Start point layer</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="183"/>
        <source>Camada de pontos a visitar</source>
        <translation>Points to visit layer</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="190"/>
        <source>Camada do ponto final (opcional; vazia = a rota fecha no ponto inicial)</source>
        <translation>End point layer (optional; empty = route closes at start point)</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="198"/>
        <source>Camada de rede viária (Linhas) (opcional)</source>
        <translation>Road network layer (Lines) (optional)</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="206"/>
        <source>Aplicar busca local (2-opt e Or-opt)</source>
        <translation>Apply local search (2-opt and Or-opt)</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="225"/>
        <source>Ordem de visita</source>
        <translation>Visit order</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="231"/>
        <source>Rota (trechos)</source>
        <translation>Route (legs)</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="255"/>
        <source>Camada do ponto inicial inválida.</source>
        <translation>Invalid start point layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="257"/>
        <source>Camada de pontos a visitar inválida.</source>
        <translation>Invalid points to visit layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="268"/>
        <source>Nenhum ponto inicial válido encontrado.</source>
        <translation>No valid start point found.</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="274"/>
        <source>Lendo pontos a visitar...</source>
        <translation>Reading points to visit...</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="292"/>
        <source>A camada de pontos a visitar está vazia.</source>
        <translation>Points to visit layer is empty.</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="304"/>
        <source>Nenhum ponto final válido encontrado na camada fornecida.</source>
        <translation>No valid end point found in provided layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="435"/>
        <source>Construindo o grafo e calculando a matriz OD na rede...</source>
        <translation>Building graph and computing network OD matrix...</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="469"/>
        <source>Erro ao construir o grafo: {}</source>
        <translation>Error building graph: {}</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="477"/>
        <source>O grafo construído possui menos de 2 vértices.</source>
        <translation>Built graph has fewer than 2 vertices.</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="502"/>
        <source>Erro ao calcular a matriz OD: {}</source>
        <translation>Error computing OD matrix: {}</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="521"/>
        <source>Calculando matriz de distâncias euclidianas...</source>
        <translation>Computing euclidean distance matrix...</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="546"/>
        <source>Executando a otimização TSP...</source>
        <translation>Executing TSP optimization...</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="270"/>
        <source>Otimização TSP concluída. Pontos: {count} | Backend: {backend} | Distância Total: {dist:.2f}</source>
        <translation type="obsolete">TSP optimization completed. Points: {count} | Backend: {backend} | Total Distance: {dist:.2f}</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="788"/>
        <source>Caixeiro Viajante (TSP)</source>
        <translation>Traveling Salesperson (TSP)</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="791"/>
        <source>Roteirização</source>
        <translation>Routing</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="447"/>
        <source>Resolve o Problema do Caixeiro Viajante (TSP) a partir de um ponto inicial, uma camada de pontos a visitar e, opcionalmente, um ponto final ou rede viária.

Determina a sequência de visita de menor distância total utilizando as heurísticas do Vizinho Mais Próximo (Flood, 1956) com refinamento opcional por busca local 2-opt (Lin, 1965) e Or-opt (Or, 1976), ou o solver de programação por restrições do Google OR-Tools.

Parâmetros:
- Camada do ponto inicial: feição de ponto/polígono do local de partida.
- Camada de pontos a visitar: feições de pontos/polígonos a serem visitadas.
- Camada do ponto final (opcional): feição do ponto de chegada (se omitida ou vazia, a rota fecha no ponto inicial).
- Camada de rede viária: rede viária para distâncias reais (opcional, usa distância euclidiana se omitida).
- Aplicar busca local: se verdadeiro, aplica 2-opt e Or-opt para otimização da rota.

Saídas:
- Ordem de visita: camada de pontos ordenada com a ordem de visita na tabela de atributos em 'visit_seq', nó ('node_role'), papel da perna ('leg_role'), distância da perna ('leg_dist') e distância acumulada ('cum_dist').
- Rota (trechos): camada de linhas com a geometria das pernas da rota classificadas ('leg_role': 'acesso', 'rota', 'retorno'). Os trechos 'acesso' e 'retorno' da camada de rota são os deslocamentos improdutivos (do ponto inicial ao primeiro ponto a visitar e do último ao ponto final), somados em 'access_dist' e 'return_dist', com os totais de distância ('tour_dist', 'service_dist') e a taxa improdutiva ('dead_ratio') repetidos em todas as feições.</source>
        <translation type="obsolete">Solves the Traveling Salesperson Problem (TSP) from a start point, a points to visit layer, and optionally an end point or road network.

Determines the visit sequence with smallest total distance using Nearest Neighbor heuristic (Flood, 1956) with optional local search refinement via 2-opt (Lin, 1965) and Or-opt (Or, 1976), or Google OR-Tools constraint programming solver.

Parameters:
- Start point layer: point/polygon feature of departure location.
- Points to visit layer: point/polygon features to visit.
- End point layer (optional): arrival point feature (if omitted or empty, route closes at start point).
- Road network layer: road network for real distances (optional, uses euclidean distance if omitted).
- Apply local search: if true, applies 2-opt and Or-opt to optimize route.

Outputs:
- Visit order: ordered point layer with visit sequence in attribute table under 'visit_seq', node ('node_role'), leg role ('leg_role'), leg distance ('leg_dist'), and cumulative distance ('cum_dist').
- Route (legs): line layer with leg geometries classified ('leg_role': 'acesso', 'rota', 'retorno'). 'acesso' and 'retorno' legs represent deadhead movements (from start point to first visit point and from last to end point), summed in 'access_dist' and 'return_dist', with distance totals ('tour_dist', 'service_dist') and deadhead ratio ('dead_ratio') repeated across all features.</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="213"/>
        <source>Backend de otimização</source>
        <translation>Optimization backend</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="213"/>
        <source>Automático (OR-Tools quando disponível)</source>
        <translation>Automatic (OR-Tools when available)</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="213"/>
        <source>Python puro (heurística)</source>
        <translation>Pure Python (heuristic)</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="213"/>
        <source>OR-Tools</source>
        <translation>OR-Tools</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="273"/>
        <source>Lendo pontos a visitar…</source>
        <translation>Reading points to visit…</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="461"/>
        <source>Janela de análise: {}</source>
        <translation>Analysis window: {}</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="465"/>
        <source>Construindo o grafo…</source>
        <translation>Building graph…</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="482"/>
        <source>Não foi possível amarrar um ou mais pontos à rede viária. Verifique se os pontos estão próximos da malha e no mesmo território dela.</source>
        <translation>Could not snap one or more points to the road network. Verify if points are close to the network and in the same territory.</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="490"/>
        <source>Calculando a matriz OD…</source>
        <translation>Calculating OD matrix…</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="512"/>
        <source>A rede viária possui {} par(es) de pontos sem caminho entre si. Verifique se a rede está desconectada.</source>
        <translation>The road network has {} pair(s) of points with no path between them. Verify if the network is disconnected.</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="520"/>
        <source>Calculando matriz de distâncias euclidianas…</source>
        <translation>Calculating Euclidean distance matrix…</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="536"/>
        <source>Otimizando (OR-Tools)…</source>
        <translation>Optimizing (OR-Tools)…</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="538"/>
        <source>Otimizando (heurística Python)…</source>
        <translation>Optimizing (Python heuristic)…</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="562"/>
        <source>Otimização TSP concluída. Pontos: {count} | Modo: {dist_mode} | Backend: {backend} | Distância Total: {dist:.2f}</source>
        <translation>TSP optimization completed. Points: {count} | Mode: {dist_mode} | Backend: {backend} | Total Distance: {dist:.2f}</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="569"/>
        <source>Gravando as saídas…</source>
        <translation>Writing outputs…</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="797"/>
        <source>Resolve o Problema do Caixeiro Viajante (TSP) a partir de um ponto inicial, uma camada de pontos a visitar e, opcionalmente, um ponto final ou rede viária.

Determina a sequência de visita de menor distância total utilizando as heurísticas do Vizinho Mais Próximo (Flood, 1956) com refinamento opcional por busca local 2-opt (Lin, 1965) e Or-opt (Or, 1976), ou o solver de programação por restrições do Google OR-Tools.

Parâmetros:
- Camada do ponto inicial: feição de ponto/polígono do local de partida.
- Camada de pontos a visitar: feições de pontos/polígonos a serem visitadas.
- Camada do ponto final (opcional): feição do ponto de chegada (se omitida ou vazia, a rota fecha no ponto inicial).
- Camada de rede viária: rede viária para distâncias reais (opcional, usa distância euclidiana se omitida).
- Aplicar busca local: se verdadeiro, aplica 2-opt e Or-opt para otimização da rota.
- Backend de otimização: escolha do solver ('Automático (OR-Tools quando disponível)', 'Python puro (heurística)' ou 'OR-Tools'). O modo 'Python puro' é o modo seguro quando o QGIS fecha ao rodar a rota.

Saídas:
- Ordem de visita: camada de pontos ordenada com a ordem de visita na tabela de atributos em 'visit_seq', nó ('node_role'), papel da perna ('leg_role'), distância da perna ('leg_dist') e distância acumulada ('cum_dist').
- Rota (trechos): camada de linhas com a geometria das pernas da rota classificadas ('leg_role': 'acesso', 'rota', 'retorno'). Os trechos 'acesso' e 'retorno' da camada de rota são os deslocamentos improdutivos (do ponto inicial ao primeiro ponto a visitar e do último ao ponto final), somados em 'access_dist' e 'return_dist', com os totais de distância ('tour_dist', 'service_dist') e a taxa improdutiva ('dead_ratio') repetidos em todas as feições, além do modo de cálculo ('dist_mode') e da geometria do trecho ('leg_geom').</source>
        <translation>Solves the Traveling Salesperson Problem (TSP) from a start point layer, a points to visit layer, and optionally an end point layer or road network.

Determines the visit sequence with minimum total distance using Nearest Neighbor heuristics (Flood, 1956) with optional local search refinement via 2-opt (Lin, 1965) and Or-opt (Or, 1976), or Google OR-Tools constraint programming solver.

Parameters:
- Start point layer: point/polygon feature for departure location.
- Points to visit layer: point/polygon features to visit.
- End point layer (optional): feature for arrival location (if omitted or empty, route closes at start point).
- Road network layer: road network for actual distances (optional, uses Euclidean distance if omitted).
- Apply local search: if true, applies 2-opt and Or-opt for route optimization.
- Optimization backend: solver choice ('Automatic (OR-Tools when available)', 'Pure Python (heuristic)' or 'OR-Tools'). 'Pure Python' mode is safe if QGIS crashes when running routes.

Outputs:
- Visit order: ordered point layer with visit sequence in attribute table ('visit_seq'), node role ('node_role'), leg role ('leg_role'), leg distance ('leg_dist'), and cumulative distance ('cum_dist').
- Route (legs): line layer with classified leg geometries ('leg_role': 'acesso', 'rota', 'retorno'). The 'acesso' and 'retorno' legs are deadhead displacements (from start point to first visit point, and from last to end point), summed in 'access_dist' and 'return_dist', with distance totals ('tour_dist', 'service_dist') and deadhead ratio ('dead_ratio') repeated across all features, along with distance mode ('dist_mode') and leg geometry ('leg_geom').</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="307"/>
        <source>ponto inicial</source>
        <translation>start point</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="308"/>
        <source>pontos a visitar</source>
        <translation>points to visit</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="311"/>
        <source>ponto final</source>
        <translation>end point</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="319"/>
        <source>SRC da rede: {}</source>
        <translation>Network CRS: {}</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="409"/>
        <source>SRC de ponto inicial: {} → {}</source>
        <translation>Start point CRS: {} → {}</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="410"/>
        <source>SRC de pontos a visitar: {} → {}</source>
        <translation>Points to visit CRS: {} → {}</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="412"/>
        <source>SRC de ponto final: {} → {}</source>
        <translation>End point CRS: {} → {}</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="448"/>
        <source>Janela de análise calculada a partir dos pontos é inválida: {}</source>
        <translation>Analysis window calculated from points is invalid: {}</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="374"/>
        <source>A janela de análise dos pontos ({}) não intercepta a extensão da rede viária (rede em {}).</source>
        <translation type="obsolete">The point analysis window ({}) does not intersect the road network extent (network in {}).</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="455"/>
        <source>Os pontos ({}) não caem na área da rede viária (rede em {}) — confira o SRC das camadas.</source>
        <translation>The points ({}) do not fall within the road network area (network in {}) — check the CRS of the layers.</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="402"/>
        <source>Transformação {src} → {dst} ok (prova ({x1:.4f}, {y1:.4f}) → ({x2:.4f}, {y2:.4f}))</source>
        <translation>Transformation {src} → {dst} ok (probe ({x1:.4f}, {y1:.4f}) → ({x2:.4f}, {y2:.4f}))</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="387"/>
        <source>Transformação para EPSG:5880 falhou ({exc}) — adotando fallback para {utm_auth}</source>
        <translation>Transformation to EPSG:5880 failed ({exc}) — adopting fallback to {utm_auth}</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="385"/>
        <source>Transformação para UTM ({utm}) falhou: {exc}</source>
        <translation>Transformation to UTM ({utm}) failed: {exc}</translation>
    </message>
    <message>
        <location filename="../algorithms/vrp_tsp.py" line="384"/>
        <source>Transformação de coordenadas falhou: {exc}</source>
        <translation>Coordinate transformation failed: {exc}</translation>
    </message>
</context>
<context>
    <name>WasteCarpRoute</name>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="102"/>
        <source>Camada de vias</source>
        <translation>Roads layer</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="109"/>
        <source>Campo de geração/demanda de resíduos (kg)</source>
        <translation>Waste generation/demand field (kg)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="118"/>
        <source>Campo de via obrigatória para coleta (opcional)</source>
        <translation>Required road field for collection (optional)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="126"/>
        <source>Campo de setor de coleta (opcional)</source>
        <translation>Collection sector field (optional)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="134"/>
        <source>Capacidade do veículo (em toneladas ou kg)</source>
        <translation>Vehicle capacity (in tonnes or kg)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="143"/>
        <source>Camada de ponto do depósito/aterro (exatamente 1 feição)</source>
        <translation>Depot/landfill point layer (exactly 1 feature)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="153"/>
        <source>Tolerância de nó em metros (requer CRS métrico)</source>
        <translation type="obsolete">Node tolerance in meters (requires metric CRS)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="159"/>
        <source>Vias com rota de coleta (CARP)</source>
        <translation>Roads with collection route (CARP)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="176"/>
        <source>Camada de vias inválida.</source>
        <translation>Invalid roads layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="178"/>
        <source>A capacidade do veículo deve ser maior que zero.</source>
        <translation>Vehicle capacity must be greater than zero.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="196"/>
        <source>Lendo trechos de via...</source>
        <translation>Reading road segments...</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="259"/>
        <source>Demanda do trecho '{fid}' ({dem:.2f}) excede a capacidade do veículo ({cap:.2f}).</source>
        <translation>Segment '{fid}' demand ({dem:.2f}) exceeds vehicle capacity ({cap:.2f}).</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="278"/>
        <source>{count} trecho(s) com geometria inválida foram ignorados.</source>
        <translation>{count} segment(s) with invalid geometry were ignored.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="285"/>
        <source>Nenhum trecho de via válido encontrado na camada de entrada.</source>
        <translation>No valid road segment found in input layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="293"/>
        <source>Camada de depósito inválida.</source>
        <translation>Invalid depot layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="303"/>
        <source>A camada de ponto do depósito deve conter exatamente 1 feição (encontradas {count}).</source>
        <translation>Depot point layer must contain exactly 1 feature (found {count}).</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="327"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation>Could not create output layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="338"/>
        <source>Setor '{sec}': nenhum trecho de coleta obrigatória. Ignorando setor.</source>
        <translation>Sector '{sec}': no required collection segment. Ignoring sector.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="358"/>
        <source>Calculando rotas CARP para o setor '{sec}' ({req_count} trechos obrigatórios)...</source>
        <translation>Calculating CARP routes for sector '{sec}' ({req_count} required segments)...</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="372"/>
        <source>Erro ao calcular rotas CARP para o setor &apos;{sec}&apos;: {err}</source>
        <translation>Error calculating CARP routes for sector '{sec}': {err}</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="378"/>
        <source>Setor &apos;{sec}&apos;: {count} rota(s)/viagem(ns) gerada(s).</source>
        <translation>Sector '{sec}': {count} route(s)/trip(s) generated.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="398"/>
        <source>Setor &apos;{sec}&apos;, rota {idx}: carga {load:.2f} kg, {dh_km:.2f} km de deadhead.</source>
        <translation>Sector '{sec}', route {idx}: load {load:.2f} kg, {dh_km:.2f} km deadhead.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="404"/>
        <source>Aviso: rota {idx} do setor &apos;{sec}&apos; usa menos de 50% da capacidade ({load:.2f} kg de {cap:.2f} kg).</source>
        <translation>Warning: route {idx} in sector '{sec}' uses less than 50% capacity ({load:.2f} kg of {cap:.2f} kg).</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="440"/>
        <source>Roteirização por Arcos Capacitada (CARP)</source>
        <translation>Capacitated Arc Routing (CARP)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="443"/>
        <source>Logística Especializada — Coleta de Lixo</source>
        <translation>Specialized Logistics — Waste Collection</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="449"/>
        <source>Calcula rotas de veículos capacitados para coleta de lixo por arcos usando o Problema de Roteirização por Arcos Capacitada (Capacitated Arc Routing Problem - CARP) com a heurística Path-Scanning (Golden et al., 1983).

Parâmetros:
- Camada de vias: feições de linha com a malha viária.
- Campo de demanda de resíduos (obrigatório): campo numérico com a geração em cada trecho, em kg.
- Campo de via obrigatória (opcional): campo indicando trechos com coleta obrigatória; se omitido, todos os trechos são obrigatórios.
- Campo de setor de coleta (opcional): se informado, resolve o CARP separadamente por setor.
- Capacidade do veículo: capacidade máxima de carga por veículo, em kg.
- Camada de depósito/aterro: feição de ponto com a localização do aterro/depósito/garagem (exatamente 1 feição). O depósito é snapado ao vértice de via mais próximo por distância euclidiana — aproximação heurística, não uma projeção exata sobre a rede.
- Tolerância de nó: distância em metros para conectar vértices das vias.

Um trecho isolado com demanda maior que a capacidade do veículo gera erro explícito em vez de ser dividido entre mais de uma viagem (sem split-delivery).

Retorno:
- Camada de linha com feições de vias e campos adicionais: 'route_id' (identificador da rota/viagem dentro do setor), 'route_visit_order' (ordem de visita na rota), 'route_sector_id' (setor de coleta), 'route_is_deadhead' (booleano indicando passagem duplicada/deslocamento deadhead), 'route_load_kg' (carga total da rota em kg) e 'route_distance_km' (distância total da rota em km).</source>
        <translation>Calculates capacitated vehicle routes for arc waste collection using the Capacitated Arc Routing Problem (CARP) with Path-Scanning heuristic (Golden et al., 1983).

Parameters:
- Roads layer: line features with road network.
- Waste demand field (required): numeric field with generation in each segment, in kg.
- Required road field (optional): field indicating required collection segments; if omitted, all segments are required.
- Collection sector field (optional): if provided, solves CARP separately per sector.
- Vehicle capacity: maximum payload capacity per vehicle, in kg.
- Depot/landfill layer: point feature with landfill/depot/garage location (exactly 1 feature). Depot is snapped to nearest road vertex by euclidean distance — heuristic approximation, not exact projection onto network.
- Node tolerance: distance in meters to connect road vertices.

An isolated segment with demand greater than vehicle capacity produces an explicit error instead of being split across multiple trips (no split-delivery).

Returns:
- Line layer with road features and additional fields: 'route_id' (route/trip identifier within sector), 'route_visit_order' (visit order in route), 'route_sector_id' (collection sector), 'route_is_deadhead' (boolean indicating duplicated/deadhead travel), 'route_load_kg' (total route load in kg), and 'route_distance_km' (total route distance in km).</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="150"/>
        <source>Tolerância de nó (m)</source>
        <translation>Node tolerance (m)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="203"/>
        <source>camada de vias</source>
        <translation>roads layer</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_carp_route.py" line="296"/>
        <source>camada de depósito</source>
        <translation>depot layer</translation>
    </message>
</context>
<context>
    <name>WasteCollectionCoverage</name>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="72"/>
        <source>Camada de vias exigidas (faixa de frequência)</source>
        <translation>Required roads layer (frequency band)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="79"/>
        <source>Campo de setor da camada de vias exigidas (opcional)</source>
        <translation>Sector field in required roads layer (optional)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="87"/>
        <source>Camada de rota coberta (vias percorridas)</source>
        <translation>Covered route layer (traversed roads)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="94"/>
        <source>Campo indicador de deadhead/conector (opcional)</source>
        <translation>Deadhead/connector indicator field (optional)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="104"/>
        <source>Campo de setor da camada de rota coberta (opcional)</source>
        <translation>Sector field in covered route layer (optional)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="112"/>
        <source>Rótulo de frequência de coleta</source>
        <translation>Collection frequency label</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="120"/>
        <source>Tabela de cobertura por setor</source>
        <translation>Coverage table by sector</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="136"/>
        <source>Camada de vias exigidas inválida.</source>
        <translation>Invalid required roads layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="138"/>
        <source>Camada de rota coberta inválida.</source>
        <translation>Invalid covered route layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="156"/>
        <source>Calculando extensão exigida por setor...</source>
        <translation>Calculating required length per sector...</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="182"/>
        <source>Calculando extensão coberta por setor...</source>
        <translation>Calculating covered length per sector...</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="214"/>
        <source>Nenhum trecho válido encontrado nas camadas de entrada.</source>
        <translation>No valid segment found in input layers.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="234"/>
        <source>Erro ao calcular a cobertura da coleta: {err}</source>
        <translation>Error calculating collection coverage: {err}</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="258"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation>Could not create output layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="275"/>
        <source>Setor &apos;{sid}&apos;: {req:.2f} km exigidos | {cov:.2f} km cobertos | Cobertura: {pct}</source>
        <translation>Sector '{sid}': {req:.2f} km required | {cov:.2f} km covered | Coverage: {pct}</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="287"/>
        <source>Aviso: Setor &apos;{sid}&apos; possui cobertura baixa ({pct:.1f}% &lt; 80.0%).</source>
        <translation>Warning: Sector '{sid}' has low coverage ({pct:.1f}% &lt; 80.0%).</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="326"/>
        <source>Total geral: {req:.2f} km exigidos | {cov:.2f} km cobertos | Cobertura total: {pct}</source>
        <translation>Grand total: {req:.2f} km required | {cov:.2f} km covered | Total coverage: {pct}</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="343"/>
        <source>Cobertura da Coleta de Resíduos por Setor</source>
        <translation>Waste Collection Coverage by Sector</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="346"/>
        <source>Logística Especializada — Coleta de Lixo</source>
        <translation>Specialized Logistics — Waste Collection</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_collection_coverage.py" line="352"/>
        <source>Calcula a extensão de via exigida (required_km), extensão efetivamente coberta por rotas de coleta (covered_km) e a taxa de cobertura (coverage_pct) por setor e no total acumulado.

Parâmetros:
- Camada de vias exigidas (faixa de frequência): feições de linha com as vias exigidas.
- Campo de setor da camada de vias exigidas (opcional): campo com o identificador do setor.
- Camada de rota coberta (vias percorridas): feições de linha (ex.: saídas de logis:waste_cpp_route, logis:waste_rpp_route ou logis:waste_carp_route).
- Campo indicador de deadhead/conector (opcional): campo booleano onde True indica trecho improdutivo (default: 'route_is_deadhead'). Trechos improdutivos são desconsiderados da cobertura.
- Campo de setor da camada de rota coberta (opcional): campo de setor na camada de rota.
- Rótulo de frequência de coleta: rótulo textual de frequência (ex.: 'Diária', '3x/semana').

Retorno:
- Tabela sem geometria com uma feição por setor: 'sector_id', 'frequency_label', 'required_km', 'covered_km' e 'coverage_pct'. Quando há mais de um setor, uma feição adicional com 'sector_id' nulo traz o total acumulado.</source>
        <translation>Calculates required road length (required_km), effectively covered length by collection routes (covered_km), and coverage rate (coverage_pct) per sector and total accumulated.

Parameters:
- Required roads layer (frequency band): line features with required roads.
- Sector field of required roads layer (optional): field with sector identifier.
- Covered route layer (traversed roads): line features (e.g. outputs from logis:waste_cpp_route, logis:waste_rpp_route, or logis:waste_carp_route).
- Deadhead/connector indicator field (optional): boolean field where True indicates unproductive segment (default: 'route_is_deadhead'). Unproductive segments are ignored in coverage.
- Sector field of covered route layer (optional): sector field in route layer.
- Collection frequency label: textual frequency label (e.g. 'Daily', '3x/week').

Returns:
- Geometryless table with one feature per sector: 'sector_id', 'frequency_label', 'required_km', 'covered_km', and 'coverage_pct'. When there is more than one sector, an additional feature with null 'sector_id' provides the accumulated total.</translation>
    </message>
</context>
<context>
    <name>WasteCppRoute</name>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="94"/>
        <source>Camada de vias</source>
        <translation>Roads layer</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="101"/>
        <source>Campo de setor de coleta (opcional)</source>
        <translation>Collection sector field (optional)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="106"/>
        <source>Tolerância de nó em metros (requer CRS métrico)</source>
        <translation type="obsolete">Node tolerance in meters (requires metric CRS)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="118"/>
        <source>Vias com rota de coleta (CPP)</source>
        <translation>Roads with collection route (CPP)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="131"/>
        <source>Camada de vias inválida.</source>
        <translation>Invalid roads layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="139"/>
        <source>Lendo trechos de via e agrupando por setor...</source>
        <translation>Reading road segments and grouping by sector...</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="195"/>
        <source>{count} trecho(s) com geometria inválida foram ignorados.</source>
        <translation>{count} segment(s) with invalid geometry were ignored.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="202"/>
        <source>Nenhum trecho de via válido encontrado na camada de entrada.</source>
        <translation>No valid road segment found in input layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="220"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation>Could not create output layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="229"/>
        <source>Calculando rota CPP para o setor &apos;{sec}&apos; com {count} trecho(s)...</source>
        <translation>Calculating CPP route for sector '{sec}' with {count} segment(s)...</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="241"/>
        <source>Erro ao calcular rota CPP para o setor &apos;{sec}&apos;: {err}</source>
        <translation>Error calculating CPP route for sector '{sec}': {err}</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="251"/>
        <source>Setor &apos;{sec}&apos;: {dup} trecho(s) duplicado(s) (deadhead), {km:.2f} km improdutivos.</source>
        <translation>Sector '{sec}': {dup} duplicated segment(s) (deadhead), {km:.2f} km unproductive.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="281"/>
        <source>Roteirização por Arcos (CPP)</source>
        <translation>Arc Routing (CPP)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="284"/>
        <source>Logística Especializada — Coleta de Lixo</source>
        <translation>Specialized Logistics — Waste Collection</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="290"/>
        <source>Calcula a sequência de percurso para coleta de lixo por arcos usando o Problema do Carteiro Chinês (Chinese Postman Problem - CPP).

Parâmetros:
- Camada de vias: feições de linha a serem percorridas.
- Campo de setor de coleta (opcional): se informado, o CPP é resolvido separadamente para cada setor de coleta; se omitido, toda a camada é tratada como um único setor.
- Tolerância de nó: distância em metros para conectar vértices das vias.

Retorno:
- Camada de linha com feições duplicadas nos trechos de deadhead e campos adicionais: 'route_visit_order' (posição sequencial no circuito), 'route_sector_id' (setor de coleta) e 'route_is_deadhead' (booleano indicando passagem duplicada/deadhead).</source>
        <translation>Calculates travel sequence for arc waste collection using the Chinese Postman Problem (CPP).

Parameters:
- Roads layer: line features to traverse.
- Collection sector field (optional): if provided, CPP is solved separately for each collection sector; if omitted, entire layer is treated as a single sector.
- Node tolerance: distance in meters to connect road vertices.

Returns:
- Line layer with duplicated features on deadhead segments and additional fields: 'route_visit_order' (sequential position in circuit), 'route_sector_id' (collection sector), and 'route_is_deadhead' (boolean indicating duplicated/deadhead pass).</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="109"/>
        <source>Tolerância de nó (m)</source>
        <translation>Node tolerance (m)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_cpp_route.py" line="146"/>
        <source>camada de vias</source>
        <translation>roads layer</translation>
    </message>
</context>
<context>
    <name>WasteDeadheadRatio</name>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="68"/>
        <source>Camada de rotas/vias de coleta</source>
        <translation>Collection routes/roads layer</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="75"/>
        <source>Campo indicador de deadhead/improdutivo</source>
        <translation>Deadhead/unproductive indicator field</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="85"/>
        <source>Campo de identificação da rota/setor (opcional)</source>
        <translation>Route/sector identification field (optional)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="93"/>
        <source>Razão de deadhead por rota</source>
        <translation>Deadhead ratio by route</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="106"/>
        <source>Camada de rotas de coleta inválida.</source>
        <translation>Invalid collection routes layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="110"/>
        <source>Campo indicador de deadhead inválido.</source>
        <translation>Invalid deadhead indicator field.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="118"/>
        <source>Lendo feições da camada e calculando comprimentos...</source>
        <translation>Reading layer features and calculating lengths...</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="147"/>
        <source>Nenhum trecho válido encontrado na camada de entrada.</source>
        <translation>No valid segment found in input layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="158"/>
        <source>Erro ao calcular a razão de deadhead: {err}</source>
        <translation>Error calculating deadhead ratio: {err}</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="178"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation>Could not create output layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="193"/>
        <source>Rota '{rid}': {prod:.2f} km produtivos | {dh:.2f} km deadhead | Razão: {ratio}</source>
        <translation>Route '{rid}': {prod:.2f} km productive | {dh:.2f} km deadhead | Ratio: {ratio}</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="218"/>
        <source>Total acumulado de todas as rotas: {prod:.2f} km produtivos | {dh:.2f} km deadhead | Razão total: {ratio}</source>
        <translation>Accumulated total of all routes: {prod:.2f} km productive | {dh:.2f} km deadhead | Total ratio: {ratio}</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="245"/>
        <source>Razão de Deadhead por Rota</source>
        <translation>Deadhead Ratio by Route</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="248"/>
        <source>Logística Especializada — Coleta de Lixo</source>
        <translation>Specialized Logistics — Waste Collection</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_deadhead_ratio.py" line="254"/>
        <source>Calcula a extensão de deslocamento produtivo (coleta), improdutivo (deadhead/conector) e a razão de deadhead (deadhead_km / productive_km) para cada rota de coleta e no total.

Parâmetros:
- Camada de rotas/vias de coleta: feições de linha (ex.: saídas de logis:waste_cpp_route, logis:waste_rpp_route ou logis:waste_carp_route).
- Campo indicador de deadhead (obrigatório): campo booleano onde True indica trecho de deadhead/deslocamento improdutivo (default: 'route_is_deadhead').
- Campo de identificação da rota/setor (opcional): se informado, calcula a razão separadamente para cada rota/setor; se omitido, calcula para a camada inteira.

Retorno:
- Tabela sem geometria com uma feição por rota: 'route_id', 'productive_km' (extensão de coleta), 'deadhead_km' (extensão improdutiva) e 'deadhead_ratio' (razão deadhead_km / productive_km). Quando há mais de uma rota, uma feição adicional com 'route_id' nulo traz o total agregado de todas as rotas.</source>
        <translation>Calculates productive travel length (collection), unproductive travel length (deadhead/connector), and the deadhead ratio (deadhead_km / productive_km) for each collection route and overall.

Parameters:
- Collection routes/roads layer: line features (e.g. outputs from logis:waste_cpp_route, logis:waste_rpp_route, or logis:waste_carp_route).
- Deadhead indicator field (required): boolean field where True indicates deadhead/unproductive segment (default: 'route_is_deadhead').
- Route/sector identification field (optional): if provided, calculates ratio separately for each route/sector; if omitted, calculates for the entire layer.

Returns:
- Geometryless table with one feature per route: 'route_id', 'productive_km' (collection length), 'deadhead_km' (unproductive length), and 'deadhead_ratio' (ratio deadhead_km / productive_km). When there is more than one route, an additional feature with null 'route_id' provides the aggregated total across all routes.</translation>
    </message>
</context>
<context>
    <name>WasteDestinationDistance</name>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="73"/>
        <source>Camada de rede viária (Linhas)</source>
        <translation>Road network layer (Lines)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="80"/>
        <source>Camada de destinos de resíduos - aterro/transbordo/ecoponto (Pontos)</source>
        <translation>Waste destinations layer - landfill/transfer/recycling site (Points)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="87"/>
        <source>Camada de setores/origens de coleta (Pontos ou Polígonos)</source>
        <translation>Collection sectors/origins layer (Points or Polygons)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="94"/>
        <source>Critério de custo</source>
        <translation>Cost criterion</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="94"/>
        <source>Distância</source>
        <translation>Distance</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="94"/>
        <source>Tempo de viagem</source>
        <translation>Travel time</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="102"/>
        <source>Setores de coleta com distância ao destino</source>
        <translation>Collection sectors with distance to destination</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="116"/>
        <source>Camada de rede viária inválida.</source>
        <translation>Invalid road network layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="118"/>
        <source>Camada de destinos de resíduos inválida.</source>
        <translation>Invalid waste destinations layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="120"/>
        <source>Camada de setores/origens inválida.</source>
        <translation>Invalid sectors/origins layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="126"/>
        <source>Lendo pontos de destino (aterros/transbordos/ecopontos)...</source>
        <translation>Reading destination points (landfills/transfer stations/recycling sites)...</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="135"/>
        <source>Nenhum ponto de destino válido encontrado.</source>
        <translation>No valid destination point found.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="138"/>
        <source>Lendo setores/origens de coleta...</source>
        <translation>Reading collection sectors/origins...</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="147"/>
        <source>Nenhum setor/origem de coleta válido encontrado.</source>
        <translation>No valid collection sector/origin found.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="150"/>
        <source>Construindo o grafo a partir da rede viária...</source>
        <translation>Building graph from road network...</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="155"/>
        <source>Erro ao construir o grafo: {}</source>
        <translation>Error building graph: {}</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="161"/>
        <source>O grafo construído possui menos de 2 vértices. Não é possível calcular as distâncias.</source>
        <translation>Constructed graph has fewer than 2 vertices. Cannot calculate distances.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="172"/>
        <source>Não foi possível amarrar um ou mais pontos de destino à rede viária.</source>
        <translation>Could not snap one or more destination points to the road network.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="174"/>
        <source>Não foi possível amarrar um ou mais setores/origens à rede viária.</source>
        <translation>Could not snap one or more sectors/origins to the road network.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="177"/>
        <source>Calculando matriz de distâncias/tempos de viagem destino-setor...</source>
        <translation>Calculating destination-sector distance/travel time matrix...</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="185"/>
        <source>Erro ao calcular a matriz OD: {}</source>
        <translation>Error calculating OD matrix: {}</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="202"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation>Could not create output layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="210"/>
        <source>Distância ao destino de resíduos mais próximo calculada para {count} setor(es).</source>
        <translation>Distance to nearest waste destination calculated for {count} sector(s).</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="221"/>
        <source>Distância ao Destino de Resíduos</source>
        <translation>Distance to Waste Destination</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="224"/>
        <source>Logística Especializada — Coleta de Lixo</source>
        <translation>Specialized Logistics — Waste Collection</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="230"/>
        <source>Calcula a distância ou tempo de viagem ao ponto de destino de resíduos mais próximo (aterro sanitário, estação de transbordo, ecoponto) para cada setor ou centroide de coleta, utilizando caminhos mínimos na rede viária.

Parâmetros:
- Camada de rede viária: feições de linha representando as vias.
- Camada de destinos de resíduos: feições de ponto representando aterros, estações de transbordo ou ecopontos.
- Camada de setores/origens: feições de ponto ou polígono representando os setores de coleta.
- Critério de custo: define se o cálculo de custo de caminho mínimo é baseado em Distância ou Tempo de viagem.

Retorno:
- Cópia da camada de origens com a coluna 'dist_destino' (menor distância em km ou tempo em min até o destino mais próximo).</source>
        <translation>Calculates travel distance or travel time to the nearest waste destination (landfill, transfer station, recycling site) for each collection sector or centroid, using shortest paths on the road network.

Parameters:
- Road network layer: line features representing roads.
- Waste destinations layer: point features representing landfills, transfer stations, or recycling sites.
- Sectors/origins layer: point or polygon features representing collection sectors.
- Cost criterion: defines whether shortest path cost calculation is based on Distance or Travel time.

Returns:
- Copy of origins layer with column 'dist_destino' (shortest distance in km or time in min to nearest destination).</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="128"/>
        <source>camada de destinos de resíduos</source>
        <translation>waste destination layer</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_destination_distance.py" line="140"/>
        <source>camada de setores/origens</source>
        <translation>collection sectors/origins layer</translation>
    </message>
</context>
<context>
    <name>WasteDistricting</name>
    <message>
        <location filename="../algorithms/waste_districting.py" line="109"/>
        <source>Camada de vias</source>
        <translation>Roads layer</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="116"/>
        <source>Campo de carga (opcional, default=comprimento do trecho)</source>
        <translation>Load field (optional, default=segment length)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="125"/>
        <source>Número de setores de coleta desejado</source>
        <translation>Desired number of collection sectors</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="122"/>
        <source>Tolerância de nó em metros (requer CRS métrico)</source>
        <translation type="obsolete">Node tolerance in meters (requires metric CRS)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="143"/>
        <source>Máximo de iterações de rebalanceamento de fronteira</source>
        <translation>Maximum boundary rebalancing iterations</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="152"/>
        <source>Vias com setor de coleta atribuído</source>
        <translation>Roads with assigned collection sector</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="167"/>
        <source>Camada de vias inválida.</source>
        <translation>Invalid roads layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="172"/>
        <source>Lendo trechos de via e construindo adjacência...</source>
        <translation>Reading road segments and building adjacency...</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="221"/>
        <source>{count} trecho(s) com geometria inválida foram ignorados.</source>
        <translation>{count} segment(s) with invalid geometry were ignored.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="228"/>
        <source>Nenhum trecho de via válido encontrado na camada de entrada.</source>
        <translation>No valid road segment found in input layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="231"/>
        <source>O número de setores ({k}) não pode exceder o número de trechos válidos ({n}).</source>
        <translation>Number of sectors ({k}) cannot exceed valid segment count ({n}).</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="292"/>
        <source>Selecionando sementes (farthest-first)...</source>
        <translation>Selecting seeds (farthest-first)...</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="296"/>
        <source>Crescendo setores a partir das sementes...</source>
        <translation>Growing sectors from seeds...</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="299"/>
        <source>Rebalanceando trechos de fronteira...</source>
        <translation>Rebalancing boundary segments...</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="310"/>
        <source>Setorização concluída. Setores: {k} | carga mín={min:.2f} | carga máx={max:.2f} | carga média={avg:.2f}</source>
        <translation>Districting completed. Sectors: {k} | min load={min:.2f} | max load={max:.2f} | avg load={avg:.2f}</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="327"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation>Could not create output layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="352"/>
        <source>Setorização de Coleta de Resíduos (Districting)</source>
        <translation>Waste Collection Districting</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="355"/>
        <source>Logística Especializada — Coleta de Lixo</source>
        <translation>Specialized Logistics — Waste Collection</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="292"/>
        <source>Particiona os trechos de uma camada de vias em k setores de coleta contíguos e balanceados por carga (resíduos gerados ou, na ausência do campo, comprimento do trecho).

Usa a heurística de sementes farthest-first (Gonzalez, 1985), seguida de crescimento de regiões a partir das sementes e refinamento local por troca de trechos de fronteira para equilibrar a carga entre setores mantendo contiguidade. A solução é boa, não necessariamente ótima.

Parâmetros:
- Camada de vias: trechos de via (linhas) a setorizar.
- Campo de carga: campo numérico com a carga de cada trecho (opcional; se omitido, usa o comprimento do trecho como proxy de carga).
- Número de setores: quantidade desejada de setores de coleta (k &gt;= 2).
- Tolerância de nó: distância, em metros, usada para considerar dois vértices de extremidade como o mesmo nó da rede. Requer que a camada esteja em um CRS métrico.
- Máximo de iterações: limite de trocas locais de trechos de fronteira.

Saída:
- Camada de vias com o novo atributo 'collection_sector_id' (ID do setor de coleta).</source>
        <translation type="obsolete">Partitions segments of a roads layer into k contiguous collection sectors balanced by payload (generated waste or, in the absence of field, segment length).

Uses farthest-first seed heuristic (Gonzalez, 1985), followed by region growing from seeds and local refinement via boundary segment swapping to balance load between sectors while maintaining contiguity. Solution is good, not necessarily optimal.

Parameters:
- Roads layer: road segments (lines) to partition.
- Payload field: numeric field with payload of each segment (optional; if omitted, uses segment length as payload proxy).
- Number of sectors: desired number of collection sectors (k &gt;= 2).
- Node tolerance: distance, in meters, used to consider two endpoint vertices as the same network node. Requires layer to be in a metric CRS.
- Max iterations: limit of local boundary segment swapping iterations.

Output:
- Roads layer with new attribute 'collection_sector_id' (collection sector ID).</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="134"/>
        <source>Tolerância de nó (m)</source>
        <translation>Node tolerance (m)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="179"/>
        <source>camada de vias</source>
        <translation>roads layer</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="292"/>
        <source>Particiona os trechos de uma camada de vias em k setores de coleta contíguos e balanceados por carga (resíduos gerados ou, na ausência do campo, comprimento do trecho).

Usa a heurística de sementes farthest-first (Gonzalez, 1985), seguida de crescimento de regiões a partir das sementes e refinamento local por troca de trechos de fronteira para equilibrar a carga entre setores mantendo contiguidade. A solução é boa, não necessariamente ótima.

Parâmetros:
- Camada de vias: trechos de via (linhas) a setorizar.
- Campo de carga: campo numérico com a carga de cada trecho (opcional; se omitido, usa o comprimento do trecho como proxy de carga).
- Número de setores: quantidade desejada de setores de coleta (k &gt;= 2).
- Tolerância de nó: distância, em metros, usada para considerar dois vértices de extremidade como o mesmo nó da rede. Funciona com qualquer SRC de entrada — a camada é lida já reprojetada para coordenadas métricas quando está em SRC geográfico, e o comprimento de cada trecho é medido de forma elipsoidal, em metros de verdade.
- Máximo de iterações: limite de trocas locais de trechos de fronteira.

Saída:
- Camada de vias com o novo atributo 'collection_sector_id' (ID do setor de coleta).</source>
        <translation type="obsolete">Partitions segments of a roads layer into k contiguous collection sectors balanced by payload (generated waste or, in the absence of field, segment length).

Uses farthest-first seed heuristic (Gonzalez, 1985), followed by region growing from seeds and local refinement via boundary segment swapping to balance load between sectors while maintaining contiguity. Solution is good, not necessarily optimal.

Parameters:
- Roads layer: road segments (lines) to partition.
- Payload field: numeric field with payload of each segment (optional; if omitted, uses segment length as payload proxy).
- Number of sectors: desired number of collection sectors (k &gt;= 2).
- Node tolerance: distance, in meters, used to consider two endpoint vertices as the same network node. Works with any input CRS — the layer is read already reprojected to metric coordinates when it is in a geographic CRS, and each segment's length is measured ellipsoidally, in true meters.
- Max iterations: limit of local boundary segment swapping iterations.

Output:
- Roads layer with new attribute 'collection_sector_id' (collection sector ID).</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="238"/>
        <source>Verificando a conectividade da rede...</source>
        <translation>Checking network connectivity...</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="255"/>
        <source>Rede fragmentada demais para setorizar: {pct:.1f}% da carga total está fora da rede principal, em {n_comp} componente(s) isolado(s) com {n_edges} trecho(s). Aumente a tolerância de nó ou trate os trechos isolados à parte.</source>
        <translation>Network too fragmented to sectorize: {pct:.1f}% of the total load is outside the main network, in {n_comp} isolated component(s) with {n_edges} segment(s). Increase the node tolerance or handle the isolated segments separately.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="267"/>
        <source>O número de setores ({k}) não pode exceder o número de trechos da rede principal ({n}; há {m} trecho(s) fora dela, que saem com collection_sector_id = -1).</source>
        <translation>The number of sectors ({k}) cannot exceed the number of segments in the main network ({n}; there are {m} segment(s) outside it, which get collection_sector_id = -1).</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="279"/>
        <source>{count} trecho(s) de via fora da rede principal, em {n_comp} componente(s) isolado(s): {pct:.1f}% da carga total. Esses trechos saem com collection_sector_id = -1 e não entram em nenhum setor. IDs: {ids}. Confira a conexão dessas vias, aumente a tolerância de nó ou trate-as à parte.</source>
        <translation>{count} street segment(s) outside the main network, in {n_comp} isolated component(s): {pct:.1f}% of the total load. These segments get collection_sector_id = -1 and are not part of any sector. IDs: {ids}. Check the connection of these streets, increase the node tolerance, or handle them separately.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="315"/>
        <source> | trechos sem setor (-1): {n}</source>
        <translation> | segments without a sector (-1): {n}</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_districting.py" line="361"/>
        <source>Particiona os trechos de uma camada de vias em k setores de coleta contíguos e balanceados por carga (resíduos gerados ou, na ausência do campo, comprimento do trecho).

Usa a heurística de sementes farthest-first (Gonzalez, 1985), seguida de crescimento de regiões a partir das sementes e refinamento local por troca de trechos de fronteira para equilibrar a carga entre setores mantendo contiguidade. A solução é boa, não necessariamente ótima.

A adjacência entre trechos considera qualquer vértice compartilhado (não só as pontas), e a setorização roda apenas sobre o componente principal da rede (o de maior carga). Trechos que não se ligam à rede principal — ilhas, fragmentos do recorte municipal, vias internas isoladas — saem com collection_sector_id = -1 e são reportados em um aviso (quantos são, quanto da carga representam e seus IDs), porque não é possível formar setores contíguos com eles. Se mais de 50% da carga ficar fora da rede principal, a execução aborta com erro, indicando aumentar a tolerância de nó.

Parâmetros:
- Camada de vias: trechos de via (linhas) a setorizar.
- Campo de carga: campo numérico com a carga de cada trecho (opcional; se omitido, usa o comprimento do trecho como proxy de carga).
- Número de setores: quantidade desejada de setores de coleta (k &gt;= 2).
- Tolerância de nó: distância, em metros, usada para considerar dois vértices de extremidade como o mesmo nó da rede. Funciona com qualquer SRC de entrada — a camada é lida já reprojetada para coordenadas métricas quando está em SRC geográfico, e o comprimento de cada trecho é medido de forma elipsoidal, em metros de verdade.
- Máximo de iterações: limite de trocas locais de trechos de fronteira.

Saída:
- Camada de vias com o novo atributo 'collection_sector_id' (ID do setor de coleta; -1 = trecho fora da rede principal).</source>
        <translation>Partitions the segments of a road layer into k contiguous collection sectors balanced by load (generated waste or, in the absence of the field, the segment length).

Uses the farthest-first seed heuristic (Gonzalez, 1985), followed by region growing from the seeds and local refinement by boundary-segment exchanges to balance the load across sectors while keeping contiguity. The solution is good, not necessarily optimal.

Adjacency between segments considers any shared vertex (not only endpoints), and sectorization runs only on the main network component (the one with the highest load). Segments that do not connect to the main network — islands, fragments from the municipal clip, isolated internal roads — get collection_sector_id = -1 and are reported in a warning (how many there are, how much load they represent, and their IDs), because contiguous sectors cannot be formed with them. If more than 50% of the load falls outside the main network, execution aborts with an error suggesting to increase the node tolerance.

Parameters:
- Road layer: road segments (lines) to sectorize.
- Load field: numeric field with the load of each segment (optional; if omitted, the segment length is used as a load proxy).
- Number of sectors: desired number of collection sectors (k &gt;= 2).
- Node tolerance: distance, in meters, used to consider two vertices as the same network node. Works with any input CRS — the layer is read already reprojected to metric coordinates when it is in a geographic CRS, and each segment's length is measured ellipsoidally, in true meters.
- Maximum iterations: limit of local boundary-segment exchanges.

Output:
- Road layer with the new attribute 'collection_sector_id' (collection sector ID; -1 = segment outside the main network).</translation>
    </message>
</context>
<context>
    <name>WasteDock</name>
    <message>
        <location filename="../gui/waste_dock.py" line="183"/>
        <source>logis — Coleta de Lixo</source>
        <translation>logis — Waste Collection</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="216"/>
        <source>&lt;b&gt;Coleta de Lixo&lt;/b&gt;</source>
        <translation>&lt;b&gt;Waste Collection&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="220"/>
        <source>Painel para gestão, estimativa de geração, setorização e roteirização por arcos (coleta de lixo urbana).</source>
        <translation>Panel for management, generation estimation, districting, and arc routing (urban waste collection).</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="237"/>
        <source>&lt;b&gt;Estimativa de Geração&lt;/b&gt;</source>
        <translation>&lt;b&gt;Generation Estimate&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="242"/>
        <source>Camada de setores censitérios (Polígonos):</source>
        <translation>Census tracts layer (Polygons):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="248"/>
        <source>Campo ID do setor (Setores):</source>
        <translation>Sector ID field (Sectors):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="255"/>
        <source>Campo de população (Setores):</source>
        <translation>Population field (Sectors):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="434"/>
        <source>Camada de trechos de via (Linhas):</source>
        <translation>Road segments layer (Lines):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="268"/>
        <source>Campo ID do setor (Vias):</source>
        <translation type="obsolete">Sector ID field (Roads):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="277"/>
        <source>Taxa per capita (kg/hab/dia):</source>
        <translation>Per capita rate (kg/hab/day):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="285"/>
        <source>Fração de cobertura (0.0 a 1.0):</source>
        <translation>Coverage fraction (0.0 to 1.0):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="293"/>
        <source>Calcular Estimativa de Geração</source>
        <translation>Calculate Generation Estimate</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="352"/>
        <source>&lt;b&gt;Roteirização CPP&lt;/b&gt;</source>
        <translation>&lt;b&gt;CPP Routing&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="637"/>
        <source>Campo de setor de coleta (opcional):</source>
        <translation>Collection sector field (optional):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="479"/>
        <source>Tolerância de nó (m):</source>
        <translation>Node tolerance (m):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="380"/>
        <source>Executar Roteirização CPP</source>
        <translation>Run CPP Routing</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="386"/>
        <source>&lt;b&gt;Roteirização RPP&lt;/b&gt;</source>
        <translation>&lt;b&gt;RPP Routing&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="440"/>
        <source>Campo de via obrigatória (opcional):</source>
        <translation>Required road field (optional):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="423"/>
        <source>Executar Roteirização RPP</source>
        <translation>Run RPP Routing</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="429"/>
        <source>&lt;b&gt;Roteirização CARP&lt;/b&gt;</source>
        <translation>&lt;b&gt;CARP Routing&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="449"/>
        <source>Campo de demanda de resíduos (kg):</source>
        <translation>Waste demand field (kg):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="456"/>
        <source>Camada de ponto do depósito/aterro (Pontos):</source>
        <translation>Depot/landfill point layer (Points):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="462"/>
        <source>Capacidade do veículo:</source>
        <translation>Vehicle capacity:</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="487"/>
        <source>Executar Roteirização CARP</source>
        <translation>Run CARP Routing</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="498"/>
        <source>&lt;b&gt;Dimensionamento de Frota&lt;/b&gt;</source>
        <translation>&lt;b&gt;Fleet Sizing&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="606"/>
        <source>Camada de rotas de coleta (Linhas):</source>
        <translation>Collection routes layer (Lines):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="509"/>
        <source>Campo ID da rota:</source>
        <translation>Route ID field:</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="646"/>
        <source>Velocidade média de coleta (km/h):</source>
        <translation>Average collection speed (km/h):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="533"/>
        <source>Duração da jornada de trabalho (horas):</source>
        <translation>Work shift duration (hours):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="654"/>
        <source>Tempo de descarga por rota (horas):</source>
        <translation>Unloading time per route (hours):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="662"/>
        <source>Tempo de deslocamento ao destino por rota (horas):</source>
        <translation>Travel time to destination per route (hours):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="557"/>
        <source>Executar Dimensionamento de Frota</source>
        <translation>Run Fleet Sizing</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="601"/>
        <source>&lt;b&gt;Equilíbrio entre Setores&lt;/b&gt;</source>
        <translation>&lt;b&gt;Sector Balance&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="612"/>
        <source>Campo de carga da rota (kg):</source>
        <translation>Route load field (kg):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="619"/>
        <source>Campo de distância da rota em km (opcional):</source>
        <translation>Route distance field in km (optional):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="628"/>
        <source>Campo ID da rota (opcional):</source>
        <translation>Route ID field (optional):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="670"/>
        <source>Executar Equilíbrio entre Setores</source>
        <translation>Run Sector Balance</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="676"/>
        <source>&lt;b&gt;Distância ao Destino&lt;/b&gt;</source>
        <translation>&lt;b&gt;Distance to Destination&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="681"/>
        <source>Camada de rede viária (Linhas):</source>
        <translation>Road network layer (Lines):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="687"/>
        <source>Camada de destinos de resíduos (Pontos):</source>
        <translation>Waste destinations layer (Points):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="693"/>
        <source>Camada de setores/origens de coleta (Pontos ou Polígonos):</source>
        <translation>Collection sectors/origins layer (Points or Polygons):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="699"/>
        <source>Critério de custo:</source>
        <translation>Cost criterion:</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="701"/>
        <source>Distância</source>
        <translation>Distance</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="701"/>
        <source>Tempo de viagem</source>
        <translation>Travel time</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="705"/>
        <source>Executar Distância ao Destino</source>
        <translation>Run Distance to Destination</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="711"/>
        <source>&lt;b&gt;Cobertura por Frequência&lt;/b&gt;</source>
        <translation>&lt;b&gt;Frequency Coverage&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="716"/>
        <source>Camada de vias exigidas (faixa de frequência) (Linhas):</source>
        <translation>Required roads layer (frequency band) (Lines):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="722"/>
        <source>Campo de setor da camada de vias exigidas (opcional):</source>
        <translation>Sector field in required roads layer (optional):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="731"/>
        <source>Camada de rota coberta (Linhas):</source>
        <translation>Covered route layer (Lines):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="737"/>
        <source>Campo indicador de deadhead/conector (opcional):</source>
        <translation>Deadhead/connector indicator field (optional):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="746"/>
        <source>Campo de setor da camada de rota coberta (opcional):</source>
        <translation>Sector field in covered route layer (optional):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="755"/>
        <source>Rótulo de frequência de coleta:</source>
        <translation>Collection frequency label:</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="760"/>
        <source>Executar Cobertura por Frequência</source>
        <translation>Run Frequency Coverage</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="768"/>
        <source>Resultados:</source>
        <translation>Results:</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1439"/>
        <source>Aviso</source>
        <translation>Warning</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="795"/>
        <source>Por favor, selecione todas as camadas e campos necessários para a estimativa de geração.</source>
        <translation>Please select all necessary layers and fields for generation estimation.</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1444"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro: Parâmetros incompletos.&lt;/span&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Error: Incomplete parameters.&lt;/span&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1450"/>
        <source>Erro</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1450"/>
        <source>QGIS Processing não está disponível no ambiente atual.</source>
        <translation>QGIS Processing is not available in the current environment.</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1455"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro: QGIS Processing não disponível.&lt;/span&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Error: QGIS Processing not available.&lt;/span&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="815"/>
        <source>&lt;b&gt;=== CALCULANDO ESTIMATIVA DE GERAÇÃO ===&lt;/b&gt;&lt;br&gt;</source>
        <translation>&lt;b&gt;=== CALCULATING GENERATION ESTIMATE ===&lt;/b&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="864"/>
        <source>-&gt; &lt;b&gt;Estimativa calculada com sucesso!&lt;/b&gt; (Camada com {count} trechos viários)&lt;br&gt;</source>
        <translation>-&gt; &lt;b&gt;Estimation calculated successfully!&lt;/b&gt; (Layer with {count} road segments)&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="868"/>
        <source>-&gt; &lt;b&gt;Resultado da estimativa retornou vazio.&lt;/b&gt;&lt;br&gt;</source>
        <translation>-&gt; &lt;b&gt;Estimation result returned empty.&lt;/b&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="871"/>
        <source>&lt;span style=&apos;color: #fc8181;&apos;&gt;Erro ao calcular estimativa: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Error calculating estimate: {error}&lt;/span&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1487"/>
        <source>&lt;b&gt;=== CÁLCULO CONCLUÍDO ===&lt;/b&gt;</source>
        <translation>&lt;b&gt;=== CALCULATION COMPLETED ===&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="969"/>
        <source>Por favor, selecione a camada de vias para a roteirização CPP.</source>
        <translation>Please select the roads layer for CPP routing.</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="989"/>
        <source>&lt;b&gt;=== EXECUTANDO ROTEIRIZAÇÃO CPP ===&lt;/b&gt;&lt;br&gt;</source>
        <translation>&lt;b&gt;=== EXECUTING CPP ROUTING ===&lt;/b&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1006"/>
        <source>-&gt; &lt;b&gt;Roteirização CPP concluída com sucesso!&lt;/b&gt; (Camada com {count} trechos viários)&lt;br&gt;</source>
        <translation>-&gt; &lt;b&gt;CPP Routing completed successfully!&lt;/b&gt; (Layer with {count} road segments)&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1144"/>
        <source>-&gt; &lt;b&gt;Resultado da roteirização retornou vazio.&lt;/b&gt;&lt;br&gt;</source>
        <translation>-&gt; &lt;b&gt;Routing result returned empty.&lt;/b&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1013"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro ao executar roteirização CPP: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Error executing CPP routing: {error}&lt;/span&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1151"/>
        <source>&lt;b&gt;=== ROTEIRIZAÇÃO CONCLUÍDA ===&lt;/b&gt;</source>
        <translation>&lt;b&gt;=== ROUTING COMPLETED ===&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1032"/>
        <source>Por favor, selecione a camada de vias para a roteirização RPP.</source>
        <translation>Please select the roads layer for RPP routing.</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1052"/>
        <source>&lt;b&gt;=== EXECUTANDO ROTEIRIZAÇÃO RPP ===&lt;/b&gt;&lt;br&gt;</source>
        <translation>&lt;b&gt;=== EXECUTING RPP ROUTING ===&lt;/b&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1070"/>
        <source>-&gt; &lt;b&gt;Roteirização RPP concluída com sucesso!&lt;/b&gt; (Camada com {count} trechos viários)&lt;br&gt;</source>
        <translation>-&gt; &lt;b&gt;RPP Routing completed successfully!&lt;/b&gt; (Layer with {count} road segments)&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1077"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro ao executar roteirização RPP: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Error executing RPP routing: {error}&lt;/span&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1099"/>
        <source>Por favor, selecione a camada de vias, o campo de demanda e a camada do depósito para a roteirização CARP.</source>
        <translation>Please select the roads layer, demand field, and depot layer for CARP routing.</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1119"/>
        <source>&lt;b&gt;=== EXECUTANDO ROTEIRIZAÇÃO CARP ===&lt;/b&gt;&lt;br&gt;</source>
        <translation>&lt;b&gt;=== EXECUTING CARP ROUTING ===&lt;/b&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1140"/>
        <source>-&gt; &lt;b&gt;Roteirização CARP concluída com sucesso!&lt;/b&gt; (Camada com {count} trechos viários)&lt;br&gt;</source>
        <translation>-&gt; &lt;b&gt;CARP Routing completed successfully!&lt;/b&gt; (Layer with {count} road segments)&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1147"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro ao executar roteirização CARP: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Error executing CARP routing: {error}&lt;/span&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1169"/>
        <source>Por favor, selecione a camada de rotas e o campo ID da rota para o dimensionamento de frota.</source>
        <translation>Please select the routes layer and route ID field for fleet sizing.</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1189"/>
        <source>&lt;b&gt;=== EXECUTANDO DIMENSIONAMENTO DE FROTA ===&lt;/b&gt;&lt;br&gt;</source>
        <translation>&lt;b&gt;=== EXECUTING FLEET SIZING ===&lt;/b&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1210"/>
        <source>-&gt; &lt;b&gt;Dimensionamento de frota concluído com sucesso!&lt;/b&gt; (Camada com {count} registros)&lt;br&gt;</source>
        <translation>-&gt; &lt;b&gt;Fleet sizing completed successfully!&lt;/b&gt; (Layer with {count} records)&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1214"/>
        <source>-&gt; &lt;b&gt;Resultado do dimensionamento retornou vazio.&lt;/b&gt;&lt;br&gt;</source>
        <translation>-&gt; &lt;b&gt;Sizing result returned empty.&lt;/b&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1217"/>
        <source>&lt;span style=&apos;color: #fc8181;&apos;&gt;Erro ao executar dimensionamento de frota: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Error executing fleet sizing: {error}&lt;/span&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1221"/>
        <source>&lt;b&gt;=== DIMENSIONAMENTO CONCLUÍDO ===&lt;/b&gt;</source>
        <translation>&lt;b&gt;=== SIZING COMPLETED ===&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1240"/>
        <source>Por favor, selecione a camada de rotas e o campo de carga para a análise de equilíbrio.</source>
        <translation>Please select the routes layer and load field for balance analysis.</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1260"/>
        <source>&lt;b&gt;=== EXECUTANDO EQUILÍBRIO ENTRE SETORES ===&lt;/b&gt;&lt;br&gt;</source>
        <translation>&lt;b&gt;=== EXECUTING SECTOR BALANCE ===&lt;/b&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1282"/>
        <source>-&gt; &lt;b&gt;Equilíbrio entre setores calculado com sucesso!&lt;/b&gt; (Camada com {count} registros)&lt;br&gt;</source>
        <translation>-&gt; &lt;b&gt;Balance between sectors calculated successfully!&lt;/b&gt; (Layer with {count} records)&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1286"/>
        <source>-&gt; &lt;b&gt;Resultado do equilíbrio retornou vazio.&lt;/b&gt;&lt;br&gt;</source>
        <translation>-&gt; &lt;b&gt;Balance result returned empty.&lt;/b&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1289"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro ao executar equilíbrio entre setores: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Error executing sector balance: {error}&lt;/span&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1293"/>
        <source>&lt;b&gt;=== ANÁLISE CONCLUÍDA ===&lt;/b&gt;</source>
        <translation>&lt;b&gt;=== ANALYSIS COMPLETED ===&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1308"/>
        <source>Por favor, selecione a rede viária, a camada de destinos e a camada de setores para o cálculo de distância ao destino.</source>
        <translation>Please select the road network, destinations layer, and sectors layer for distance to destination calculation.</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1328"/>
        <source>&lt;b&gt;=== EXECUTANDO DISTÂNCIA AO DESTINO ===&lt;/b&gt;&lt;br&gt;</source>
        <translation>&lt;b&gt;=== EXECUTING DISTANCE TO DESTINATION ===&lt;/b&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1346"/>
        <source>-&gt; &lt;b&gt;Distância ao destino calculada com sucesso!&lt;/b&gt; (Camada com {count} registro(s))&lt;br&gt;</source>
        <translation>-&gt; &lt;b&gt;Distance to destination calculated successfully!&lt;/b&gt; (Layer with {count} record(s))&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1350"/>
        <source>-&gt; &lt;b&gt;Resultado da distância ao destino retornou vazio.&lt;/b&gt;&lt;br&gt;</source>
        <translation>-&gt; &lt;b&gt;Distance to destination result returned empty.&lt;/b&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1353"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro ao executar distância ao destino: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Error executing distance to destination: {error}&lt;/span&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1374"/>
        <source>Por favor, selecione a camada de vias exigidas e a camada de rota coberta para o cálculo de cobertura por frequência.</source>
        <translation>Please select the required roads layer and covered route layer for frequency coverage calculation.</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1394"/>
        <source>&lt;b&gt;=== EXECUTANDO COBERTURA POR FREQUÊNCIA ===&lt;/b&gt;&lt;br&gt;</source>
        <translation>&lt;b&gt;=== EXECUTING FREQUENCY COVERAGE ===&lt;/b&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1414"/>
        <source>-&gt; &lt;b&gt;Cobertura por frequência calculada com sucesso!&lt;/b&gt; (Camada com {count} registro(s))&lt;br&gt;</source>
        <translation>-&gt; &lt;b&gt;Frequency coverage calculated successfully!&lt;/b&gt; (Layer with {count} record(s))&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1418"/>
        <source>-&gt; &lt;b&gt;Resultado da cobertura por frequência retornou vazio.&lt;/b&gt;&lt;br&gt;</source>
        <translation>-&gt; &lt;b&gt;Frequency coverage result returned empty.&lt;/b&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1421"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro ao executar cobertura por frequência: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Error executing frequency coverage: {error}&lt;/span&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="234"/>
        <source>Geração</source>
        <translation>Generation</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="299"/>
        <source>&lt;b&gt;Setorização&lt;/b&gt;</source>
        <translation>&lt;b&gt;Districting&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="310"/>
        <source>Campo de carga (opcional):</source>
        <translation>Load field (optional):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="319"/>
        <source>Número de setores de coleta desejado:</source>
        <translation>Desired number of collection sectors:</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="334"/>
        <source>Máximo de iterações de rebalanceamento:</source>
        <translation>Maximum rebalancing iterations:</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="341"/>
        <source>Executar Setorização</source>
        <translation>Run Districting</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="349"/>
        <source>Roteirização</source>
        <translation>Routing</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="495"/>
        <source>Frota</source>
        <translation>Fleet</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="565"/>
        <source>Indicadores</source>
        <translation>Indicators</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="568"/>
        <source>&lt;b&gt;Deadhead Ratio (Razão de Deadhead)&lt;/b&gt;</source>
        <translation>&lt;b&gt;Deadhead Ratio&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="573"/>
        <source>Camada de rotas/vias de coleta (Linhas):</source>
        <translation>Collection routes/roads layer (Lines):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="579"/>
        <source>Campo indicador de deadhead/improdutivo:</source>
        <translation>Deadhead/unproductive indicator field:</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="586"/>
        <source>Campo de identificação da rota/setor (opcional):</source>
        <translation>Route/sector identification field (optional):</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="595"/>
        <source>Executar Razão de Deadhead</source>
        <translation>Run Deadhead Ratio</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="891"/>
        <source>Por favor, selecione a camada de vias para a setorização.</source>
        <translation>Please select the roads layer for districting.</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="911"/>
        <source>&lt;b&gt;=== EXECUTANDO SETORIZAÇÃO ===&lt;/b&gt;&lt;br&gt;</source>
        <translation>&lt;b&gt;=== RUNNING DISTRICTING ===&lt;/b&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="930"/>
        <source>-&gt; &lt;b&gt;Setorização concluída com sucesso!&lt;/b&gt; (Camada com {count} trechos viários)&lt;br&gt;</source>
        <translation>-&gt; &lt;b&gt;Districting completed successfully!&lt;/b&gt; (Layer with {count} road segments)&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="948"/>
        <source>-&gt; &lt;b&gt;Resultado da setorização retornou vazio.&lt;/b&gt;&lt;br&gt;</source>
        <translation>-&gt; &lt;b&gt;Districting result returned empty.&lt;/b&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="951"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro ao executar setorização: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Error executing districting: {error}&lt;/span&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="955"/>
        <source>&lt;b&gt;=== EXECUÇÃO CONCLUÍDA ===&lt;/b&gt;</source>
        <translation>&lt;b&gt;=== EXECUTION COMPLETE ===&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1439"/>
        <source>Por favor, selecione a camada de rotas e o campo indicador de deadhead para a análise.</source>
        <translation>Please select the routes layer and the deadhead indicator field for the analysis.</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1459"/>
        <source>&lt;b&gt;=== EXECUTANDO RAZÃO DE DEADHEAD ===&lt;/b&gt;&lt;br&gt;</source>
        <translation>&lt;b&gt;=== RUNNING DEADHEAD RATIO ===&lt;/b&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1476"/>
        <source>-&gt; &lt;b&gt;Razão de deadhead calculada com sucesso!&lt;/b&gt; (Camada com {count} registro(s))&lt;br&gt;</source>
        <translation>-&gt; &lt;b&gt;Deadhead ratio calculated successfully!&lt;/b&gt; (Layer with {count} record(s))&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1480"/>
        <source>-&gt; &lt;b&gt;Resultado da razão de deadhead retornou vazio.&lt;/b&gt;&lt;br&gt;</source>
        <translation>-&gt; &lt;b&gt;Deadhead ratio result returned empty.&lt;/b&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="1483"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro ao executar razão de deadhead: {error}&lt;/span&gt;&lt;br&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Error executing deadhead ratio: {error}&lt;/span&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="268"/>
        <source>Campo ID do setor (Vias) — vazio: associa automaticamente</source>
        <translation>Sector ID field (Roads) — empty: assigns automatically</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="834"/>
        <source>-&gt; &lt;b&gt;Setores associados às vias com sucesso!&lt;/b&gt; ({count} trechos viários)&lt;br&gt;</source>
        <translation>-&gt; &lt;b&gt;Sectors associated with roads successfully!&lt;/b&gt; ({count} road segments)&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="840"/>
        <source>&lt;span style='color: #fc8181;'&gt;Erro: Falha na associação das vias aos setores.&lt;/span&gt;&lt;br&gt;</source>
        <translation>&lt;span style='color: #fc8181;'&gt;Error: Failed to associate roads with sectors.&lt;/span&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../gui/waste_dock.py" line="941"/>
        <source>&lt;span style='color: #f6e05e;'&gt;Aviso: {count} trecho(s) fora da rede principal (filtre por &quot;collection_sector_id&quot; = -1 para visualizá-los).&lt;/span&gt;&lt;br&gt;</source>
        <translation>&lt;span style='color: #f6e05e;'&gt;Warning: {count} segment(s) outside main network (filter by &quot;collection_sector_id&quot; = -1 to view them).&lt;/span&gt;&lt;br&gt;</translation>
    </message>
</context>
<context>
    <name>WasteFleetSizing</name>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="71"/>
        <source>Camada de rotas de coleta (saída de logis:waste_carp_route)</source>
        <translation>Collection routes layer (output from logis:waste_carp_route)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="78"/>
        <source>Campo de identificação da rota</source>
        <translation>Route identification field</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="86"/>
        <source>Campo de setor de coleta (opcional)</source>
        <translation>Collection sector field (optional)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="94"/>
        <source>Velocidade média de coleta (km/h)</source>
        <translation>Average collection speed (km/h)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="103"/>
        <source>Duração da jornada de trabalho diária (horas)</source>
        <translation>Daily work shift duration (hours)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="112"/>
        <source>Tempo fixo de descarga por rota (horas)</source>
        <translation>Fixed unloading time per route (hours)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="121"/>
        <source>Tempo fixo de deslocamento ao destino por rota (horas)</source>
        <translation>Fixed travel time to destination per route (hours)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="130"/>
        <source>Dimensionamento de frota por setor</source>
        <translation>Fleet sizing by sector</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="147"/>
        <source>Camada de rotas de coleta inválida.</source>
        <translation>Invalid collection routes layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="151"/>
        <source>Campo de identificação da rota inválido.</source>
        <translation>Invalid route identification field.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="159"/>
        <source>Lendo rotas e somando distâncias por setor...</source>
        <translation>Reading routes and summing distances by sector...</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="186"/>
        <source>Nenhuma rota válida encontrada na camada de entrada.</source>
        <translation>No valid route found in input layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="206"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation>Could not create output layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="217"/>
        <source>Dimensionando frota do setor &apos;{sec}&apos; ({count} rota(s))...</source>
        <translation>Sizing fleet for sector '{sec}' ({count} route(s))...</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="232"/>
        <source>Erro ao dimensionar a frota do setor &apos;{sec}&apos;: {err}</source>
        <translation>Error sizing fleet for sector '{sec}': {err}</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="238"/>
        <source>Setor '{sec}': {fleet} veículo(s) necessário(s) | Utilização média: {util:.1f}% | Tempo total de rotas: {total:.2f} h</source>
        <translation>Sector '{sec}': {fleet} vehicle(s) required | Average utilization: {util:.1f}% | Total route time: {total:.2f} h</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="250"/>
        <source>Aviso: frota do setor '{sec}' com utilização média abaixo de 50% ({util:.1f}%) — possível sobredimensionamento.</source>
        <translation>Warning: fleet in sector '{sec}' has average utilization under 50% ({util:.1f}%) — possible oversizing.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="277"/>
        <source>Dimensionamento de Frota de Coleta</source>
        <translation>Collection Fleet Sizing</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="280"/>
        <source>Logística Especializada — Coleta de Lixo</source>
        <translation>Specialized Logistics — Waste Collection</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_fleet_sizing.py" line="286"/>
        <source>Dimensiona a frota de veículos necessária para atender às rotas de coleta de resíduos sólidos durante a jornada de trabalho, aplicando o algoritmo First-Fit Decreasing (FFD) para o problema de empacotamento (Bin Packing).

Parâmetros:
- Camada de rotas de coleta: feições de linha, tipicamente a saída de logis:waste_carp_route.
- Campo de identificação da rota (obrigatório): agrupa feições pela rota/viagem ('route_id'); a distância de cada rota é a soma do comprimento das geometrias.
- Campo de setor de coleta (opcional): se informado, dimensiona a frota separadamente por setor ('route_sector_id'); se omitido, trata a camada inteira como um único setor.
- Velocidade média de coleta: velocidade operacional em km/h (default: 10 km/h).
- Duração da jornada: tempo máximo de trabalho por veículo em horas (default: 8 h).
- Tempo fixo de descarga: tempo gasto na descarga por rota em horas (default: 0.5 h).
- Tempo fixo de deslocamento: tempo de viagem ao aterro/depósito por rota em horas (default: 0.5 h).

Uma rota isolada cuja duração exceda a jornada de trabalho gera erro explícito em vez de ser dividida entre mais de um veículo (sem split).

Retorno:
- Tabela sem geometria com uma feição por setor: 'sector_id', 'fleet_size' (nº de veículos estimado), 'num_routes' (nº de rotas do setor), 'total_route_time_h' (soma das durações das rotas) e 'avg_utilization' (utilização média da frota, entre 0 e 1).</source>
        <translation>Sizes the fleet of vehicles needed to service solid waste collection routes during the work shift, applying the First-Fit Decreasing (FFD) algorithm for the Bin Packing problem.

Parameters:
- Collection routes layer: line features, typically the output of logis:waste_carp_route.
- Route identification field (required): groups features by route/trip ('route_id'); distance of each route is the sum of geometry lengths.
- Collection sector field (optional): if provided, sizes fleet separately per sector ('route_sector_id'); if omitted, treats entire layer as a single sector.
- Average collection speed: operational speed in km/h (default: 10 km/h).
- Shift duration: maximum working time per vehicle in hours (default: 8 h).
- Fixed unloading time: time spent unloading per route in hours (default: 0.5 h).
- Fixed travel time: travel time to landfill/depot per route in hours (default: 0.5 h).

An isolated route whose duration exceeds the work shift produces an explicit error instead of being split among multiple vehicles (no split).

Returns:
- Geometryless table with one feature per sector: 'sector_id', 'fleet_size' (estimated vehicle count), 'num_routes' (route count in sector), 'total_route_time_h' (sum of route durations), and 'avg_utilization' (average fleet utilization between 0 and 1).</translation>
    </message>
</context>
<context>
    <name>WasteGenerationEstimate</name>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="62"/>
        <source>Camada de setores (população)</source>
        <translation>Sectors layer (population)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="69"/>
        <source>Campo de identificação do setor</source>
        <translation>Sector identification field</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="77"/>
        <source>Campo de população (habitantes)</source>
        <translation>Population field (inhabitants)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="85"/>
        <source>Camada de vias (com setor já associado)</source>
        <translation>Roads layer (with sector already assigned)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="92"/>
        <source>Campo de identificação do setor na camada de vias</source>
        <translation>Sector identification field in roads layer</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="100"/>
        <source>Geração per capita (kg/hab/dia)</source>
        <translation>Per capita generation (kg/hab/day)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="109"/>
        <source>Fração de cobertura da coleta (0 a 1)</source>
        <translation>Collection coverage fraction (0 to 1)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="119"/>
        <source>Vias com estimativa de geração de resíduos</source>
        <translation>Roads with estimated waste generation</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="136"/>
        <source>Camada de setores inválida.</source>
        <translation>Invalid sectors layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="138"/>
        <source>Camada de vias inválida.</source>
        <translation>Invalid roads layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="142"/>
        <source>Campo de população '{field}' não encontrado na camada de setores.</source>
        <translation>Population field '{field}' not found in sectors layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="147"/>
        <source>Campo de identificação do setor '{field}' não encontrado na camada de setores.</source>
        <translation>Sector identification field '{field}' not found in sectors layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="152"/>
        <source>Campo de identificação do setor '{field}' não encontrado na camada de vias.</source>
        <translation>Sector identification field '{field}' not found in roads layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="157"/>
        <source>Lendo população dos setores...</source>
        <translation>Reading sector population...</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="169"/>
        <source>Agrupando trechos de via por setor...</source>
        <translation>Grouping road segments by sector...</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="176"/>
        <source>Trecho {fid} sem setor associado — ignorado.</source>
        <translation>Segment {fid} with no associated sector — ignored.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="191"/>
        <source>Setor '{sector}' presente na camada de vias mas não encontrado na camada de setores — ignorado.</source>
        <translation>Sector '{sector}' present in roads layer but not found in sectors layer — ignored.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="214"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation>Could not create output layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="232"/>
        <source>Geração de resíduos estimada para {count} trecho(s) de via.</source>
        <translation>Estimated waste generation for {count} road segment(s).</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="243"/>
        <source>Estimativa de Geração de Resíduos Sólidos</source>
        <translation>Solid Waste Generation Estimation</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="246"/>
        <source>Logística Especializada — Coleta de Lixo</source>
        <translation>Specialized Logistics — Waste Collection</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="252"/>
        <source>Estima a geração de resíduos sólidos (em kg/dia) por trecho de via, a partir da população de cada setor e do rateio proporcional ao comprimento dos trechos de via associados a esse setor.

A camada de vias deve chegar com um campo de identificação do setor já preenchido (ex.: executando native:joinbylocation manualmente no QGIS antes deste algorithm, ou trazendo o campo de outra fonte) — este algorithm não faz nenhum spatial join.

Parâmetros:
- Camada de setores: feições de polígono representando os setores de coleta.
- Campo de identificação do setor (setores): identifica cada setor.
- Campo de população: população de cada setor.
- Camada de vias: feições de linha representando os trechos de via a coletar.
- Campo de identificação do setor (vias): associa cada trecho de via ao seu setor.
- Geração per capita: taxa de geração diária por habitante em kg (default: 0.9 kg/hab/dia).
- Fração de cobertura: fração da população do setor efetivamente coberta pela coleta (default: 1.0).

Retorno:
- Camada de vias com a nova coluna 'waste_kg_day', contendo a geração de resíduos rateada de cada trecho (kg/dia).</source>
        <translation type="obsolete">Estimates solid waste generation (in kg/day) per road segment based on sector population and proportional allocation by length of road segments associated with that sector.

The roads layer must arrive with a sector identification field already filled in (e.g. running native:joinbylocation manually in QGIS before this algorithm, or bringing the field from another source) — this algorithm performs no spatial join.

Parameters:
- Sectors layer: polygon features representing collection sectors.
- Sector identification field (sectors): identifies each sector.
- Population field: population of each sector.
- Roads layer: line features representing road segments to collect.
- Sector identification field (roads): associates each road segment to its sector.
- Per capita generation: daily generation rate per inhabitant in kg (default: 0.9 kg/hab/day).
- Coverage fraction: fraction of sector population effectively covered by collection (default: 1.0).

Returns:
- Roads layer with new column 'waste_kg_day', containing allocated waste generation for each segment (kg/day).</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_generation_estimate.py" line="252"/>
        <source>Estima a geração de resíduos sólidos (em kg/dia) por trecho de via, a partir da população de cada setor e do rateio proporcional ao comprimento dos trechos de via associados a esse setor.

A camada de vias deve chegar com um campo de identificação do setor já preenchido (ex.: rodando antes logis:waste_street_sector_join no QGIS antes deste algorithm, ou trazendo o campo de outra fonte) — este algorithm não faz nenhum spatial join.

Parâmetros:
- Camada de setores: feições de polígono representando os setores de coleta.
- Campo de identificação do setor (setores): identifica cada setor.
- Campo de população: população de cada setor.
- Camada de vias: feições de linha representando os trechos de via a coletar.
- Campo de identificação do setor (vias): associa cada trecho de via ao seu setor.
- Geração per capita: taxa de geração diária por habitante em kg (default: 0.9 kg/hab/dia).
- Fração de cobertura: fração da população do setor efetivamente coberta pela coleta (default: 1.0).

Retorno:
- Camada de vias com a nova coluna 'waste_kg_day', contendo a geração de resíduos rateada de cada trecho (kg/dia).</source>
        <translation>Estimates solid waste generation (in kg/day) per road segment based on sector population and proportional allocation by length of road segments associated with that sector.

The roads layer must arrive with a sector identification field already filled in (e.g. running logis:waste_street_sector_join in QGIS before this algorithm, or bringing the field from another source) — this algorithm performs no spatial join.

Parameters:
- Sectors layer: polygon features representing collection sectors.
- Sector identification field (sectors): identifies each sector.
- Population field: population of each sector.
- Roads layer: line features representing road segments to collect.
- Sector identification field (roads): associates each road segment to its sector.
- Per capita generation: daily generation rate per inhabitant in kg (default: 0.9 kg/hab/day).
- Coverage fraction: fraction of sector population effectively covered by collection (default: 1.0).

Returns:
- Roads layer with new column 'waste_kg_day', containing allocated waste generation for each segment (kg/day).</translation>
    </message>
</context>
<context>
    <name>WasteRppRoute</name>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="114"/>
        <source>Camada de vias</source>
        <translation>Roads layer</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="121"/>
        <source>Campo de via obrigatória para coleta (opcional)</source>
        <translation>Required road field for collection (optional)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="129"/>
        <source>Campo de setor de coleta (opcional)</source>
        <translation>Collection sector field (optional)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="134"/>
        <source>Tolerância de nó em metros (requer CRS métrico)</source>
        <translation type="obsolete">Node tolerance in meters (requires metric CRS)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="146"/>
        <source>Vias com rota de coleta (RPP)</source>
        <translation>Roads with collection route (RPP)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="160"/>
        <source>Camada de vias inválida.</source>
        <translation>Invalid roads layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="173"/>
        <source>Lendo trechos de via e agrupando por setor...</source>
        <translation>Reading road segments and grouping by sector...</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="235"/>
        <source>{count} trecho(s) com geometria inválida foram ignorados.</source>
        <translation>{count} segment(s) with invalid geometry were ignored.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="242"/>
        <source>Nenhum trecho de via válido encontrado na camada de entrada.</source>
        <translation>No valid road segment found in input layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="260"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation>Could not create output layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="273"/>
        <source>Setor '{sec}': nenhum trecho de coleta obrigatória. Ignorando setor.</source>
        <translation>Sector '{sec}': no required collection segment. Ignoring sector.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="282"/>
        <source>Calculando rota RPP para o setor '{sec}' ({req_count} obrigatórios de {tot_count} trechos)...</source>
        <translation>Calculating RPP route for sector '{sec}' ({req_count} required of {tot_count} segments)...</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="327"/>
        <source>Erro ao calcular rota RPP para o setor &apos;{sec}&apos;: {err}</source>
        <translation>Error calculating RPP route for sector '{sec}': {err}</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="338"/>
        <source>Setor '{sec}': RPP concluído com {steps} passo(s). {km:.2f} km de deadhead/deslocamento.</source>
        <translation>Sector '{sec}': RPP completed in {steps} step(s). {km:.2f} km deadhead/travel.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="365"/>
        <source>Roteirização por Arcos (RPP)</source>
        <translation>Arc Routing (RPP)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="368"/>
        <source>Logística Especializada — Coleta de Lixo</source>
        <translation>Specialized Logistics — Waste Collection</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="374"/>
        <source>Calcula a sequência de percurso para coleta de lixo por arcos em um subconjunto de vias obrigatórias usando o Problema do Carteiro Rural (Rural Postman Problem - RPP).

Parâmetros:
- Camada de vias: feições de linha com a malha viária.
- Campo de via obrigatória (opcional): campo booleano/inteiro indicando trechos de coleta obrigatória; se omitido, todas as vias são consideradas obrigatórias (equivalente ao CPP).
- Campo de setor de coleta (opcional): se informado, o RPP é resolvido separadamente por setor.
- Tolerância de nó: distância em metros para conectar vértices das vias.

Retorno:
- Camada de linha com feições duplicadas na sequência de travessia e três campos adicionais: 'route_visit_order' (posição sequencial no circuito), 'route_sector_id' (setor de coleta) e 'route_is_connector' (booleano indicando via conetora).</source>
        <translation>Calculates travel sequence for arc waste collection on a subset of required roads using the Rural Postman Problem (RPP).

Parameters:
- Roads layer: line features with the road network.
- Required road field (optional): boolean/integer field indicating required collection segments; if omitted, all roads are considered required (equivalent to CPP).
- Collection sector field (optional): if provided, RPP is solved separately by sector.
- Node tolerance: distance in meters to connect road vertices.

Returns:
- Line layer with duplicated features in traversal sequence and three additional fields: 'route_visit_order' (sequential position in circuit), 'route_sector_id' (collection sector), and 'route_is_connector' (boolean indicating connector road).</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="137"/>
        <source>Tolerância de nó (m)</source>
        <translation>Node tolerance (m)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_rpp_route.py" line="180"/>
        <source>camada de vias</source>
        <translation>roads layer</translation>
    </message>
</context>
<context>
    <name>WasteSectorBalance</name>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="74"/>
        <source>Camada de rotas de coleta (ex.: saída de logis:waste_carp_route)</source>
        <translation>Collection routes layer (e.g. output from logis:waste_carp_route)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="81"/>
        <source>Campo de carga da rota (kg)</source>
        <translation>Route load field (kg)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="91"/>
        <source>Campo de distância da rota em km (opcional)</source>
        <translation>Route distance field in km (optional)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="101"/>
        <source>Campo de identificação da rota (opcional)</source>
        <translation>Route identification field (optional)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="110"/>
        <source>Campo de setor de coleta (opcional)</source>
        <translation>Collection sector field (optional)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="119"/>
        <source>Velocidade média de coleta (km/h)</source>
        <translation>Average collection speed (km/h)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="129"/>
        <source>Tempo fixo de descarga por rota (horas)</source>
        <translation>Fixed unloading time per route (hours)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="138"/>
        <source>Tempo fixo de deslocamento ao destino por rota (horas)</source>
        <translation>Fixed travel time to destination per route (hours)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="147"/>
        <source>Indicadores de equilíbrio entre rotas por setor</source>
        <translation>Route balance indicators by sector</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="165"/>
        <source>Camada de rotas de coleta inválida.</source>
        <translation>Invalid collection routes layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="169"/>
        <source>Campo de carga da rota '{field}' não encontrado.</source>
        <translation>Route load field '{field}' not found.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="191"/>
        <source>Agrupando feições e calculando cargas e distâncias de rotas por setor...</source>
        <translation>Grouping features and calculating route loads and distances by sector...</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="235"/>
        <source>Nenhuma rota válida encontrada na camada de entrada.</source>
        <translation>No valid route found in input layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="264"/>
        <source>Não foi possível criar a camada de saída.</source>
        <translation>Could not create output layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="317"/>
        <source>Erro ao calcular equilíbrio do setor '{sec}': {err}</source>
        <translation>Error calculating balance for sector '{sec}': {err}</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="326"/>
        <source>Setor '{sec}': {num} rota(s) | Carga média: {m_load:.2f} kg (σ={std_load:.2f}, CV={cv_load:.1f}%)</source>
        <translation>Sector '{sec}': {num} route(s) | Average load: {m_load:.2f} kg (σ={std_load:.2f}, CV={cv_load:.1f}%)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="339"/>
        <source>Aviso: setor '{sec}' apresenta desbalanço de carga alto (CV={cv:.1f}% &gt; 20%).</source>
        <translation>Warning: sector '{sec}' exhibits high load imbalance (CV={cv:.1f}% &gt; 20%).</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="346"/>
        <source>Setor '{sec}': Tempo médio: {m_time:.2f} h (σ={std_time:.2f}, CV={cv_time:.1f}%)</source>
        <translation>Sector '{sec}': Average time: {m_time:.2f} h (σ={std_time:.2f}, CV={cv_time:.1f}%)</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="386"/>
        <source>Equilíbrio entre Setores/Rotas de Coleta</source>
        <translation>Balance between Collection Sectors/Routes</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="389"/>
        <source>Logística Especializada — Coleta de Lixo</source>
        <translation>Specialized Logistics — Waste Collection</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_sector_balance.py" line="395"/>
        <source>Avalia o equilíbrio (balanço) de carga e tempo operacional entre rotas/setores de coleta de resíduos sólidos, calculando média, desvio padrão, mínimo, máximo e coeficiente de variação (CV).

Parâmetros:
- Camada de rotas de coleta: feições com rotas/vias (ex.: saída de logis:waste_carp_route, com campos 'route_load_kg' e 'route_distance_km').
- Campo de carga da rota (obrigatório): campo numérico com a carga total da rota (kg).
- Campo de distância da rota (opcional): campo numérico com a distância em km; se omitido, utiliza a extensão das geometrias das rotas.
- Campo de identificação da rota (opcional): se informado, agrupa feições por rota.
- Campo de setor de coleta (opcional): se informado, calcula o equilíbrio separadamente para cada setor.
- Velocidade média de coleta: velocidade operacional em km/h (default: 10 km/h).
- Tempo fixo de descarga: tempo gasto na descarga por rota em horas (default: 0.0 h).
- Tempo fixo de deslocamento: tempo de viagem ao aterro/depósito em horas (default: 0.0 h).

Retorno:
- Tabela sem geometria com uma feição por setor: 'sector_id', 'num_routes', 'total_load_kg', 'mean_load_kg', 'std_dev_load_kg', 'min_load_kg', 'max_load_kg', 'cv_load', 'total_time_h', 'mean_time_h', 'std_dev_time_h', 'min_time_h', 'max_time_h' e 'cv_time'.</source>
        <translation>Evaluates load and operating time balance across solid waste collection routes/sectors, calculating mean, standard deviation, minimum, maximum, and coefficient of variation (CV).

Parameters:
- Collection routes layer: features with routes/roads (e.g. output from logis:waste_carp_route, with 'route_load_kg' and 'route_distance_km' fields).
- Route load field (required): numeric field with total route load (kg).
- Route distance field (optional): numeric field with distance in km; if omitted, uses length of route geometries.
- Route identification field (optional): if provided, groups features by route.
- Collection sector field (optional): if provided, calculates balance separately for each sector.
- Average collection speed: operational speed in km/h (default: 10 km/h).
- Fixed unloading time: time spent unloading per route in hours (default: 0.0 h).
- Fixed travel time: travel time to landfill/depot in hours (default: 0.0 h).

Returns:
- Geometryless table with one feature per sector: 'sector_id', 'num_routes', 'total_load_kg', 'mean_load_kg', 'std_dev_load_kg', 'min_load_kg', 'max_load_kg', 'cv_load', 'total_time_h', 'mean_time_h', 'std_dev_time_h', 'min_time_h', 'max_time_h', and 'cv_time'.</translation>
    </message>
</context>
<context>
    <name>WasteStreetSectorJoin</name>
    <message>
        <location filename="../algorithms/waste_street_sector_join.py" line="57"/>
        <source>Camada de vias</source>
        <translation>Roads layer</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_street_sector_join.py" line="64"/>
        <source>Camada de setores</source>
        <translation>Sectors layer</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_street_sector_join.py" line="71"/>
        <source>Campo de identificação do setor</source>
        <translation>Sector identification field</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_street_sector_join.py" line="79"/>
        <source>Vias com setor associado</source>
        <translation>Roads with associated sector</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_street_sector_join.py" line="94"/>
        <source>Camada de vias inválida.</source>
        <translation>Invalid roads layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_street_sector_join.py" line="96"/>
        <source>Camada de setores inválida.</source>
        <translation>Invalid sectors layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_street_sector_join.py" line="99"/>
        <source>Campo de identificação do setor '{field}' não encontrado na camada de setores.</source>
        <translation>Sector identification field '{field}' not found in sectors layer.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_street_sector_join.py" line="106"/>
        <source>A camada de vias já possui o campo '{field}'. Utilize esse campo diretamente em vez de refazer a junção.</source>
        <translation>The roads layer already contains the '{field}' field. Use this field directly instead of redoing the join.</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_street_sector_join.py" line="129"/>
        <source>Executando junção espacial por maior sobreposição...</source>
        <translation>Running spatial join by largest overlap...</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_street_sector_join.py" line="156"/>
        <source>{count} trecho(s) de via ficaram sem setor associado (valor NULL).</source>
        <translation>{count} road segment(s) were left with no associated sector (NULL value).</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_street_sector_join.py" line="168"/>
        <source>Associar Vias a Setores Censitários</source>
        <translation>Associate Roads with Census Tracts</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_street_sector_join.py" line="171"/>
        <source>Logística Especializada — Coleta de Lixo</source>
        <translation>Specialized Logistics — Waste Collection</translation>
    </message>
    <message>
        <location filename="../algorithms/waste_street_sector_join.py" line="177"/>
        <source>Associa espacialmente cada trecho de via ao setor censitário correspondente.

A operação utiliza a sobreposição espacial com critério de maior sobreposição (um para um), garantindo que trechos que cruzam a divisa entre dois setores sejam atribuídos ao setor onde possuem maior extensão, sem duplicar feições nem distorcer o rateio de extensão.

Trechos que estiverem fora de todos os setores recebem valor NULL no campo de setor, sem serem descartados da camada de saída.

Parâmetros:
- Camada de vias: linhas representando a malha viária a ser associada.
- Camada de setores: polígonos representando os setores censitários ou áreas de coleta.
- Campo de identificação do setor: campo da camada de setores que identifica unicamente cada setor.

Retorno:
- Camada de vias contendo todos os atributos originais mais o campo de identificação do setor preenchido conforme a sobreposição espacial.</source>
        <translation>Spatially associates each road segment with the corresponding census tract.

The operation uses spatial overlay with the largest overlap criterion (one-to-one), ensuring that segments crossing the boundary between two sectors are assigned to the sector where they have the greatest length, without duplicating features or distorting length allocation.

Segments outside all sectors receive a NULL value in the sector field, without being discarded from the output layer.

Parameters:
- Roads layer: lines representing the road network to be associated.
- Sectors layer: polygons representing census tracts or collection areas.
- Sector identification field: field in the sectors layer uniquely identifying each sector.

Returns:
- Roads layer containing all original attributes plus the sector identification field populated according to spatial overlap.</translation>
    </message>
</context>
<context>
    <name>_CollectingFeedback</name>
    <message>
        <location filename="../gui/network_dock.py" line="377"/>
        <source>Rede viária OSM ({code_muni}) carregada: {n_links} arcos, {n_nodes} nós.</source>
        <translation type="obsolete">OSM road network ({code_muni}) loaded: {n_links} links, {n_nodes} nodes.</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="395"/>
        <source>Por favor, selecione uma UF.</source>
        <translation type="obsolete">Please select a state (UF).</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="397"/>
        <source>Erro</source>
        <translation type="obsolete">Error</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="448"/>
        <source>Rede viária SNV ({uf}) carregada: {n_links} arcos, {n_nodes} nós.</source>
        <translation type="obsolete">SNV road network ({uf}) loaded: {n_links} links, {n_nodes} nodes.</translation>
    </message>
    <message>
        <location filename="../gui/network_dock.py" line="386"/>
        <source>Rede viária OSM ({code_muni}) carregada via {source}: {n_links} arcos, {n_nodes} nós.</source>
        <translation type="obsolete">OSM road network ({code_muni}) loaded via {source}: {n_links} links, {n_nodes} nodes.</translation>
    </message>
</context>
</TS>
